-- =====================================================================
-- PASTELERÍA LORENITA — ESQUEMA DE BASE DE DATOS
-- Motor: MySQL 8+ / MariaDB 10.5+ (compatible con adaptación a Postgres)
-- Charset: utf8mb4 (soporta emojis y acentos correctamente)
--
-- Diseño normalizado (3FN) y preparado para crecer sin reescribir tablas:
-- separa catálogo, personalización, pedidos, temas y configuración.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. CONFIGURACIÓN GENERAL DEL NEGOCIO
-- ---------------------------------------------------------------------

-- Fila única con la configuración global. Se usa un id fijo = 1.
CREATE TABLE admin_settings (
  id                TINYINT UNSIGNED PRIMARY KEY DEFAULT 1,
  business_name     VARCHAR(120) NOT NULL DEFAULT 'Pastelería Lorenita',
  password_hash     VARCHAR(255) NOT NULL,          -- bcrypt/argon2, nunca texto plano
  whatsapp_number   VARCHAR(20),
  contact_email     VARCHAR(150),
  address           VARCHAR(255),
  active_theme_id   VARCHAR(60) NOT NULL DEFAULT 'dulce-suspiro',
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_admin_settings_singleton CHECK (id = 1)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. SISTEMA DE TEMAS
-- ---------------------------------------------------------------------

CREATE TABLE themes (
  id            VARCHAR(60) PRIMARY KEY,      -- slug, ej. 'dulce-suspiro' o 'custom-xxxx'
  name          VARCHAR(80) NOT NULL,
  description   VARCHAR(255),
  is_custom     BOOLEAN NOT NULL DEFAULT FALSE,
  is_active_default BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Cada color de cada tema vive en su propia fila: fácil de agregar roles
-- nuevos (ej. "color de borde") sin alterar la estructura de la tabla themes.
CREATE TABLE theme_colors (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  theme_id    VARCHAR(60) NOT NULL,
  role        ENUM('primary','primaryDark','secondary','accent','background',
                    'surface','card','header','text','textMuted','buttonText') NOT NULL,
  rgb_value   VARCHAR(20) NOT NULL,           -- formato "R G B", ej. "236 100 149"
  UNIQUE KEY uq_theme_role (theme_id, role),
  CONSTRAINT fk_theme_colors_theme FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 3. CLIENTES
-- ---------------------------------------------------------------------

CREATE TABLE clients (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(150) NOT NULL,
  phone         VARCHAR(20) NOT NULL,
  email         VARCHAR(150),
  notes         TEXT,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_clients_phone (phone)
) ENGINE=InnoDB;

CREATE TABLE client_addresses (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id     BIGINT UNSIGNED NOT NULL,
  label         VARCHAR(60) DEFAULT 'Principal',
  address_line  VARCHAR(255) NOT NULL,
  city          VARCHAR(100),
  reference     VARCHAR(255),
  is_default    BOOLEAN NOT NULL DEFAULT TRUE,
  CONSTRAINT fk_client_addresses_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. CATÁLOGO: PASTELES Y SUS OPCIONES DE PERSONALIZACIÓN
-- ---------------------------------------------------------------------

CREATE TABLE cake_categories (
  id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name    VARCHAR(80) NOT NULL UNIQUE          -- ej. Cumpleaños, Bodas, Temáticos
) ENGINE=InnoDB;

CREATE TABLE cakes (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id   INT UNSIGNED,
  name          VARCHAR(150) NOT NULL,
  description   TEXT,
  base_price    DECIMAL(10,2) NOT NULL,
  image_url     VARCHAR(500),
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_cakes_category FOREIGN KEY (category_id) REFERENCES cake_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE cake_sizes (
  id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cake_id           BIGINT UNSIGNED NOT NULL,
  size_name         VARCHAR(60) NOT NULL,        -- ej. "6 personas", "20 personas"
  price_modifier    DECIMAL(10,2) NOT NULL DEFAULT 0, -- se suma al base_price
  CONSTRAINT fk_cake_sizes_cake FOREIGN KEY (cake_id) REFERENCES cakes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE flavors (
  id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name    VARCHAR(80) NOT NULL UNIQUE            -- ej. Vainilla, Chocolate, Red Velvet
) ENGINE=InnoDB;

CREATE TABLE fillings (
  id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name    VARCHAR(80) NOT NULL UNIQUE            -- ej. Fresa, Cajeta, Nutella
) ENGINE=InnoDB;

-- Relación N:M — qué sabores están disponibles para cada pastel
CREATE TABLE cake_flavor_options (
  cake_id     BIGINT UNSIGNED NOT NULL,
  flavor_id   INT UNSIGNED NOT NULL,
  extra_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (cake_id, flavor_id),
  CONSTRAINT fk_cfo_cake FOREIGN KEY (cake_id) REFERENCES cakes(id) ON DELETE CASCADE,
  CONSTRAINT fk_cfo_flavor FOREIGN KEY (flavor_id) REFERENCES flavors(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Relación N:M — qué rellenos están disponibles para cada pastel
CREATE TABLE cake_filling_options (
  cake_id     BIGINT UNSIGNED NOT NULL,
  filling_id  INT UNSIGNED NOT NULL,
  extra_price DECIMAL(10,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (cake_id, filling_id),
  CONSTRAINT fk_cfio_cake FOREIGN KEY (cake_id) REFERENCES cakes(id) ON DELETE CASCADE,
  CONSTRAINT fk_cfio_filling FOREIGN KEY (filling_id) REFERENCES fillings(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cake_images (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cake_id     BIGINT UNSIGNED NOT NULL,
  image_url   VARCHAR(500) NOT NULL,
  sort_order  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT fk_cake_images_cake FOREIGN KEY (cake_id) REFERENCES cakes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. PRODUCTOS ADICIONALES (cupcakes, galletas, bebidas, etc.)
-- ---------------------------------------------------------------------

CREATE TABLE additional_product_categories (
  id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name    VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE additional_products (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id   INT UNSIGNED,
  name          VARCHAR(150) NOT NULL,
  description   TEXT,
  price         DECIMAL(10,2) NOT NULL,
  image_url     VARCHAR(500),
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_additional_products_category
    FOREIGN KEY (category_id) REFERENCES additional_product_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 6. PROMOCIONES
-- ---------------------------------------------------------------------

CREATE TABLE promotions (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title           VARCHAR(150) NOT NULL,
  description     TEXT,
  image_url       VARCHAR(500),
  discount_type   ENUM('percentage','fixed_amount') NOT NULL DEFAULT 'percentage',
  discount_value  DECIMAL(10,2) NOT NULL,
  start_date      DATE NOT NULL,
  end_date        DATE NOT NULL,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (end_date >= start_date)
) ENGINE=InnoDB;

-- Relación N:M — a qué pasteles aplica una promoción (vacío = aplica a todos)
CREATE TABLE promotion_cakes (
  promotion_id  BIGINT UNSIGNED NOT NULL,
  cake_id       BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (promotion_id, cake_id),
  CONSTRAINT fk_promo_cakes_promo FOREIGN KEY (promotion_id) REFERENCES promotions(id) ON DELETE CASCADE,
  CONSTRAINT fk_promo_cakes_cake FOREIGN KEY (cake_id) REFERENCES cakes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 7. PEDIDOS
-- ---------------------------------------------------------------------

CREATE TABLE orders (
  id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id         BIGINT UNSIGNED NOT NULL,
  status            ENUM('pendiente','confirmado','en_preparacion','listo','entregado','cancelado')
                      NOT NULL DEFAULT 'pendiente',
  delivery_type     ENUM('recoger','domicilio') NOT NULL DEFAULT 'recoger',
  delivery_address_id BIGINT UNSIGNED,
  delivery_datetime DATETIME NOT NULL,
  subtotal          DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount_total    DECIMAL(10,2) NOT NULL DEFAULT 0,
  total             DECIMAL(10,2) NOT NULL DEFAULT 0,
  notes             TEXT,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_orders_client FOREIGN KEY (client_id) REFERENCES clients(id),
  CONSTRAINT fk_orders_address FOREIGN KEY (delivery_address_id) REFERENCES client_addresses(id)
) ENGINE=InnoDB;

-- Historial de cambios de estado, útil para reportes y trazabilidad
CREATE TABLE order_status_history (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id    BIGINT UNSIGNED NOT NULL,
  status      ENUM('pendiente','confirmado','en_preparacion','listo','entregado','cancelado') NOT NULL,
  changed_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_status_history_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Ítems del pedido: puede ser un pastel personalizado o un producto adicional
CREATE TABLE order_items (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id        BIGINT UNSIGNED NOT NULL,
  item_type       ENUM('cake','additional_product') NOT NULL,
  cake_id         BIGINT UNSIGNED,               -- si item_type = 'cake'
  additional_product_id BIGINT UNSIGNED,         -- si item_type = 'additional_product'
  quantity        SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  unit_price      DECIMAL(10,2) NOT NULL,
  line_total      DECIMAL(10,2) NOT NULL,
  custom_message  VARCHAR(255),                  -- ej. texto para el pastel
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  CONSTRAINT fk_order_items_cake FOREIGN KEY (cake_id) REFERENCES cakes(id),
  CONSTRAINT fk_order_items_product FOREIGN KEY (additional_product_id) REFERENCES additional_products(id),
  CONSTRAINT chk_order_items_type CHECK (
    (item_type = 'cake' AND cake_id IS NOT NULL AND additional_product_id IS NULL) OR
    (item_type = 'additional_product' AND additional_product_id IS NOT NULL AND cake_id IS NULL)
  )
) ENGINE=InnoDB;

-- Personalización elegida para un pastel dentro de un pedido (tamaño/sabor/relleno)
CREATE TABLE order_item_customizations (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_item_id   BIGINT UNSIGNED NOT NULL,
  cake_size_id    BIGINT UNSIGNED,
  flavor_id       INT UNSIGNED,
  filling_id      INT UNSIGNED,
  CONSTRAINT fk_oic_item FOREIGN KEY (order_item_id) REFERENCES order_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_oic_size FOREIGN KEY (cake_size_id) REFERENCES cake_sizes(id),
  CONSTRAINT fk_oic_flavor FOREIGN KEY (flavor_id) REFERENCES flavors(id),
  CONSTRAINT fk_oic_filling FOREIGN KEY (filling_id) REFERENCES fillings(id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 8. CLIENTES SATISFECHOS (testimonios públicos)
-- ---------------------------------------------------------------------

CREATE TABLE satisfied_customers (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id     BIGINT UNSIGNED,                 -- opcional: puede vincularse a un cliente real
  display_name  VARCHAR(150) NOT NULL,
  photo_url     VARCHAR(500),
  testimonial   TEXT NOT NULL,
  rating        TINYINT UNSIGNED CHECK (rating BETWEEN 1 AND 5),
  cake_id       BIGINT UNSIGNED,                  -- pastel relacionado, opcional
  is_featured   BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_satisfied_customers_client FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
  CONSTRAINT fk_satisfied_customers_cake FOREIGN KEY (cake_id) REFERENCES cakes(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 9. ÍNDICES ADICIONALES PARA RENDIMIENTO
-- ---------------------------------------------------------------------

CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_delivery_datetime ON orders(delivery_datetime);
CREATE INDEX idx_cakes_active ON cakes(is_active);
CREATE INDEX idx_additional_products_active ON additional_products(is_active);
CREATE INDEX idx_promotions_active_dates ON promotions(is_active, start_date, end_date);
CREATE INDEX idx_satisfied_customers_featured ON satisfied_customers(is_featured);

-- ---------------------------------------------------------------------
-- 10. SEMILLA MÍNIMA (los 10 temas predisñados)
-- ---------------------------------------------------------------------

INSERT INTO themes (id, name, description, is_custom, is_active_default) VALUES
  ('dulce-suspiro',    'Dulce Suspiro',    'Rosa pastel suave, delicado y romántico.', FALSE, TRUE),
  ('chocolate-premium','Chocolate Premium','Tonos cacao y crema, elegante y cálido.',  FALSE, FALSE),
  ('lavanda',          'Lavanda',          'Violeta suave y sereno.',                  FALSE, FALSE),
  ('fresa',            'Fresa',            'Rojo fresa vibrante y juvenil.',           FALSE, FALSE),
  ('durazno',          'Durazno',          'Naranja melocotón cálido.',                FALSE, FALSE),
  ('menta',            'Menta',            'Verde menta fresco y moderno.',            FALSE, FALSE),
  ('arandano',         'Arándano',         'Azul índigo profundo y elegante.',         FALSE, FALSE),
  ('fiesta',           'Fiesta',           'Magenta y amarillo vibrantes.',            FALSE, FALSE),
  ('dorado-elegante',  'Dorado Elegante',  'Negro y dorado, lujo y sofisticación.',    FALSE, FALSE),
  ('cielo',            'Cielo',            'Azul cielo claro y optimista.',            FALSE, FALSE);

-- Nota: los valores RGB de cada tema (tabla theme_colors) se insertan desde
-- el backend a partir de src/themes/themes.js para mantener una sola fuente
-- de verdad durante la fase de diseño. En producción, themes.js pasa a ser
-- solo el fallback/caché del frontend y la base de datos es la fuente real.

-- Configuración inicial (la contraseña real se define en la primera
-- ejecución del asistente de configuración, nunca queda fija aquí).
INSERT INTO admin_settings (id, business_name, password_hash, active_theme_id)
VALUES (1, 'Pastelería Lorenita', '<<HASH_GENERADO_EN_PRIMER_INICIO>>', 'dulce-suspiro');
