import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage'

// -----------------------------------------------------------------------
// Configuración real de Firebase del proyecto "pasteleria-lorenita".
// La apiKey de un proyecto web de Firebase NO es secreta por diseño (así
// funciona el SDK de Firebase para clientes): la protección real de los
// datos vive en las reglas de seguridad de Firestore/Storage
// (ver /firestore.rules y /storage.rules en la raíz del proyecto), no en
// ocultar esta configuración. Aun así, evita subir este archivo a un
// repositorio público sin revisar antes esas reglas.
// -----------------------------------------------------------------------
const firebaseConfig = {
  apiKey: 'AIzaSyA68AaQcBJdtyKBc33auE8e9ov6KoLglyM',
  authDomain: 'pasteleria-lorenita.firebaseapp.com',
  projectId: 'pasteleria-lorenita',
  storageBucket: 'pasteleria-lorenita.firebasestorage.app',
  messagingSenderId: '842575460976',
  appId: '1:842575460976:web:effb855b98a7aba11b92b5',
  measurementId: 'G-W18TWN4TDB'
}

export const firebaseApp = initializeApp(firebaseConfig)
export const db = getFirestore(firebaseApp)
export const storage = getStorage(firebaseApp)

// Analytics solo funciona en un navegador real con soporte de medición
// (no en SSR, y puede fallar si el usuario bloquea trackers). Se carga de
// forma perezosa y silenciosa para que nunca rompa el arranque de la app.
export async function initAnalyticsIfSupported() {
  try {
    const { getAnalytics, isSupported } = await import('firebase/analytics')
    if (await isSupported()) {
      return getAnalytics(firebaseApp)
    }
  } catch {
    // Analytics es opcional: cualquier fallo aquí se ignora a propósito.
  }
  return null
}
