import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  onAuthStateChanged,
  signOut
} from 'firebase/auth'
import { doc, getDoc, setDoc } from 'firebase/firestore'
import { firebaseApp, db } from './config'

// -----------------------------------------------------------------------
// El negocio pide "solo contraseña, sin usuario". Por dentro, para lograr
// seguridad real (en vez de comparar texto plano guardado en la base de
// datos, que cualquiera con la configuración de Firebase podría leer),
// se usa Firebase Authentication con una cuenta técnica fija que la
// persona nunca ve ni escribe. Firebase Auth se encarga de:
//   - Guardar la contraseña con hash seguro (nunca en texto plano).
//   - Bloquear automáticamente intentos repetidos de fuerza bruta
//     (error "auth/too-many-requests" tras varios intentos fallidos).
// Esto es real protección de backend, no una simulación de frontend.
// -----------------------------------------------------------------------

const ADMIN_EMAIL = 'admin@pasteleria-lorenita.internal'
const BUSINESS_REF = ['settings', 'business']

export const auth = getAuth(firebaseApp)

async function isBootstrapped() {
  const snap = await getDoc(doc(db, ...BUSINESS_REF))
  return snap.exists() && snap.data().adminBootstrapped === true
}

async function markBootstrapped() {
  await setDoc(doc(db, ...BUSINESS_REF), { adminBootstrapped: true }, { merge: true })
}

// Intenta iniciar sesión. La PRIMERA vez que se usa el panel (todavía no
// existe la cuenta interna en Firebase Auth), se acepta únicamente la
// contraseña inicial documentada (LOREILI) para crear esa cuenta. Después
// de ese primer uso, solo sirve la contraseña real ya configurada.
export async function adminSignIn(password) {
  const bootstrapped = await isBootstrapped()

  if (!bootstrapped) {
    if (password !== 'LOREILI') {
      return { ok: false, reason: 'invalid-initial-password' }
    }
    await createUserWithEmailAndPassword(auth, ADMIN_EMAIL, password)
    await markBootstrapped()
    return { ok: true }
  }

  try {
    await signInWithEmailAndPassword(auth, ADMIN_EMAIL, password)
    return { ok: true }
  } catch (err) {
    if (err.code === 'auth/too-many-requests') {
      return { ok: false, reason: 'too-many-requests' }
    }
    return { ok: false, reason: 'invalid-password' }
  }
}

export async function adminSignOut() {
  await signOut(auth)
}

export function onAdminAuthStateChanged(callback) {
  return onAuthStateChanged(auth, (user) => callback(!!user))
}

// Cambia la contraseña real (requiere volver a confirmar la actual, como
// exige Firebase Auth antes de permitir cambios sensibles de la cuenta).
export async function adminChangePassword(currentPassword, newPassword) {
  const user = auth.currentUser
  if (!user) return { ok: false, reason: 'not-authenticated' }
  if (!newPassword || newPassword.trim().length < 6) {
    return { ok: false, reason: 'weak-password' }
  }
  try {
    const credential = EmailAuthProvider.credential(ADMIN_EMAIL, currentPassword)
    await reauthenticateWithCredential(user, credential)
    await updatePassword(user, newPassword.trim())
    return { ok: true }
  } catch (err) {
    if (err.code === 'auth/too-many-requests') return { ok: false, reason: 'too-many-requests' }
    return { ok: false, reason: 'invalid-current-password' }
  }
}
