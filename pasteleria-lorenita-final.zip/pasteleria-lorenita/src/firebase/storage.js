import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage'
import { storage } from '../firebase/config'

// Límite conservador para no generar archivos pesados en el panel (pedido
// explícito de "evitar archivos demasiado pesados" y de mitigar subida de
// archivos maliciosos: solo imágenes, y con un tope de tamaño).
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024 // 5 MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']

export function validateImageFile(file) {
  if (!file) return 'No se seleccionó ningún archivo.'
  if (!ALLOWED_TYPES.includes(file.type)) return 'Solo se permiten imágenes JPG, PNG, WEBP o GIF.'
  if (file.size > MAX_FILE_SIZE_BYTES) return 'La imagen no debe superar 5 MB.'
  return null
}

// Sube una imagen a Storage bajo una carpeta lógica (ej. "designs",
// "logos", "testimonials", "products", "promotions") y devuelve su URL
// pública de descarga, lista para guardar en el documento de Firestore
// correspondiente.
export async function uploadImage(file, folder) {
  const error = validateImageFile(file)
  if (error) throw new Error(error)

  const safeName = file.name.replace(/[^a-zA-Z0-9.\-_]/g, '_')
  const path = `${folder}/${Date.now()}-${safeName}`
  const storageRef = ref(storage, path)
  await uploadBytes(storageRef, file)
  const url = await getDownloadURL(storageRef)
  return { url, path }
}

export async function deleteImage(path) {
  if (!path) return
  try {
    await deleteObject(ref(storage, path))
  } catch (err) {
    // No es crítico si ya no existe o falla el borrado del archivo.
    console.warn('No se pudo eliminar la imagen del almacenamiento:', err.message)
  }
}
