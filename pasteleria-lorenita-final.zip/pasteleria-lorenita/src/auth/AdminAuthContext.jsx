import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { adminSignIn, adminSignOut, adminChangePassword, onAdminAuthStateChanged } from '../firebase/auth'

// -----------------------------------------------------------------------
// Puerta de acceso del admin: "solo contraseña, sin usuario" desde la
// interfaz, pero por dentro respaldada por Firebase Authentication real
// (ver src/firebase/auth.js). Esto reemplaza la comparación de texto
// plano usada en bloques anteriores por seguridad real de backend:
// contraseña con hash seguro, y bloqueo automático ante fuerza bruta.
// -----------------------------------------------------------------------

const AdminAuthContext = createContext(null)

const FRIENDLY_MESSAGES = {
  'invalid-initial-password': 'Esa contraseña no es válida. Intenta nuevamente.',
  'invalid-password': 'Esa contraseña no es válida. Intenta nuevamente.',
  'too-many-requests': 'Demasiados intentos fallidos. Espera unos minutos antes de volver a intentarlo.',
  'invalid-current-password': 'La contraseña actual no es correcta.',
  'weak-password': 'La nueva contraseña debe tener al menos 6 caracteres.',
  'not-authenticated': 'Tu sesión expiró. Vuelve a iniciar sesión.'
}

export function AdminAuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authReady, setAuthReady] = useState(false)

  useEffect(() => {
    const unsubscribe = onAdminAuthStateChanged((loggedIn) => {
      setIsAuthenticated(loggedIn)
      setAuthReady(true)
    })
    return unsubscribe
  }, [])

  const login = useCallback(async (password) => {
    const result = await adminSignIn(password)
    if (result.ok) return { ok: true }
    return { ok: false, message: FRIENDLY_MESSAGES[result.reason] || 'No se pudo iniciar sesión. Intenta de nuevo.' }
  }, [])

  const logout = useCallback(async () => {
    await adminSignOut()
  }, [])

  const changePassword = useCallback(async (currentPassword, newPassword) => {
    const result = await adminChangePassword(currentPassword, newPassword)
    if (result.ok) return { ok: true }
    return { ok: false, message: FRIENDLY_MESSAGES[result.reason] || 'No se pudo cambiar la contraseña.' }
  }, [])

  return (
    <AdminAuthContext.Provider value={{ isAuthenticated, authReady, login, logout, changePassword }}>
      {children}
    </AdminAuthContext.Provider>
  )
}

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext)
  if (!ctx) throw new Error('useAdminAuth debe usarse dentro de <AdminAuthProvider>')
  return ctx
}
