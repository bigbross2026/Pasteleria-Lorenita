import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { KeyRound, CakeSlice } from 'lucide-react'
import { useAdminAuth } from '../../auth/AdminAuthContext'
import Button from '../../components/ui/Button'
import Card from '../../components/ui/Card'

export default function Login() {
  const { login } = useAdminAuth()
  const navigate = useNavigate()
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const result = await login(password)
    setLoading(false)
    if (result.ok) {
      navigate('/admin')
    } else {
      setError(result.message)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-5 theme-transition">
      <Card className="w-full max-w-sm text-center">
        <div className="flex justify-center mb-4 text-primary">
          <CakeSlice size={40} strokeWidth={1.5} />
        </div>
        <h1 className="text-2xl font-semibold mb-1">Acceso Administrador</h1>
        <p className="text-sm text-text-muted mb-6">Ingresa la contraseña para continuar</p>

        <form onSubmit={handleSubmit} className="space-y-4 text-left">
          <label className="block">
            <span className="sr-only">Contraseña</span>
            <div className="flex items-center gap-2 rounded-pill border border-secondary px-4 py-3 bg-surface">
              <KeyRound size={18} className="text-text-muted" />
              <input
                type="password"
                autoFocus
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Contraseña"
                className="bg-transparent outline-none flex-1 text-text-main placeholder:text-text-muted"
              />
            </div>
          </label>

          {error && <p className="text-sm text-primary-dark font-medium">{error}</p>}

          <Button type="submit" fullWidth disabled={loading}>
            {loading ? 'Verificando…' : 'Entrar'}
          </Button>
        </form>
      </Card>
    </div>
  )
}
