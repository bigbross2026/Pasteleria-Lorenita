import { useMemo, useState } from 'react'
import { BarChart3, FileDown, ClipboardList, DollarSign, CheckCircle2, Clock3, XCircle } from 'lucide-react'
import AdminModuleHeader from '../../../components/admin/AdminModuleHeader'
import Card from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import StatBarChart from '../../../components/admin/charts/StatBarChart'
import RevenueTrendChart from '../../../components/admin/charts/RevenueTrendChart'
import { useAdminData } from '../../../data/AdminDataContext'
import { getRangeForPeriod, computeReport, computeAllTimeStats, toChartData, computeRevenueTrend } from '../../../utils/reports'
import { formatCurrency } from '../../../utils/pricing'

const PERIODS = [
  { key: 'daily', label: 'Diario' },
  { key: 'weekly', label: 'Semanal' },
  { key: 'monthly', label: 'Mensual' }
]

const TREND_POINTS = { daily: 7, weekly: 8, monthly: 6 }

export default function Reportes() {
  const { orders, categories, business } = useAdminData()
  const [period, setPeriod] = useState('daily')
  const [tab, setTab] = useState('resumen')

  const range = useMemo(() => getRangeForPeriod(period), [period])
  const report = useMemo(() => computeReport(orders, range), [orders, range])
  const allTime = useMemo(() => computeAllTimeStats(orders), [orders])
  const trend = useMemo(() => computeRevenueTrend(orders, period, TREND_POINTS[period]), [orders, period])

  function categoryName(id) {
    return categories.find((c) => c.id === id)?.name || 'Sin categoría'
  }

  const categoryChartData = useMemo(
    () =>
      toChartData(
        Object.fromEntries(Object.entries(allTime.byCategory).map(([id, qty]) => [categoryName(id), qty]))
      ),
    [allTime.byCategory, categories]
  )

  async function exportPdf() {
    const { jsPDF } = await import('jspdf')
    const doc = new jsPDF()
    const marginX = 18
    let y = 22

    // Encabezado con el logotipo real (si ya fue cargado en Configuración)
    // o, mientras tanto, un círculo con la inicial del negocio.
    let logoDrawn = false
    if (business.logoUrl) {
      try {
        const response = await fetch(business.logoUrl)
        const blob = await response.blob()
        const dataUrl = await new Promise((resolve, reject) => {
          const reader = new FileReader()
          reader.onload = () => resolve(reader.result)
          reader.onerror = reject
          reader.readAsDataURL(blob)
        })
        doc.addImage(dataUrl, marginX, y - 9, 12, 12)
        logoDrawn = true
      } catch (err) {
        console.warn('No se pudo incluir el logotipo en el PDF:', err.message)
      }
    }
    if (!logoDrawn) {
      doc.setFillColor(224, 55, 84)
      doc.circle(marginX + 5, y - 3, 6, 'F')
      doc.setTextColor(255, 255, 255)
      doc.setFontSize(12)
      doc.text(business.businessName.charAt(0), marginX + 5, y - 0.5, { align: 'center' })
    }

    doc.setTextColor(40, 40, 40)
    doc.setFontSize(16)
    doc.text(business.businessName, marginX + 16, y - 1)
    doc.setFontSize(10)
    doc.setTextColor(120, 120, 120)
    y += 8
    doc.text(`Reporte ${PERIODS.find((p) => p.key === period).label.toLowerCase()} — generado el ${new Date().toLocaleDateString('es-ES')}`, marginX, y)

    y += 10
    doc.setDrawColor(230, 230, 230)
    doc.line(marginX, y, 192, y)
    y += 10

    doc.setTextColor(40, 40, 40)
    doc.setFontSize(13)
    doc.text('Resumen general', marginX, y)
    y += 7
    doc.setFontSize(11)
    doc.text(`Pedidos: ${report.orderCount}`, marginX, y)
    y += 6
    doc.text(`Ingresos totales: ${formatCurrency(report.totalRevenue)}`, marginX, y)
    y += 10

    doc.setFontSize(13)
    doc.text('Ventas por categoría', marginX, y)
    y += 7
    doc.setFontSize(10)
    const catEntries = Object.entries(report.byCategory)
    if (catEntries.length === 0) {
      doc.text('Sin ventas en este período.', marginX, y)
      y += 6
    } else {
      catEntries.forEach(([id, data]) => {
        doc.text(`${categoryName(id)}: ${data.qty} unidad(es) — ${formatCurrency(data.revenue)}`, marginX, y)
        y += 6
      })
    }
    y += 4

    doc.setFontSize(13)
    doc.text('Promociones vendidas', marginX, y)
    y += 7
    doc.setFontSize(10)
    const promoEntries = Object.values(report.byPromotion)
    if (promoEntries.length === 0) {
      doc.text('Sin promociones vendidas en este período.', marginX, y)
      y += 6
    } else {
      promoEntries.forEach((data) => {
        doc.text(`${data.title}: ${data.qty} — ${formatCurrency(data.revenue)}`, marginX, y)
        y += 6
      })
    }
    y += 4

    doc.setFontSize(13)
    doc.text('Productos adicionales vendidos', marginX, y)
    y += 7
    doc.setFontSize(10)
    const addonEntries = Object.values(report.byAdditionalProduct)
    if (addonEntries.length === 0) {
      doc.text('Sin productos adicionales vendidos en este período.', marginX, y)
      y += 6
    } else {
      addonEntries.forEach((data) => {
        doc.text(`${data.name}: ${data.qty} unidad(es) — ${formatCurrency(data.revenue)}`, marginX, y)
        y += 6
      })
    }

    doc.save(`reporte-${period}-${new Date().toISOString().slice(0, 10)}.pdf`)
  }

  return (
    <div>
      <AdminModuleHeader title="Reportes" icon={BarChart3} description="Estadísticas agrupadas de ventas e ingresos." />

      <div className="flex gap-2 mb-6 flex-wrap">
        <button
          onClick={() => setTab('resumen')}
          className={`px-4 py-2 rounded-pill text-sm font-semibold transition-colors ${
            tab === 'resumen' ? 'bg-primary text-button-text' : 'bg-surface text-text-main'
          }`}
        >
          Resumen por período
        </button>
        <button
          onClick={() => setTab('estadisticas')}
          className={`px-4 py-2 rounded-pill text-sm font-semibold transition-colors ${
            tab === 'estadisticas' ? 'bg-primary text-button-text' : 'bg-surface text-text-main'
          }`}
        >
          Estadísticas generales
        </button>
      </div>

      {tab === 'resumen' && (
        <>
          <div className="flex gap-2 mb-6">
            {PERIODS.map((p) => (
              <button
                key={p.key}
                onClick={() => setPeriod(p.key)}
                className={`px-4 py-2 rounded-pill text-sm font-semibold transition-colors ${
                  period === p.key ? 'bg-primary text-button-text' : 'bg-surface text-text-main'
                }`}
              >
                {p.label}
              </button>
            ))}
            <Button size="sm" variant="secondary" icon={FileDown} onClick={exportPdf} className="ml-auto">
              Exportar PDF
            </Button>
          </div>

          <div className="grid sm:grid-cols-2 gap-4 mb-6">
            <Card className="flex items-center gap-4">
              <ClipboardList size={32} className="text-primary" />
              <div>
                <p className="text-2xl font-display font-bold">{report.orderCount}</p>
                <p className="text-sm text-text-muted">Pedidos en el período</p>
              </div>
            </Card>
            <Card className="flex items-center gap-4">
              <DollarSign size={32} className="text-primary" />
              <div>
                <p className="text-2xl font-display font-bold">{formatCurrency(report.totalRevenue)}</p>
                <p className="text-sm text-text-muted">Ingresos totales</p>
              </div>
            </Card>
          </div>

          <Card className="mb-4">
            <h3 className="font-semibold mb-3">Tendencia de ingresos</h3>
            <RevenueTrendChart data={trend} />
          </Card>

          <Card className="mb-4">
            <h3 className="font-semibold mb-3">Ventas por categoría</h3>
            {Object.keys(report.byCategory).length === 0 ? (
              <p className="text-sm text-text-muted">Sin ventas en este período.</p>
            ) : (
              <div className="space-y-2">
                {Object.entries(report.byCategory).map(([id, data]) => (
                  <div key={id} className="flex justify-between text-sm">
                    <span>{categoryName(id)}</span>
                    <span className="text-text-muted">{data.qty} unidad(es) — {formatCurrency(data.revenue)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card className="mb-4">
            <h3 className="font-semibold mb-3">Promociones vendidas</h3>
            {Object.keys(report.byPromotion).length === 0 ? (
              <p className="text-sm text-text-muted">Sin promociones vendidas en este período.</p>
            ) : (
              <div className="space-y-2">
                {Object.values(report.byPromotion).map((data, i) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span>{data.title}</span>
                    <span className="text-text-muted">{data.qty} — {formatCurrency(data.revenue)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>

          <Card>
            <h3 className="font-semibold mb-3">Productos adicionales vendidos</h3>
            {Object.keys(report.byAdditionalProduct).length === 0 ? (
              <p className="text-sm text-text-muted">Sin productos adicionales vendidos en este período.</p>
            ) : (
              <div className="space-y-2">
                {Object.values(report.byAdditionalProduct).map((data, i) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span>{data.name}</span>
                    <span className="text-text-muted">{data.qty} unidad(es) — {formatCurrency(data.revenue)}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </>
      )}

      {tab === 'estadisticas' && (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
            <Card className="text-center">
              <ClipboardList size={24} className="mx-auto mb-2 text-primary" />
              <p className="text-xl font-display font-bold">{allTime.total}</p>
              <p className="text-xs text-text-muted">Total de pedidos</p>
            </Card>
            <Card className="text-center">
              <CheckCircle2 size={24} className="mx-auto mb-2 text-primary" />
              <p className="text-xl font-display font-bold">{allTime.delivered}</p>
              <p className="text-xs text-text-muted">Entregados</p>
            </Card>
            <Card className="text-center">
              <Clock3 size={24} className="mx-auto mb-2 text-primary" />
              <p className="text-xl font-display font-bold">{allTime.pending}</p>
              <p className="text-xs text-text-muted">Pendientes</p>
            </Card>
            <Card className="text-center">
              <XCircle size={24} className="mx-auto mb-2 text-primary" />
              <p className="text-xl font-display font-bold">{allTime.cancelled}</p>
              <p className="text-xs text-text-muted">Cancelados</p>
            </Card>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <Card>
              <h3 className="font-semibold mb-3">Pasteles más vendidos</h3>
              <StatBarChart data={toChartData(allTime.byCake)} emptyText="Todavía no hay pedidos entregados o pendientes." />
            </Card>
            <Card>
              <h3 className="font-semibold mb-3">Categorías más utilizadas</h3>
              <StatBarChart data={categoryChartData} />
            </Card>
            <Card>
              <h3 className="font-semibold mb-3">Sabores más elegidos</h3>
              <StatBarChart data={toChartData(allTime.byFlavor)} />
            </Card>
            <Card>
              <h3 className="font-semibold mb-3">Rellenos más elegidos</h3>
              <StatBarChart data={toChartData(allTime.byFilling)} />
            </Card>
            <Card>
              <h3 className="font-semibold mb-3">Tamaños más vendidos</h3>
              <StatBarChart data={toChartData(allTime.bySize)} />
            </Card>
            <Card>
              <h3 className="font-semibold mb-3">Productos adicionales más vendidos</h3>
              <StatBarChart data={toChartData(allTime.byAdditionalProduct)} />
            </Card>
            <Card className="sm:col-span-2">
              <h3 className="font-semibold mb-3">Promociones con mayor éxito</h3>
              <StatBarChart data={toChartData(allTime.byPromotion)} />
            </Card>
          </div>
        </>
      )}
    </div>
  )
}
