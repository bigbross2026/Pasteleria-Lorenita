import { useState } from 'react'
import { CakeSlice, Tags, IceCreamCone, Layers, Ruler } from 'lucide-react'
import AdminModuleHeader from '../../../../components/admin/AdminModuleHeader'
import SimpleListManager from '../../../../components/admin/SimpleListManager'
import CategoriesTab from './CategoriesTab'
import { useAdminData } from '../../../../data/AdminDataContext'

const TABS = [
  { key: 'categorias', label: 'Categorías', icon: Tags },
  { key: 'sabores', label: 'Sabores', icon: IceCreamCone },
  { key: 'rellenos', label: 'Rellenos', icon: Layers },
  { key: 'tamanos', label: 'Tamaños', icon: Ruler }
]

export default function Pasteles() {
  const { flavors, flavorOps, fillings, fillingOps, sizes, sizeOps } = useAdminData()
  const [tab, setTab] = useState('categorias')

  return (
    <div>
      <AdminModuleHeader
        title="Pasteles"
        icon={CakeSlice}
        description="Categorías, fotografías, sabores, rellenos y tamaños del catálogo."
      />

      <div className="flex gap-2 mb-6 flex-wrap">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-pill text-sm font-semibold transition-colors ${
              tab === key ? 'bg-primary text-button-text' : 'bg-surface text-text-main'
            }`}
          >
            <Icon size={16} /> {label}
          </button>
        ))}
      </div>

      {tab === 'categorias' && <CategoriesTab />}

      {tab === 'sabores' && (
        <SimpleListManager
          items={flavors}
          ops={flavorOps}
          fields={[{ key: 'name', label: 'Nombre del sabor', type: 'text' }]}
          emptyState="Aún no hay sabores registrados."
        />
      )}

      {tab === 'rellenos' && (
        <SimpleListManager
          items={fillings}
          ops={fillingOps}
          fields={[{ key: 'name', label: 'Nombre del relleno', type: 'text' }]}
          emptyState="Aún no hay rellenos registrados."
        />
      )}

      {tab === 'tamanos' && (
        <SimpleListManager
          items={sizes}
          ops={sizeOps}
          fields={[
            { key: 'label', label: 'Ej. 12 porciones', type: 'text' },
            { key: 'price', label: 'Precio', type: 'number', suffix: '$' }
          ]}
          emptyState="Aún no hay tamaños registrados."
        />
      )}
    </div>
  )
}
