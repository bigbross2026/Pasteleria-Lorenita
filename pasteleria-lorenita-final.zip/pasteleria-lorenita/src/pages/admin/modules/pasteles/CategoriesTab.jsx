import { useState } from 'react'
import {
  Plus, Pencil, Trash2, Power, ImagePlus, ChevronDown, ChevronUp, Eye, EyeOff, ArrowRightLeft, Loader2
} from 'lucide-react'
import Button from '../../../../components/ui/Button'
import Card from '../../../../components/ui/Card'
import Modal from '../../../../components/common/Modal'
import ConfirmChoiceDialog from '../../../../components/admin/ConfirmChoiceDialog'
import CakeVisual from '../../../../components/order/CakeVisual'
import { useAdminData } from '../../../../data/AdminDataContext'
import { useNotify } from '../../../../context/NotificationContext'
import { sanitizeText, isNonEmpty, isPositiveNumber } from '../../../../utils/validation'
import { uploadImage, deleteImage, validateImageFile } from '../../../../firebase/storage'

function hexToRgbString(hex) {
  const r = parseInt(hex.slice(1, 3), 16)
  const g = parseInt(hex.slice(3, 5), 16)
  const b = parseInt(hex.slice(5, 7), 16)
  return `${r} ${g} ${b}`
}

function CategoryForm({ initial, onCancel, onSave }) {
  const [name, setName] = useState(initial?.name || '')
  const [emoji, setEmoji] = useState(initial?.emoji || '⭐')
  const [frameColor, setFrameColor] = useState(initial?.frameColor || '212 175 92')
  const [surcharge, setSurcharge] = useState(initial?.surcharge ?? 5)

  const valid = isNonEmpty(name) && isPositiveNumber(surcharge)

  return (
    <Card className="mb-4">
      <div className="flex flex-wrap gap-3 items-center">
        <input
          value={emoji}
          onChange={(e) => setEmoji(e.target.value.slice(0, 2))}
          className="w-14 text-center rounded-pill border border-secondary py-2 bg-surface outline-none"
          placeholder="🎂"
        />
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Nombre de la categoría"
          className="flex-1 min-w-[160px] rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
        <label className="flex items-center gap-2 text-sm">
          Marco
          <input
            type="color"
            defaultValue="#d4af5c"
            onChange={(e) => setFrameColor(hexToRgbString(e.target.value))}
            className="h-9 w-11 rounded cursor-pointer border border-secondary"
          />
        </label>
        <label className="flex items-center gap-2 text-sm">
          Recargo $
          <input
            type="number"
            min="0"
            value={surcharge}
            onChange={(e) => setSurcharge(e.target.value)}
            className="w-20 rounded-pill border border-secondary px-3 py-2 bg-surface outline-none"
          />
        </label>
      </div>
      <div className="flex gap-2 mt-4">
        <Button
          size="sm"
          disabled={!valid}
          onClick={() =>
            onSave({ name: sanitizeText(name, 40), emoji, frameColor, surcharge: Number(surcharge) })
          }
        >
          Guardar
        </Button>
        <Button size="sm" variant="secondary" onClick={onCancel}>
          Cancelar
        </Button>
      </div>
    </Card>
  )
}

export default function CategoriesTab() {
  const { categories, categoryOps, designs, designOps } = useAdminData()
  const { notify } = useNotify()
  const [creating, setCreating] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [expandedId, setExpandedId] = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [lightboxCake, setLightboxCake] = useState(null)
  const [uploadingCount, setUploadingCount] = useState(0)

  const orphanDesigns = designs.filter((d) => !categories.some((c) => c.id === d.categoryId))

  function handleCreate(data) {
    categoryOps.add({ ...data, status: 'active' })
    notify('success', `Categoría "${data.name}" creada correctamente.`)
    setCreating(false)
  }

  function handleUpdate(id, data) {
    categoryOps.update(id, data)
    notify('success', `Categoría "${data.name}" actualizada.`)
    setEditingId(null)
  }

  function toggleCategoryStatus(cat) {
    categoryOps.update(cat.id, { status: cat.status === 'active' ? 'silenced' : 'active' })
  }

  function requestDelete(cat) {
    const photoCount = designs.filter((d) => d.categoryId === cat.id).length
    if (photoCount === 0) {
      if (window.confirm(`¿Eliminar la categoría "${cat.name}"?`)) categoryOps.remove(cat.id)
      return
    }
    setDeleteTarget(cat)
  }

  async function handleBulkUpload(categoryId, fileList) {
    const files = Array.from(fileList || [])
    setUploadingCount(files.length)
    let uploaded = 0
    for (const file of files) {
      const validationError = validateImageFile(file)
      if (validationError) {
        notify('error', `"${file.name}" no se subió: ${validationError}`)
        setUploadingCount((n) => Math.max(0, n - 1))
        continue
      }
      try {
        const { url, path } = await uploadImage(file, `designs/${categoryId}`)
        await designOps.add({
          name: file.name.replace(/\.[^/.]+$/, '') || 'Nuevo diseño',
          categoryId,
          status: 'active',
          imageUrl: url,
          storagePath: path
        })
        uploaded += 1
      } catch (err) {
        notify('error', `No se pudo subir "${file.name}": ${err.message}`)
      } finally {
        setUploadingCount((n) => Math.max(0, n - 1))
      }
    }
    if (uploaded > 0) notify('success', `${uploaded} fotografía(s) agregada(s) correctamente.`)
  }

  function togglePhotoStatus(design) {
    designOps.update(design.id, { status: design.status === 'active' ? 'silenced' : 'active' })
  }

  function movePhoto(design, newCategoryId) {
    designOps.update(design.id, { categoryId: newCategoryId })
  }

  return (
    <div>
      <div className="space-y-3 mb-4">
        {categories.map((cat) => {
          const photos = designs.filter((d) => d.categoryId === cat.id)
          const isExpanded = expandedId === cat.id
          return (
            <Card key={cat.id}>
              {editingId === cat.id ? (
                <CategoryForm
                  initial={cat}
                  onCancel={() => setEditingId(null)}
                  onSave={(data) => handleUpdate(cat.id, data)}
                />
              ) : (
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-3">
                    <span
                      className="h-9 w-9 rounded-full flex items-center justify-center text-lg"
                      style={{ backgroundColor: `rgb(${cat.frameColor})` }}
                    >
                      {cat.emoji}
                    </span>
                    <div>
                      <p className="font-semibold flex items-center gap-2">
                        {cat.name}
                        {cat.status !== 'active' && (
                          <span className="text-xs bg-secondary text-text-muted px-2 py-0.5 rounded-pill">Silenciada</span>
                        )}
                      </p>
                      <p className="text-xs text-text-muted">Recargo: ${cat.surcharge} · {photos.length} foto(s)</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button onClick={() => setExpandedId(isExpanded ? null : cat.id)} className="text-text-muted hover:text-primary" title="Ver fotos">
                      {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                    </button>
                    <button onClick={() => toggleCategoryStatus(cat)} className="text-text-muted hover:text-primary" title="Activar/Silenciar">
                      <Power size={18} />
                    </button>
                    <button onClick={() => setEditingId(cat.id)} className="text-text-muted hover:text-primary" title="Editar">
                      <Pencil size={18} />
                    </button>
                    <button onClick={() => requestDelete(cat)} className="text-text-muted hover:text-primary" title="Eliminar">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              )}

              {isExpanded && (
                <div className="mt-4 pt-4 border-t border-secondary">
                  <label className="inline-flex items-center gap-2 text-sm font-medium text-primary cursor-pointer mb-4">
                    {uploadingCount > 0 ? <Loader2 size={18} className="animate-spin" /> : <ImagePlus size={18} />}
                    {uploadingCount > 0 ? `Subiendo ${uploadingCount} foto(s)…` : 'Subir fotografías (varias a la vez)'}
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      disabled={uploadingCount > 0}
                      onChange={(e) => {
                        handleBulkUpload(cat.id, e.target.files)
                        e.target.value = ''
                      }}
                    />
                  </label>

                  {photos.length === 0 ? (
                    <p className="text-sm text-text-muted">Aún no hay fotografías en esta categoría.</p>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {photos.map((photo) => (
                        <div key={photo.id} className="relative">
                          <button onClick={() => setLightboxCake(photo)} className="block w-full">
                            <CakeVisual cake={photo} aspect="aspect-square" />
                          </button>
                          {photo.status !== 'active' && (
                            <span className="absolute top-1 right-1 bg-secondary text-[10px] px-1.5 py-0.5 rounded-pill">Oculta</span>
                          )}
                          <div className="flex items-center justify-center gap-2 mt-1">
                            <button onClick={() => togglePhotoStatus(photo)} title="Silenciar/Mostrar" className="text-text-muted hover:text-primary">
                              {photo.status === 'active' ? <Eye size={16} /> : <EyeOff size={16} />}
                            </button>
                            <select
                              value={photo.categoryId}
                              onChange={(e) => movePhoto(photo, e.target.value)}
                              title="Mover a otra categoría"
                              className="text-xs rounded-pill border border-secondary bg-surface px-1 py-0.5"
                            >
                              {categories.map((c) => (
                                <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>
                              ))}
                            </select>
                            <button
                              onClick={() => {
                                if (window.confirm(`¿Eliminar "${photo.name}"?`)) {
                                  designOps.remove(photo.id)
                                  if (photo.storagePath) deleteImage(photo.storagePath)
                                }
                              }}
                              title="Eliminar"
                              className="text-text-muted hover:text-primary"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </Card>
          )
        })}
      </div>

      {creating ? (
        <CategoryForm onCancel={() => setCreating(false)} onSave={handleCreate} />
      ) : (
        <Button size="sm" variant="secondary" icon={Plus} onClick={() => setCreating(true)}>
          Nueva categoría
        </Button>
      )}

      {orphanDesigns.length > 0 && (
        <Card className="mt-6">
          <p className="font-semibold mb-1 flex items-center gap-2">
            <ArrowRightLeft size={18} className="text-primary" /> Fotos sin categoría
          </p>
          <p className="text-sm text-text-muted mb-3">
            Estas fotos pertenecían a una categoría eliminada. Muévelas a otra para que vuelvan a ser visibles.
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {orphanDesigns.map((photo) => (
              <div key={photo.id}>
                <CakeVisual cake={{ ...photo, categoryId: null }} aspect="aspect-square" />
                <select
                  defaultValue=""
                  onChange={(e) => e.target.value && movePhoto(photo, e.target.value)}
                  className="mt-1 w-full text-xs rounded-pill border border-secondary bg-surface px-1 py-1"
                >
                  <option value="" disabled>Mover a…</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Modal open={!!lightboxCake} onClose={() => setLightboxCake(null)} size="lg">
        {lightboxCake && <CakeVisual cake={lightboxCake} aspect="aspect-[4/3]" big />}
      </Modal>

      <ConfirmChoiceDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        title={`Eliminar "${deleteTarget?.name}"`}
        description="Esta categoría tiene fotografías asociadas. ¿Qué deseas hacer con ellas?"
        choices={
          deleteTarget
            ? [
                {
                  label: 'Eliminar categoría y todas sus fotos',
                  variant: 'primary',
                  onSelect: () => {
                    const toRemove = designs.filter((d) => d.categoryId === deleteTarget.id)
                    designOps.removeMany(toRemove.map((d) => d.id))
                    toRemove.forEach((d) => d.storagePath && deleteImage(d.storagePath))
                    categoryOps.remove(deleteTarget.id)
                  }
                },
                {
                  label: 'Eliminar solo la categoría (conservar fotos)',
                  variant: 'secondary',
                  onSelect: () => categoryOps.remove(deleteTarget.id)
                }
              ]
            : []
        }
      />
    </div>
  )
}
