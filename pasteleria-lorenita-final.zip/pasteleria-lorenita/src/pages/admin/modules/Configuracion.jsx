import { useState } from 'react'
import { Eye, Check, Palette, Plus, Settings2, Store, ToggleLeft, Database } from 'lucide-react'
import { useTheme } from '../../../themes/ThemeContext'
import Card from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import AdminModuleHeader from '../../../components/admin/AdminModuleHeader'
import PasswordSection from './configuracion/PasswordSection'
import BusinessInfoSection from './configuracion/BusinessInfoSection'
import ModulesSection from './configuracion/ModulesSection'
import BackupSection from './configuracion/BackupSection'

function ThemeCard({ theme, isActive, onPreview, onApply }) {
  const swatchRoles = ['primary', 'secondary', 'accent', 'background', 'header']

  return (
    <Card className={isActive ? 'ring-2 ring-primary' : ''}>
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-text-main">{theme.name}</h3>
        {isActive && (
          <span className="flex items-center gap-1 text-xs font-semibold text-primary">
            <Check size={14} /> Activo
          </span>
        )}
      </div>

      {theme.description && <p className="text-xs text-text-muted mb-3">{theme.description}</p>}

      <div className="flex gap-2 mb-4">
        {swatchRoles.map((role) => (
          <span
            key={role}
            className="h-7 w-7 rounded-full border border-black/5"
            style={{ backgroundColor: `rgb(${theme.colors[role]})` }}
            title={role}
          />
        ))}
      </div>

      {/* Miniatura simplificada de cómo luce la app con este tema */}
      <div
        className="rounded-xl overflow-hidden mb-4 border border-black/5"
        style={{ backgroundColor: `rgb(${theme.colors.background})` }}
      >
        <div className="h-6" style={{ backgroundColor: `rgb(${theme.colors.header})` }} />
        <div className="p-3 space-y-2">
          <div className="h-3 w-2/3 rounded" style={{ backgroundColor: `rgb(${theme.colors.text})`, opacity: 0.8 }} />
          <div className="h-2 w-1/2 rounded" style={{ backgroundColor: `rgb(${theme.colors.textMuted})` }} />
          <div
            className="h-6 w-20 rounded-pill"
            style={{ backgroundColor: `rgb(${theme.colors.primary})` }}
          />
        </div>
      </div>

      <div className="flex gap-2">
        <Button size="sm" variant="secondary" icon={Eye} onClick={() => onPreview(theme.id)} className="flex-1">
          Vista previa
        </Button>
        <Button size="sm" onClick={() => onApply(theme.id)} className="flex-1">
          Aplicar
        </Button>
      </div>
    </Card>
  )
}

const TABS = [
  { key: 'general', label: 'General', icon: Store },
  { key: 'modulos', label: 'Módulos', icon: ToggleLeft },
  { key: 'temas', label: 'Temas', icon: Palette },
  { key: 'personalizado', label: 'Tema personalizado', icon: Plus },
  { key: 'respaldo', label: 'Respaldo', icon: Database }
]

export default function Configuracion() {
  const { themes, activeThemeId, previewTheme, applyTheme } = useTheme()
  const [tab, setTab] = useState('general')

  return (
    <div>
      <AdminModuleHeader
        title="Configuración"
        icon={Settings2}
        description="Datos del negocio, módulos activos, apariencia y respaldo de la información."
      />

      <div className="flex gap-2 mb-6 flex-wrap">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-pill text-sm font-semibold transition-colors ${
              tab === key ? 'bg-primary text-button-text' : 'bg-surface text-text-main'
            }`}
          >
            <Icon size={16} /> {label}
          </button>
        ))}
      </div>

      {tab === 'general' && (
        <div className="space-y-4">
          <BusinessInfoSection />
          <PasswordSection />
        </div>
      )}

      {tab === 'modulos' && <ModulesSection />}

      {tab === 'temas' && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {themes.map((theme) => (
            <ThemeCard
              key={theme.id}
              theme={theme}
              isActive={theme.id === activeThemeId}
              onPreview={(id) => previewTheme(id, 5000)}
              onApply={applyTheme}
            />
          ))}
        </div>
      )}

      {tab === 'personalizado' && <CustomThemeEditor />}

      {tab === 'respaldo' && <BackupSection />}
    </div>
  )
}

// Editor simple para crear/editar un tema propio. Se guarda con
// saveCustomTheme y queda disponible junto a los temas predisñados.
function CustomThemeEditor() {
  const { saveCustomTheme, applyTheme } = useTheme()
  const [name, setName] = useState('')
  const [colors, setColors] = useState({
    primary: '224 55 84',
    primaryDark: '182 36 62',
    secondary: '255 205 210',
    accent: '255 132 149',
    background: '255 248 248',
    surface: '255 233 235',
    card: '255 255 255',
    header: '255 225 228',
    text: '77 28 34',
    textMuted: '158 90 98',
    buttonText: '255 255 255'
  })

  function updateColor(role, hexOrRgb) {
    setColors((prev) => ({ ...prev, [role]: hexOrRgb }))
  }

  function handleSave() {
    if (!name.trim()) return
    const id = `custom-${name.trim().toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`
    const theme = { id, name: name.trim(), description: 'Tema personalizado', colors, isCustom: true }
    saveCustomTheme(theme)
    applyTheme(id)
  }

  const roleLabels = {
    primary: 'Principal',
    primaryDark: 'Principal (oscuro)',
    secondary: 'Secundario',
    accent: 'Acento',
    background: 'Fondo',
    surface: 'Superficie',
    card: 'Tarjetas',
    header: 'Encabezado',
    text: 'Texto',
    textMuted: 'Texto secundario',
    buttonText: 'Texto de botones'
  }

  return (
    <Card className="max-w-xl">
      <label className="block mb-4">
        <span className="text-sm font-semibold text-text-main">Nombre del tema</span>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ej. Cumpleaños Azul"
          className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
      </label>

      <div className="grid grid-cols-2 gap-4 mb-6">
        {Object.entries(roleLabels).map(([role, label]) => (
          <label key={role} className="flex items-center justify-between gap-2 text-sm">
            <span className="text-text-main">{label}</span>
            <input
              type="color"
              // El input color usa hex; convertimos a "r g b" al guardar.
              onChange={(e) => {
                const hex = e.target.value
                const r = parseInt(hex.slice(1, 3), 16)
                const g = parseInt(hex.slice(3, 5), 16)
                const b = parseInt(hex.slice(5, 7), 16)
                updateColor(role, `${r} ${g} ${b}`)
              }}
              className="h-8 w-10 rounded cursor-pointer border border-secondary"
            />
          </label>
        ))}
      </div>

      <Button onClick={handleSave} disabled={!name.trim()}>
        Guardar y aplicar tema
      </Button>
    </Card>
  )
}
