import { useState } from 'react'
import { ShoppingBag, Plus, Pencil, Trash2, Power, X } from 'lucide-react'
import AdminModuleHeader from '../../../components/admin/AdminModuleHeader'
import ModuleVisibilityToggle from './ModuleVisibilityToggle'
import ImageUploadField from '../../../components/admin/ImageUploadField'
import Card from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import PlaceholderMedia from '../../../components/ui/PlaceholderMedia'
import { useAdminData } from '../../../data/AdminDataContext'
import { sanitizeText, isNonEmpty, isPositiveNumber } from '../../../utils/validation'

function emptyProduct() {
  return { name: '', description: '', imageUrl: null, tiers: [{ qty: 10, price: 0 }] }
}

function ProductForm({ initial, onCancel, onSave }) {
  const [draft, setDraft] = useState(initial ? { ...initial, tiers: [...initial.tiers] } : emptyProduct())

  function updateTier(index, key, value) {
    setDraft((d) => {
      const tiers = [...d.tiers]
      tiers[index] = { ...tiers[index], [key]: value }
      return { ...d, tiers }
    })
  }

  function addTier() {
    setDraft((d) => ({ ...d, tiers: [...d.tiers, { qty: 0, price: 0 }] }))
  }

  function removeTier(index) {
    setDraft((d) => ({ ...d, tiers: d.tiers.filter((_, i) => i !== index) }))
  }

  const valid =
    isNonEmpty(draft.name) &&
    draft.tiers.length > 0 &&
    draft.tiers.every((t) => isPositiveNumber(t.qty) && isPositiveNumber(t.price))

  function handleSave() {
    if (!valid) return
    onSave({
      name: sanitizeText(draft.name, 80),
      description: sanitizeText(draft.description, 200),
      imageUrl: draft.imageUrl || null,
      tiers: draft.tiers.map((t) => ({ qty: Number(t.qty), price: Number(t.price) }))
    })
  }

  return (
    <Card className="mb-4">
      <div className="mb-3 w-32">
        <ImageUploadField
          folder="products"
          currentUrl={draft.imageUrl}
          label="Foto del producto"
          onUploaded={({ url }) => setDraft((d) => ({ ...d, imageUrl: url }))}
        />
      </div>
      <div className="grid sm:grid-cols-2 gap-3 mb-3">
        <input
          value={draft.name}
          onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
          placeholder="Nombre del producto"
          className="rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
        <input
          value={draft.description}
          onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
          placeholder="Descripción (opcional)"
          className="rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
      </div>

      <p className="text-sm font-semibold mb-2">Cantidades disponibles</p>
      <div className="space-y-2 mb-3">
        {draft.tiers.map((tier, i) => (
          <div key={i} className="flex items-center gap-2">
            <input
              type="number"
              min="1"
              value={tier.qty}
              onChange={(e) => updateTier(i, 'qty', e.target.value)}
              placeholder="Unidades"
              className="w-24 rounded-pill border border-secondary px-3 py-1.5 bg-surface outline-none text-sm"
            />
            <span className="text-text-muted text-sm">unidades →</span>
            <input
              type="number"
              min="0"
              step="0.01"
              value={tier.price}
              onChange={(e) => updateTier(i, 'price', e.target.value)}
              placeholder="Precio"
              className="w-24 rounded-pill border border-secondary px-3 py-1.5 bg-surface outline-none text-sm"
            />
            {draft.tiers.length > 1 && (
              <button onClick={() => removeTier(i)} className="text-text-muted hover:text-primary">
                <X size={16} />
              </button>
            )}
          </div>
        ))}
        <Button size="sm" variant="ghost" icon={Plus} onClick={addTier}>
          Agregar cantidad
        </Button>
      </div>

      <div className="flex gap-2">
        <Button size="sm" disabled={!valid} onClick={handleSave}>Guardar</Button>
        <Button size="sm" variant="secondary" onClick={onCancel}>Cancelar</Button>
      </div>
    </Card>
  )
}

export default function ProductosAdicionales() {
  const { additionalProducts, additionalProductOps } = useAdminData()
  const [creating, setCreating] = useState(false)
  const [editingId, setEditingId] = useState(null)

  return (
    <div>
      <AdminModuleHeader
        title="Productos Adicionales"
        icon={ShoppingBag}
        description="Cualquier producto extra que acompañe un pedido: gelatinas, bocaditos, cupcakes, y lo que necesites."
      />

      <ModuleVisibilityToggle settingKey="additionalProducts" label="Mostrar productos adicionales a los clientes" />

      <div className="space-y-3 mb-4">
        {additionalProducts.map((p) =>
          editingId === p.id ? (
            <ProductForm
              key={p.id}
              initial={p}
              onCancel={() => setEditingId(null)}
              onSave={(data) => {
                additionalProductOps.update(p.id, data)
                setEditingId(null)
              }}
            />
          ) : (
            <Card key={p.id} className="flex gap-4">
              <PlaceholderMedia label={p.name} imageUrl={p.imageUrl} aspect="aspect-square" className="w-20 shrink-0" />
              <div className="flex-1">
                <p className="font-semibold flex items-center gap-2">
                  {p.name}
                  {p.status !== 'active' && (
                    <span className="text-xs bg-secondary text-text-muted px-2 py-0.5 rounded-pill">Silenciado</span>
                  )}
                </p>
                {p.description && <p className="text-sm text-text-muted">{p.description}</p>}
                <div className="flex flex-wrap gap-2 mt-2">
                  {p.tiers.map((t, i) => (
                    <span key={i} className="text-xs bg-surface rounded-pill px-2 py-1">
                      {t.qty}u — ${t.price}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex flex-col items-center gap-2 shrink-0">
                <button
                  onClick={() => additionalProductOps.update(p.id, { status: p.status === 'active' ? 'inactive' : 'active' })}
                  className="text-text-muted hover:text-primary"
                  title="Activar/Silenciar"
                >
                  <Power size={18} />
                </button>
                <button onClick={() => setEditingId(p.id)} className="text-text-muted hover:text-primary" title="Editar">
                  <Pencil size={18} />
                </button>
                <button
                  onClick={() => window.confirm(`¿Eliminar "${p.name}"?`) && additionalProductOps.remove(p.id)}
                  className="text-text-muted hover:text-primary"
                  title="Eliminar"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </Card>
          )
        )}
      </div>

      {creating ? (
        <ProductForm
          onCancel={() => setCreating(false)}
          onSave={(data) => {
            additionalProductOps.add({ ...data, status: 'active' })
            setCreating(false)
          }}
        />
      ) : (
        <Button size="sm" variant="secondary" icon={Plus} onClick={() => setCreating(true)}>
          Nuevo producto
        </Button>
      )}
    </div>
  )
}
