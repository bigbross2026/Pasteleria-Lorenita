import { useState } from 'react'
import { Percent, Plus, Pencil, Trash2, Power } from 'lucide-react'
import AdminModuleHeader from '../../../components/admin/AdminModuleHeader'
import ModuleVisibilityToggle from './ModuleVisibilityToggle'
import ImageUploadField from '../../../components/admin/ImageUploadField'
import Card from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import PlaceholderMedia from '../../../components/ui/PlaceholderMedia'
import { useAdminData } from '../../../data/AdminDataContext'
import { sanitizeText, isNonEmpty, isPositiveNumber } from '../../../utils/validation'

function emptyPromo() {
  const today = new Date().toISOString().slice(0, 10)
  return { title: '', description: '', price: 0, startDate: today, endDate: today, imageUrl: null }
}

function PromoForm({ initial, onCancel, onSave }) {
  const [draft, setDraft] = useState(initial || emptyPromo())

  const valid =
    isNonEmpty(draft.title) &&
    isPositiveNumber(draft.price) &&
    draft.startDate &&
    draft.endDate &&
    draft.endDate >= draft.startDate

  function handleSave() {
    if (!valid) return
    onSave({
      title: sanitizeText(draft.title, 80),
      description: sanitizeText(draft.description, 200),
      price: Number(draft.price),
      startDate: draft.startDate,
      endDate: draft.endDate,
      imageUrl: draft.imageUrl || null
    })
  }

  return (
    <Card className="mb-4">
      <div className="mb-3 w-32">
        <ImageUploadField
          folder="promotions"
          currentUrl={draft.imageUrl}
          label="Foto de la promoción"
          onUploaded={({ url }) => setDraft((d) => ({ ...d, imageUrl: url }))}
        />
      </div>
      <div className="grid sm:grid-cols-2 gap-3 mb-3">
        <input
          value={draft.title}
          onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
          placeholder="Nombre de la promoción"
          className="rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
        <input
          type="number"
          min="0"
          step="0.01"
          value={draft.price}
          onChange={(e) => setDraft((d) => ({ ...d, price: e.target.value }))}
          placeholder="Precio promocional"
          className="rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
      </div>
      <textarea
        value={draft.description}
        onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
        placeholder="Descripción"
        rows={2}
        className="w-full rounded-xl border border-secondary px-4 py-2 bg-surface outline-none resize-none mb-3"
      />
      <div className="grid sm:grid-cols-2 gap-3 mb-4">
        <label className="text-sm">
          Inicio
          <input
            type="date"
            value={draft.startDate}
            onChange={(e) => setDraft((d) => ({ ...d, startDate: e.target.value }))}
            className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
          />
        </label>
        <label className="text-sm">
          Fin
          <input
            type="date"
            value={draft.endDate}
            onChange={(e) => setDraft((d) => ({ ...d, endDate: e.target.value }))}
            className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
          />
        </label>
      </div>
      <div className="flex gap-2">
        <Button size="sm" disabled={!valid} onClick={handleSave}>Guardar</Button>
        <Button size="sm" variant="secondary" onClick={onCancel}>Cancelar</Button>
      </div>
    </Card>
  )
}

export default function Promociones() {
  const { promotions, promotionOps } = useAdminData()
  const [creating, setCreating] = useState(false)
  const [editingId, setEditingId] = useState(null)

  const today = new Date().toISOString().slice(0, 10)

  return (
    <div>
      <AdminModuleHeader
        title="Promociones"
        icon={Percent}
        description="Descuentos y ofertas especiales visibles para los clientes."
      />

      <ModuleVisibilityToggle settingKey="promotions" label="Mostrar promociones a los clientes" />

      <div className="space-y-3 mb-4">
        {promotions.map((promo) => {
          const expired = promo.endDate < today
          return editingId === promo.id ? (
            <PromoForm
              key={promo.id}
              initial={promo}
              onCancel={() => setEditingId(null)}
              onSave={(data) => {
                promotionOps.update(promo.id, data)
                setEditingId(null)
              }}
            />
          ) : (
            <Card key={promo.id} className="flex gap-4">
              <PlaceholderMedia label={promo.title} imageUrl={promo.imageUrl} aspect="aspect-square" className="w-20 shrink-0" />
              <div className="flex-1">
                <p className="font-semibold flex items-center gap-2 flex-wrap">
                  {promo.title}
                  {promo.status !== 'active' && (
                    <span className="text-xs bg-secondary text-text-muted px-2 py-0.5 rounded-pill">Desactivada</span>
                  )}
                  {expired && (
                    <span className="text-xs bg-secondary text-text-muted px-2 py-0.5 rounded-pill">Vencida</span>
                  )}
                </p>
                <p className="text-sm text-text-muted">{promo.description}</p>
                <p className="text-xs text-text-muted mt-1">
                  ${promo.price} · vigente {promo.startDate} → {promo.endDate}
                </p>
              </div>
              <div className="flex flex-col items-center gap-2 shrink-0">
                <button
                  onClick={() => promotionOps.update(promo.id, { status: promo.status === 'active' ? 'inactive' : 'active' })}
                  className="text-text-muted hover:text-primary"
                  title="Activar/Desactivar"
                >
                  <Power size={18} />
                </button>
                <button onClick={() => setEditingId(promo.id)} className="text-text-muted hover:text-primary" title="Editar">
                  <Pencil size={18} />
                </button>
                <button
                  onClick={() => window.confirm(`¿Eliminar "${promo.title}"?`) && promotionOps.remove(promo.id)}
                  className="text-text-muted hover:text-primary"
                  title="Eliminar"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </Card>
          )
        })}
      </div>

      {creating ? (
        <PromoForm
          onCancel={() => setCreating(false)}
          onSave={(data) => {
            promotionOps.add({ ...data, status: 'active' })
            setCreating(false)
          }}
        />
      ) : (
        <Button size="sm" variant="secondary" icon={Plus} onClick={() => setCreating(true)}>
          Nueva promoción
        </Button>
      )}
    </div>
  )
}
