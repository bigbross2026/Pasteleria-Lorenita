import { useState } from 'react'
import { Heart, Check, X, Trash2, Pencil, Image as ImageIcon } from 'lucide-react'
import AdminModuleHeader from '../../../components/admin/AdminModuleHeader'
import ModuleVisibilityToggle from './ModuleVisibilityToggle'
import Card from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import PlaceholderMedia from '../../../components/ui/PlaceholderMedia'
import { useAdminData } from '../../../data/AdminDataContext'
import { useNotify } from '../../../context/NotificationContext'
import { sanitizeText } from '../../../utils/validation'
import { deleteImage } from '../../../firebase/storage'

function TestimonialCard({ item, ops, notify }) {
  const [editing, setEditing] = useState(false)
  const [message, setMessage] = useState(item.message)

  function saveMessage() {
    ops.update(item.id, { message: sanitizeText(message, 300) })
    setEditing(false)
  }

  function removePhoto(photo) {
    ops.update(item.id, { photos: item.photos.filter((p) => p.id !== photo.id) })
    if (photo.path) deleteImage(photo.path)
  }

  function removeAllPhotos() {
    if (window.confirm('¿Eliminar todas las fotografías de esta publicación?')) {
      item.photos.forEach((p) => p.path && deleteImage(p.path))
      ops.update(item.id, { photos: [] })
    }
  }

  const statusLabel = { pending: 'Pendiente', approved: 'Aprobada', rejected: 'Rechazada' }[item.status]
  const statusColor = { pending: 'bg-accent', approved: 'bg-primary', rejected: 'bg-secondary' }[item.status]

  return (
    <Card>
      <div className="flex items-center justify-between mb-3">
        <span className={`text-xs font-semibold text-white px-2 py-1 rounded-pill ${statusColor}`}>{statusLabel}</span>
        <span className="text-xs text-text-muted">{new Date(item.createdAt).toLocaleDateString('es-ES')}</span>
      </div>

      {item.photos.length > 0 && (
        <div className="flex gap-2 mb-3">
          {item.photos.map((photo) => (
            <div key={photo.id} className="relative flex-1">
              <PlaceholderMedia label="" imageUrl={photo.url} aspect="aspect-square" />
              <button
                onClick={() => removePhoto(photo)}
                className="absolute top-1 right-1 bg-card rounded-full p-1 shadow-soft text-text-muted hover:text-primary"
                title="Eliminar esta fotografía"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}
      {item.photos.length > 1 && (
        <button onClick={removeAllPhotos} className="text-xs text-text-muted hover:text-primary flex items-center gap-1 mb-3">
          <ImageIcon size={14} /> Eliminar todas las fotos
        </button>
      )}

      {editing ? (
        <div className="mb-3">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
            className="w-full rounded-xl border border-secondary px-3 py-2 bg-surface outline-none resize-none text-sm"
          />
          <div className="flex gap-2 mt-2">
            <Button size="sm" onClick={saveMessage}>Guardar</Button>
            <Button size="sm" variant="secondary" onClick={() => setEditing(false)}>Cancelar</Button>
          </div>
        </div>
      ) : (
        <p className="text-sm italic text-text-muted mb-3">
          "{item.message}"{' '}
          <button onClick={() => setEditing(true)} className="not-italic text-primary inline-flex items-center gap-0.5">
            <Pencil size={12} /> editar
          </button>
        </p>
      )}

      <div className="flex gap-2 flex-wrap">
        {item.status !== 'approved' && (
          <Button
            size="sm"
            icon={Check}
            onClick={() => {
              ops.update(item.id, { status: 'approved' })
              notify('success', 'Publicación aprobada. Ya es visible para los clientes.')
            }}
          >
            Aprobar
          </Button>
        )}
        {item.status !== 'rejected' && (
          <Button
            size="sm"
            variant="secondary"
            icon={X}
            onClick={() => {
              ops.update(item.id, { status: 'rejected' })
              notify('info', 'Publicación rechazada.')
            }}
          >
            Rechazar
          </Button>
        )}
        <Button
          size="sm"
          variant="ghost"
          icon={Trash2}
          onClick={() => {
            if (window.confirm('¿Eliminar esta publicación por completo?')) {
              ops.remove(item.id)
              notify('success', 'Publicación eliminada.')
            }
          }}
        >
          Eliminar
        </Button>
      </div>
    </Card>
  )
}

export default function ClientesSatisfechos() {
  const { testimonials, testimonialOps } = useAdminData()
  const { notify } = useNotify()
  const pending = testimonials.filter((t) => t.status === 'pending')
  const others = testimonials.filter((t) => t.status !== 'pending')

  return (
    <div>
      <AdminModuleHeader
        title="Clientes Satisfechos"
        icon={Heart}
        description="Aprueba, rechaza o edita las experiencias enviadas por los clientes."
      />

      <ModuleVisibilityToggle settingKey="satisfiedCustomers" label="Mostrar clientes satisfechos a los clientes" />

      {pending.length > 0 && (
        <div className="mb-8">
          <h2 className="font-semibold mb-3">Pendientes de revisión ({pending.length})</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {pending.map((t) => <TestimonialCard key={t.id} item={t} ops={testimonialOps} notify={notify} />)}
          </div>
        </div>
      )}

      <div>
        <h2 className="font-semibold mb-3">Todas las publicaciones</h2>
        {others.length === 0 ? (
          <p className="text-text-muted">Aún no hay publicaciones aprobadas o rechazadas.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {others.map((t) => <TestimonialCard key={t.id} item={t} ops={testimonialOps} notify={notify} />)}
          </div>
        )}
      </div>
    </div>
  )
}
