import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import Card from '../../../components/ui/Card'

// Cada módulo del admin (Pedidos, Pasteles, Promociones, etc.) usa esta
// plantilla como punto de partida. La lógica de cada uno se construirá en
// el siguiente bloque de trabajo; por ahora solo confirma la navegación y
// mantiene la identidad visual consistente.
export default function ModulePlaceholder({ title, icon: Icon, description }) {
  return (
    <div>
      <Link to="/admin" className="inline-flex items-center gap-1 text-sm text-text-muted hover:text-primary mb-4">
        <ArrowLeft size={16} /> Volver al menú
      </Link>

      <Card className="text-center py-16">
        {Icon && <Icon size={48} strokeWidth={1.5} className="mx-auto mb-4 text-primary" />}
        <h1 className="text-2xl font-semibold mb-2">{title}</h1>
        <p className="text-text-muted max-w-md mx-auto">
          {description || 'Este módulo se desarrollará en el siguiente bloque de trabajo.'}
        </p>
      </Card>
    </div>
  )
}
