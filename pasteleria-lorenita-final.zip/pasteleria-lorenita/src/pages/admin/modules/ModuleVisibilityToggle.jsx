import { useAdminData } from '../../../data/AdminDataContext'

// Interruptor simple para que el admin active o desactive una sección
// visible en el módulo cliente (Promociones, Clientes Satisfechos,
// Productos Adicionales). Grande y con muy poco texto, como pide el brief
// para un administrador sin conocimientos técnicos.
export default function ModuleVisibilityToggle({ settingKey, label }) {
  const { business, toggleModule } = useAdminData()
  const isOn = business.modules[settingKey]

  return (
    <div className="flex items-center justify-between bg-surface rounded-card px-5 py-4 mb-6">
      <div>
        <p className="font-semibold text-text-main">{label}</p>
        <p className="text-sm text-text-muted">{isOn ? 'Visible para los clientes' : 'Oculto para los clientes'}</p>
      </div>
      <button
        onClick={() => toggleModule(settingKey)}
        aria-pressed={isOn}
        aria-label={`Alternar visibilidad de ${label}`}
        className={`relative w-14 h-8 rounded-pill transition-colors duration-300 ${isOn ? 'bg-primary' : 'bg-secondary'}`}
      >
        <span
          className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-soft transition-transform duration-300 ${
            isOn ? 'translate-x-7' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  )
}
