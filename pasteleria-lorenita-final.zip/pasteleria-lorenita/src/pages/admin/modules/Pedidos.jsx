import { useState, useMemo } from 'react'
import { ClipboardList, Search, Check, XCircle, Clock3, Link as LinkIcon, Gauge } from 'lucide-react'
import AdminModuleHeader from '../../../components/admin/AdminModuleHeader'
import Card from '../../../components/ui/Card'
import Button from '../../../components/ui/Button'
import CakeVisual from '../../../components/order/CakeVisual'
import { useAdminData } from '../../../data/AdminDataContext'
import { useNotify } from '../../../context/NotificationContext'
import { formatCurrency } from '../../../utils/pricing'
import { formatDateHuman } from '../../../utils/deliveryTime'

const STATUS_OPTIONS = ['Pendiente', 'Entregado', 'Cancelado']
const STATUS_STYLES = {
  Pendiente: 'bg-accent text-button-text',
  Entregado: 'bg-primary text-button-text',
  Cancelado: 'bg-secondary text-text-muted'
}

function OrderDetail({ order, onChangeStatus }) {
  return (
    <Card className="mt-4">
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
        <div>
          <h3 className="text-xl font-display font-semibold">{order.orderNumber}</h3>
          <p className="text-sm text-text-muted">
            Pedido realizado el {new Date(order.createdAt).toLocaleDateString('es-ES')}
          </p>
        </div>
        <span className={`text-sm font-semibold px-3 py-1.5 rounded-pill ${STATUS_STYLES[order.status]}`}>
          {order.status}
        </span>
      </div>

      <div className="space-y-4 mb-4">
        {order.cakes.map((c, i) => (
          <div key={i} className="flex gap-4 bg-surface rounded-card p-4">
            <div className="w-24 shrink-0">
              <CakeVisual cake={c.cake} aspect="aspect-square" />
            </div>
            <div className="flex-1 text-sm">
              <p className="font-semibold">{c.cake.name}</p>
              <p className="text-text-muted">Sabor: {c.flavor.name} · Relleno: {c.filling.name} · Tamaño: {c.size.label}</p>
              <p className="text-text-muted flex items-center gap-1 mt-1">
                <Clock3 size={14} /> Entrega: {formatDateHuman(c.date)} a las {c.time}
              </p>
              {c.message && <p className="text-text-muted italic">Mensaje: "{c.message}"</p>}
              <a
                href={`/diseno/${c.cake.id}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-primary mt-1"
              >
                <LinkIcon size={14} /> Ver diseño
              </a>
            </div>
            <div className="font-display font-semibold text-primary shrink-0">{formatCurrency(c.price)}</div>
          </div>
        ))}

        {order.additionalProducts?.length > 0 && (
          <div className="bg-surface rounded-card p-4">
            <p className="font-semibold text-sm mb-2">Productos adicionales</p>
            {order.additionalProducts.map((p, i) => (
              <div key={i} className="flex justify-between text-sm text-text-muted">
                <span>{p.product.name} — {p.quantity} unidades</span>
                <span>{formatCurrency(p.price)}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between border-t border-secondary pt-4 mb-4">
        <span className="font-semibold">Total</span>
        <span className="font-display font-bold text-xl text-primary">{formatCurrency(order.total)}</span>
      </div>

      <div>
        <p className="text-sm font-semibold mb-2">Cambiar estado</p>
        <div className="flex gap-2 flex-wrap">
          {STATUS_OPTIONS.map((s) => (
            <Button
              key={s}
              size="sm"
              variant={order.status === s ? 'primary' : 'secondary'}
              icon={s === 'Entregado' ? Check : s === 'Cancelado' ? XCircle : Clock3}
              onClick={() => onChangeStatus(order.id, s)}
            >
              {s}
            </Button>
          ))}
        </div>
      </div>
    </Card>
  )
}

function DailyLimitSettings() {
  const { business, updateBusiness } = useAdminData()
  const dailyLimit = business.dailyLimit

  return (
    <Card className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="font-semibold flex items-center gap-2"><Gauge size={18} className="text-primary" /> Límite diario de producción</p>
          <p className="text-sm text-text-muted">
            {dailyLimit.enabled ? `Máximo ${dailyLimit.max} pasteles por día` : 'Sin límite: se aceptan pedidos libremente'}
          </p>
        </div>
        <button
          onClick={() => updateBusiness({ dailyLimit: { ...dailyLimit, enabled: !dailyLimit.enabled } })}
          className={`relative w-14 h-8 rounded-pill transition-colors duration-300 ${dailyLimit.enabled ? 'bg-primary' : 'bg-secondary'}`}
        >
          <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-soft transition-transform duration-300 ${dailyLimit.enabled ? 'translate-x-7' : 'translate-x-1'}`} />
        </button>
      </div>
      {dailyLimit.enabled && (
        <label className="flex items-center gap-3 text-sm">
          Máximo de pasteles por día
          <input
            type="number"
            min="1"
            value={dailyLimit.max}
            onChange={(e) => updateBusiness({ dailyLimit: { ...dailyLimit, max: Number(e.target.value) || 1 } })}
            className="w-24 rounded-pill border border-secondary px-3 py-1.5 bg-surface outline-none"
          />
        </label>
      )}
      <p className="text-xs text-text-muted mt-2">
        Si un pedido ya tenía cupo y el cliente agrega varios pasteles, se permiten hasta 2 pasteles adicionales sobre el
        máximo para ese mismo pedido, tal como fue aprobado.
      </p>
    </Card>
  )
}

export default function Pedidos() {
  const { orders, orderOps } = useAdminData()
  const { notify } = useNotify()
  const [query, setQuery] = useState('')

  function handleStatusChange(id, status) {
    orderOps.update(id, { status })
    notify('success', `Pedido actualizado a "${status}".`)
  }

  const sortedOrders = useMemo(
    () => [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    [orders]
  )

  const found = query.trim()
    ? sortedOrders.find((o) => o.orderNumber.toLowerCase() === query.trim().toLowerCase())
    : null

  const pendingCount = orders.filter((o) => o.status === 'Pendiente').length

  return (
    <div>
      <AdminModuleHeader
        title="Pedidos"
        icon={ClipboardList}
        description={`${pendingCount} pedido(s) pendiente(s) de un total de ${orders.length}.`}
      />

      <DailyLimitSettings />

      <Card className="mb-6">
        <label className="flex items-center gap-2">
          <Search size={18} className="text-text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por código, ej. Pedido-00100"
            className="flex-1 outline-none bg-transparent"
          />
        </label>
      </Card>

      {query.trim() && (
        found ? (
          <OrderDetail order={found} onChangeStatus={handleStatusChange} />
        ) : (
          <p className="text-text-muted">No se encontró ningún pedido con ese código.</p>
        )
      )}

      {!query.trim() && (
        <div className="space-y-3">
          {sortedOrders.length === 0 && <p className="text-text-muted">Todavía no se ha recibido ningún pedido.</p>}
          {sortedOrders.map((o) => (
            <button
              key={o.id}
              onClick={() => setQuery(o.orderNumber)}
              className="w-full flex items-center justify-between bg-card rounded-card shadow-soft px-4 py-3 hover:shadow-lift transition-shadow"
            >
              <div className="text-left">
                <p className="font-semibold">{o.orderNumber}</p>
                <p className="text-xs text-text-muted">{new Date(o.createdAt).toLocaleDateString('es-ES')} · {o.cakes.length} pastel(es)</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-display font-semibold text-primary">{formatCurrency(o.total)}</span>
                <span className={`text-xs font-semibold px-2 py-1 rounded-pill ${STATUS_STYLES[o.status]}`}>{o.status}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
