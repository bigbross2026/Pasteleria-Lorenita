import { useState } from 'react'
import { Store, Phone, ImageIcon, Clock, Loader2 } from 'lucide-react'
import Card from '../../../../components/ui/Card'
import Button from '../../../../components/ui/Button'
import { useAdminData } from '../../../../data/AdminDataContext'
import { sanitizeText } from '../../../../utils/validation'
import { uploadImage } from '../../../../firebase/storage'

export default function BusinessInfoSection() {
  const { business, updateBusiness } = useAdminData()
  const [name, setName] = useState(business.businessName)
  const [whatsapp, setWhatsapp] = useState(business.whatsappNumber)
  const [hours, setHours] = useState(business.hours)
  const [savedTick, setSavedTick] = useState(false)
  const [uploadingLogo, setUploadingLogo] = useState(false)
  const [logoError, setLogoError] = useState(null)

  async function handleLogoUpload(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploadingLogo(true)
    setLogoError(null)
    try {
      const { url } = await uploadImage(file, 'logo')
      await updateBusiness({ logoLabel: file.name, logoUrl: url })
    } catch (err) {
      setLogoError(err.message)
    } finally {
      setUploadingLogo(false)
    }
  }

  function handleSave() {
    updateBusiness({
      businessName: sanitizeText(name, 60) || business.businessName,
      whatsappNumber: sanitizeText(whatsapp, 20) || business.whatsappNumber,
      hours
    })
    setSavedTick(true)
    setTimeout(() => setSavedTick(false), 2000)
  }

  return (
    <div className="space-y-4">
      <Card className="max-w-md">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Store size={18} className="text-primary" /> Datos del negocio
        </h3>
        <label className="block mb-3">
          <span className="text-sm text-text-muted">Nombre de la pastelería</span>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
          />
        </label>
        <label className="block mb-3">
          <span className="text-sm text-text-muted flex items-center gap-1"><Phone size={14} /> Número de WhatsApp</span>
          <input
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value)}
            placeholder="Ej. 593999999999"
            className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
          />
        </label>
        <label className="block mb-4">
          <span className="text-sm text-text-muted flex items-center gap-1"><ImageIcon size={14} /> Logotipo</span>
          {business.logoUrl && (
            <img src={business.logoUrl} alt="Logotipo actual" className="h-16 w-16 object-contain rounded-card border border-secondary my-2 bg-white" />
          )}
          <input type="file" accept="image/*" onChange={handleLogoUpload} disabled={uploadingLogo} className="mt-1 w-full text-sm" />
          <p className="text-xs text-text-muted mt-1 flex items-center gap-1">
            {uploadingLogo && <Loader2 size={12} className="animate-spin" />}
            {uploadingLogo ? 'Subiendo…' : business.logoLabel}
          </p>
          {logoError && <p className="text-xs text-primary-dark mt-1">{logoError}</p>}
        </label>
        <Button size="sm" onClick={handleSave}>{savedTick ? 'Guardado ✓' : 'Guardar cambios'}</Button>
      </Card>

      <Card className="max-w-md">
        <h3 className="font-semibold mb-4 flex items-center gap-2">
          <Clock size={18} className="text-primary" /> Horario de atención
        </h3>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <label className="text-sm">
            Abre
            <input
              type="time"
              value={hours.open}
              onChange={(e) => setHours((h) => ({ ...h, open: e.target.value }))}
              className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
            />
          </label>
          <label className="text-sm">
            Cierra
            <input
              type="time"
              value={hours.close}
              onChange={(e) => setHours((h) => ({ ...h, close: e.target.value }))}
              className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
            />
          </label>
        </div>
        <label className="block mb-4 text-sm">
          Días de atención
          <input
            value={hours.days}
            onChange={(e) => setHours((h) => ({ ...h, days: e.target.value }))}
            placeholder="Ej. Lunes a sábado"
            className="mt-1 w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
          />
        </label>
        <Button size="sm" onClick={handleSave}>{savedTick ? 'Guardado ✓' : 'Guardar horario'}</Button>
      </Card>
    </div>
  )
}
