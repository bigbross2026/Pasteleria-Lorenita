import { useState } from 'react'
import { KeyRound } from 'lucide-react'
import Card from '../../../../components/ui/Card'
import Button from '../../../../components/ui/Button'
import { useAdminAuth } from '../../../../auth/AdminAuthContext'

export default function PasswordSection() {
  const { changePassword } = useAdminAuth()
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')
  const [feedback, setFeedback] = useState(null)

  async function handleSubmit(e) {
    e.preventDefault()
    if (next !== confirm) {
      setFeedback({ ok: false, text: 'La nueva contraseña y su confirmación no coinciden.' })
      return
    }
    const result = await changePassword(current, next)
    if (result.ok) {
      setFeedback({ ok: true, text: 'Contraseña actualizada correctamente.' })
      setCurrent('')
      setNext('')
      setConfirm('')
    } else {
      setFeedback({ ok: false, text: result.message })
    }
  }

  return (
    <Card className="max-w-md">
      <h3 className="font-semibold mb-4 flex items-center gap-2">
        <KeyRound size={18} className="text-primary" /> Cambiar contraseña
      </h3>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input
          type="password"
          value={current}
          onChange={(e) => setCurrent(e.target.value)}
          placeholder="Contraseña actual"
          className="w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
        <input
          type="password"
          value={next}
          onChange={(e) => setNext(e.target.value)}
          placeholder="Nueva contraseña"
          className="w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
        <input
          type="password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          placeholder="Confirmar nueva contraseña"
          className="w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
        />
        {feedback && (
          <p className={`text-sm ${feedback.ok ? 'text-primary' : 'text-primary-dark'}`}>{feedback.text}</p>
        )}
        <Button type="submit" size="sm">Guardar nueva contraseña</Button>
      </form>
    </Card>
  )
}
