import { Gauge } from 'lucide-react'
import Card from '../../../../components/ui/Card'
import ModuleVisibilityToggle from '../ModuleVisibilityToggle'
import { useAdminData } from '../../../../data/AdminDataContext'

export default function ModulesSection() {
  const { business, updateBusiness } = useAdminData()
  const dailyLimit = business.dailyLimit

  return (
    <div>
      <ModuleVisibilityToggle settingKey="promotions" label="Promociones" />
      <ModuleVisibilityToggle settingKey="additionalProducts" label="Productos adicionales" />
      <ModuleVisibilityToggle settingKey="satisfiedCustomers" label="Clientes satisfechos" />

      <Card>
        <div className="flex items-center justify-between mb-3">
          <div>
            <p className="font-semibold flex items-center gap-2"><Gauge size={18} className="text-primary" /> Límite diario de producción</p>
            <p className="text-sm text-text-muted">
              {dailyLimit.enabled ? `Activado — máximo ${dailyLimit.max} pasteles por día` : 'Desactivado — sin límite'}
            </p>
          </div>
          <button
            onClick={() => updateBusiness({ dailyLimit: { ...dailyLimit, enabled: !dailyLimit.enabled } })}
            className={`relative w-14 h-8 rounded-pill transition-colors duration-300 ${dailyLimit.enabled ? 'bg-primary' : 'bg-secondary'}`}
          >
            <span className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow-soft transition-transform duration-300 ${dailyLimit.enabled ? 'translate-x-7' : 'translate-x-1'}`} />
          </button>
        </div>
        {dailyLimit.enabled && (
          <label className="flex items-center gap-3 text-sm">
            Máximo de pasteles por día
            <input
              type="number"
              min="1"
              value={dailyLimit.max}
              onChange={(e) => updateBusiness({ dailyLimit: { ...dailyLimit, max: Number(e.target.value) || 1 } })}
              className="w-24 rounded-pill border border-secondary px-3 py-1.5 bg-surface outline-none"
            />
          </label>
        )}
        <p className="text-xs text-text-muted mt-2">
          Esta misma opción también está disponible en el módulo Pedidos.
        </p>
      </Card>
    </div>
  )
}
