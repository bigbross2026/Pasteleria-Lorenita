import { useEffect, useRef, useState } from 'react'
import { DownloadCloud, UploadCloud, AlertTriangle, Save, Trash2, RotateCcw, Loader2 } from 'lucide-react'
import Card from '../../../../components/ui/Card'
import Button from '../../../../components/ui/Button'
import {
  exportSnapshot,
  saveBackupSnapshot,
  listBackups,
  getBackupData,
  deleteBackup,
  restoreSnapshot,
  downloadSnapshotAsFile
} from '../../../../utils/firestoreBackup'
import { useNotify } from '../../../../context/NotificationContext'

export default function BackupSection() {
  const fileInputRef = useRef(null)
  const { notify } = useNotify()
  const [backups, setBackups] = useState([])
  const [loadingList, setLoadingList] = useState(true)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState(null)

  async function refreshList() {
    setLoadingList(true)
    try {
      setBackups(await listBackups())
    } catch (err) {
      setMessage({ ok: false, text: `No se pudo cargar el historial: ${err.message}` })
    } finally {
      setLoadingList(false)
    }
  }

  useEffect(() => {
    refreshList()
  }, [])

  async function handleCreateBackup() {
    setBusy(true)
    setMessage(null)
    try {
      const snapshot = await exportSnapshot()
      await saveBackupSnapshot(snapshot)
      setMessage({ ok: true, text: 'Respaldo creado correctamente.' })
      notify('success', 'Respaldo creado correctamente.')
      refreshList()
    } catch (err) {
      setMessage({ ok: false, text: `No se pudo crear el respaldo: ${err.message}` })
    } finally {
      setBusy(false)
    }
  }

  async function handleDownload(id) {
    setBusy(true)
    try {
      const data = await getBackupData(id)
      downloadSnapshotAsFile(data)
    } catch (err) {
      setMessage({ ok: false, text: err.message })
    } finally {
      setBusy(false)
    }
  }

  async function handleRestore(id) {
    if (!window.confirm('Restaurar este respaldo reemplazará los datos actuales. ¿Deseas continuar?')) return
    setBusy(true)
    try {
      const data = await getBackupData(id)
      await restoreSnapshot(data)
      setMessage({ ok: true, text: 'Respaldo restaurado correctamente.' })
      notify('success', 'Respaldo restaurado correctamente.')
    } catch (err) {
      setMessage({ ok: false, text: `No se pudo restaurar: ${err.message}` })
    } finally {
      setBusy(false)
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('¿Eliminar este respaldo del historial?')) return
    setBusy(true)
    try {
      await deleteBackup(id)
      refreshList()
    } catch (err) {
      setMessage({ ok: false, text: err.message })
    } finally {
      setBusy(false)
    }
  }

  function handleDownloadNow() {
    setBusy(true)
    exportSnapshot()
      .then(downloadSnapshotAsFile)
      .catch((err) => setMessage({ ok: false, text: err.message }))
      .finally(() => setBusy(false))
  }

  function handleRestoreFromFile(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    if (!window.confirm('Restaurar este archivo reemplazará los datos actuales. ¿Deseas continuar?')) return

    setBusy(true)
    const reader = new FileReader()
    reader.onload = async () => {
      try {
        const data = JSON.parse(reader.result)
        await restoreSnapshot(data)
        setMessage({ ok: true, text: 'Respaldo restaurado desde archivo correctamente.' })
      } catch {
        setMessage({ ok: false, text: 'El archivo no es un respaldo válido.' })
      } finally {
        setBusy(false)
      }
    }
    reader.readAsText(file)
  }

  return (
    <Card className="max-w-lg">
      <h3 className="font-semibold mb-1">Respaldo y restauración</h3>
      <p className="text-sm text-text-muted mb-4">
        Crea copias de todos los datos (catálogo, pedidos, configuración) guardadas en la nube, descárgalas o
        restaura cualquiera de ellas cuando lo necesites.
      </p>

      <div className="flex flex-wrap gap-3 mb-5">
        <Button size="sm" icon={busy ? Loader2 : Save} disabled={busy} onClick={handleCreateBackup}>
          Crear respaldo ahora
        </Button>
        <Button size="sm" variant="secondary" icon={DownloadCloud} disabled={busy} onClick={handleDownloadNow}>
          Descargar respaldo actual
        </Button>
        <Button size="sm" variant="secondary" icon={UploadCloud} disabled={busy} onClick={() => fileInputRef.current?.click()}>
          Restaurar desde archivo
        </Button>
        <input ref={fileInputRef} type="file" accept="application/json" className="hidden" onChange={handleRestoreFromFile} />
      </div>

      {message && (
        <p className={`text-sm mb-4 flex items-center gap-1 ${message.ok ? 'text-primary' : 'text-primary-dark'}`}>
          <AlertTriangle size={14} /> {message.text}
        </p>
      )}

      <h4 className="text-sm font-semibold mb-2">Respaldos guardados</h4>
      {loadingList ? (
        <p className="text-sm text-text-muted flex items-center gap-2"><Loader2 size={14} className="animate-spin" /> Cargando…</p>
      ) : backups.length === 0 ? (
        <p className="text-sm text-text-muted">Aún no has creado ningún respaldo.</p>
      ) : (
        <div className="space-y-2">
          {backups.map((b) => (
            <div key={b.id} className="flex items-center justify-between bg-surface rounded-card px-3 py-2 text-sm">
              <span>{new Date(b.createdAt).toLocaleString('es-ES')}</span>
              <div className="flex items-center gap-3">
                <button onClick={() => handleDownload(b.id)} disabled={busy} className="text-text-muted hover:text-primary" title="Descargar">
                  <DownloadCloud size={16} />
                </button>
                <button onClick={() => handleRestore(b.id)} disabled={busy} className="text-text-muted hover:text-primary" title="Restaurar">
                  <RotateCcw size={16} />
                </button>
                <button onClick={() => handleDelete(b.id)} disabled={busy} className="text-text-muted hover:text-primary" title="Eliminar">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  )
}
