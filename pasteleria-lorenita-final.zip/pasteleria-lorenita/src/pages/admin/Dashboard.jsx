import { Link } from 'react-router-dom'
import {
  ClipboardList,
  CakeSlice,
  Percent,
  ShoppingBag,
  Heart,
  BarChart3,
  Settings
} from 'lucide-react'
import { useAdminData } from '../../data/AdminDataContext'

// El admin no tiene conocimientos técnicos: por eso el menú tiene SOLO
// estos 7 botones, grandes, con ícono grande y poco texto. El punto
// animado de "pendiente" se calcula en tiempo real a partir de los datos
// reales (pedidos sin revisar, publicaciones por aprobar).
export default function Dashboard() {
  const { orders, testimonials } = useAdminData()

  const pendingOrders = orders.filter((o) => o.status === 'Pendiente').length
  const pendingTestimonials = testimonials.filter((t) => t.status === 'pending').length

  const MODULES = [
    { to: '/admin/pedidos', label: 'Pedidos', icon: ClipboardList, pending: pendingOrders > 0 },
    { to: '/admin/pasteles', label: 'Pasteles', icon: CakeSlice, pending: false },
    { to: '/admin/promociones', label: 'Promociones', icon: Percent, pending: false },
    { to: '/admin/productos-adicionales', label: 'Productos Adicionales', icon: ShoppingBag, pending: false },
    { to: '/admin/clientes-satisfechos', label: 'Clientes Satisfechos', icon: Heart, pending: pendingTestimonials > 0 },
    { to: '/admin/reportes', label: 'Reportes', icon: BarChart3, pending: false },
    { to: '/admin/configuracion', label: 'Configuración', icon: Settings, pending: false }
  ]

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-6">¿Qué deseas hacer hoy?</h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
        {MODULES.map(({ to, label, icon: Icon, pending }) => (
          <Link
            key={to}
            to={to}
            className="relative flex flex-col items-center justify-center gap-3 bg-card rounded-card shadow-soft
                       hover:shadow-lift hover:-translate-y-1 active:scale-95 transition-all duration-200
                       aspect-square p-4 text-center"
          >
            {pending && (
              <span className="absolute top-3 right-3 h-3 w-3 rounded-full bg-accent animate-pulse-attention" />
            )}
            <Icon size={40} strokeWidth={1.75} className="text-primary" />
            <span className="font-semibold text-text-main text-sm sm:text-base">{label}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
