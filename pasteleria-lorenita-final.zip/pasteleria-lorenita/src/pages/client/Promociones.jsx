import { Percent } from 'lucide-react'
import PromotionsSection from '../../components/order/PromotionsSection'
import { useAdminData } from '../../data/AdminDataContext'

export default function Promociones() {
  const { business } = useAdminData()

  if (!business.modules.promotions) {
    return (
      <div className="max-w-lg mx-auto px-5 py-20 text-center">
        <Percent size={40} className="mx-auto mb-3 text-primary" strokeWidth={1.5} />
        <h1 className="text-2xl font-semibold mb-2">Promociones</h1>
        <p className="text-text-muted">Por ahora no hay promociones activas. ¡Vuelve pronto!</p>
      </div>
    )
  }

  return (
    <div className="py-6">
      <PromotionsSection />
    </div>
  )
}
