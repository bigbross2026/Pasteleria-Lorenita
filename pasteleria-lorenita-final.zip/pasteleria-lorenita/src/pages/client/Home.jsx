import { Link } from 'react-router-dom'
import { CakeSlice, Percent, Heart, MessageCircle, Lock } from 'lucide-react'
import PlaceholderMedia from '../../components/ui/PlaceholderMedia'
import WelcomeTutorial from '../../components/order/WelcomeTutorial'
import PromotionsSection from '../../components/order/PromotionsSection'
import AdditionalProductsSection from '../../components/order/AdditionalProductsSection'
import SatisfiedCustomersSection from '../../components/order/SatisfiedCustomersSection'
import { useAdminData } from '../../data/AdminDataContext'
import { getContactWhatsAppLink } from '../../utils/whatsapp'

const MENU_ITEMS = (modules) => [
  { to: '/crea-tu-pastel', icon: CakeSlice, label: 'Crea tu pastel', emoji: '🍰', show: true },
  { to: '/promociones', icon: Percent, label: 'Promociones', emoji: '🎉', show: modules.promotions },
  { to: '/clientes-satisfechos', icon: Heart, label: 'Clientes satisfechos', emoji: '❤️', show: modules.satisfiedCustomers },
  { to: 'whatsapp', icon: MessageCircle, label: 'Comunícate con nosotros', emoji: '💬', show: true }
]

export default function Home() {
  const { business } = useAdminData()
  const modules = business.modules
  const items = MENU_ITEMS(modules).filter((i) => i.show)

  return (
    <div className="theme-transition relative">
      <WelcomeTutorial />

      {/* Encabezado / banner principal */}
      <section className="max-w-6xl mx-auto px-5 pt-10 pb-8 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl sm:text-5xl font-semibold leading-tight mb-4">
            Diseña el pastel perfecto para tu celebración
          </h1>
          <p className="text-text-muted text-lg max-w-md">
            Elige tu diseño, personalízalo a tu gusto y recíbelo listo para tu fiesta.
          </p>
        </div>
        <PlaceholderMedia label="Banner principal" aspect="aspect-[4/3]" />
      </section>

      {/* Menú principal */}
      <section className="max-w-6xl mx-auto px-5 pb-6">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-5">
          {items.map((item) =>
            item.to === 'whatsapp' ? (
              <a
                key={item.label}
                href={getContactWhatsAppLink(business.whatsappNumber)}
                target="_blank"
                rel="noreferrer"
                className="flex flex-col items-center justify-center gap-2 bg-card rounded-card shadow-soft
                           hover:shadow-lift hover:-translate-y-1 active:scale-95 transition-all duration-200
                           aspect-square p-4 text-center"
              >
                <span className="text-3xl">{item.emoji}</span>
                <span className="font-semibold text-sm">{item.label}</span>
              </a>
            ) : (
              <Link
                key={item.label}
                to={item.to}
                className="flex flex-col items-center justify-center gap-2 bg-card rounded-card shadow-soft
                           hover:shadow-lift hover:-translate-y-1 active:scale-95 transition-all duration-200
                           aspect-square p-4 text-center"
              >
                <span className="text-3xl">{item.emoji}</span>
                <span className="font-semibold text-sm">{item.label}</span>
              </Link>
            )
          )}
        </div>
      </section>

      <PromotionsSection />
      <AdditionalProductsSection />
      <SatisfiedCustomersSection />

      {/* Acceso casi invisible al panel administrador, además del enlace en el pie de página */}
      <Link
        to="/admin/acceso"
        aria-label="Acceso administrador"
        className="fixed bottom-3 left-3 z-20 p-2 text-text-muted/30 hover:text-text-muted/70 transition-colors"
      >
        <Lock size={14} />
      </Link>
    </div>
  )
}
