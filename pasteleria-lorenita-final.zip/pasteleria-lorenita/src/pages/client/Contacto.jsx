import { MessageCircle } from 'lucide-react'
import Button from '../../components/ui/Button'
import { getContactWhatsAppLink } from '../../utils/whatsapp'
import { useAdminData } from '../../data/AdminDataContext'

export default function Contacto() {
  const { business } = useAdminData()

  return (
    <div className="max-w-lg mx-auto px-5 py-20 text-center">
      <h1 className="text-3xl font-semibold mb-3">Contáctanos</h1>
      <p className="text-text-muted mb-6">
        ¿Tienes dudas sobre tu pedido? Escríbenos directamente por WhatsApp y te ayudamos con gusto.
      </p>
      <a href={getContactWhatsAppLink(business.whatsappNumber)} target="_blank" rel="noreferrer">
        <Button size="lg" icon={MessageCircle}>Abrir WhatsApp</Button>
      </a>
    </div>
  )
}
