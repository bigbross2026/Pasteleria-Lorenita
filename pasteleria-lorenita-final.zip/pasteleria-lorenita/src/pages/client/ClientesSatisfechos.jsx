import { Heart } from 'lucide-react'
import SatisfiedCustomersSection from '../../components/order/SatisfiedCustomersSection'
import { useAdminData } from '../../data/AdminDataContext'

export default function ClientesSatisfechos() {
  const { business } = useAdminData()

  if (!business.modules.satisfiedCustomers) {
    return (
      <div className="max-w-lg mx-auto px-5 py-20 text-center">
        <Heart size={40} className="mx-auto mb-3 text-primary" strokeWidth={1.5} />
        <h1 className="text-2xl font-semibold mb-2">Clientes satisfechos</h1>
        <p className="text-text-muted">Esta sección aún no está disponible.</p>
      </div>
    )
  }

  return (
    <div className="py-6">
      <SatisfiedCustomersSection />
    </div>
  )
}
