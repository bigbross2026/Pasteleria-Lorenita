import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { CakeSlice } from 'lucide-react'
import CakeCarousel from '../../components/order/CakeCarousel'
import CakeLightbox from '../../components/order/CakeLightbox'
import CakeCustomizer from '../../components/order/CakeCustomizer'
import AddAnotherCakePrompt from '../../components/order/AddAnotherCakePrompt'
import BestSellersSection from '../../components/order/BestSellersSection'
import { useAdminData } from '../../data/AdminDataContext'
import { useOrder } from '../../context/OrderContext'

// Máquina de estados simple del flujo de creación de pasteles:
// 'carousel' -> elegir diseño
// 'customize' -> personalizar sabor/relleno/tamaño/fecha
// 'addAnother' -> preguntar si desea agregar otro pastel
export default function CreaTuPastel() {
  const navigate = useNavigate()
  const { addCake } = useOrder()
  const { getActiveDesigns } = useAdminData()
  const cakes = getActiveDesigns()

  const [step, setStep] = useState('carousel')
  const [selectedCake, setSelectedCake] = useState(null)
  const [expandedCake, setExpandedCake] = useState(null)

  function chooseCake(cake) {
    setSelectedCake(cake)
    setExpandedCake(null)
    setStep('customize')
  }

  function handleConfirmCake(cakeOrderItem) {
    addCake(cakeOrderItem)
    setStep('addAnother')
  }

  function handleAddAnother() {
    setSelectedCake(null)
    setStep('carousel')
  }

  function handleFinishCakes() {
    navigate('/?continuar=1')
  }

  return (
    <div className="max-w-6xl mx-auto px-5 py-10">
      <h1 className="text-3xl font-semibold mb-1 flex items-center gap-2">
        <CakeSlice className="text-primary" /> Crea tu pastel
      </h1>
      <p className="text-text-muted mb-8">Elige un diseño y personalízalo a tu gusto.</p>

      {cakes.length === 0 && (
        <p className="text-text-muted">Por ahora no hay diseños disponibles. Vuelve pronto.</p>
      )}

      {step === 'carousel' && cakes.length > 0 && (
        <>
          <CakeCarousel cakes={cakes} onExpand={setExpandedCake} onChoose={chooseCake} />
          <CakeLightbox cake={expandedCake} onClose={() => setExpandedCake(null)} onChoose={chooseCake} />
          <div className="mt-4">
            <BestSellersSection onChoose={chooseCake} />
          </div>
        </>
      )}

      {step === 'customize' && selectedCake && (
        <CakeCustomizer
          cake={selectedCake}
          onChangeDesign={() => setStep('carousel')}
          onConfirm={handleConfirmCake}
        />
      )}

      {step === 'addAnother' && (
        <AddAnotherCakePrompt onYes={handleAddAnother} onNo={handleFinishCakes} />
      )}
    </div>
  )
}
