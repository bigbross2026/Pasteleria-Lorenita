// La ruta /pasteles del menú de navegación apunta al mismo flujo que
// "Crea tu pastel" del menú principal, para no duplicar lógica.
export { default } from './CreaTuPastel'
