import { useParams, Link } from 'react-router-dom'
import { Download, ArrowLeft } from 'lucide-react'
import { useAdminData } from '../../data/AdminDataContext'
import CakeVisual from '../../components/order/CakeVisual'
import Button from '../../components/ui/Button'

// Esta es la página a la que apunta el enlace "Diseño" dentro del mensaje
// de WhatsApp. Cuando existan fotografías reales, el botón "Descargar"
// apuntará directamente al archivo de imagen en el servidor.
export default function DesignViewer() {
  const { cakeId } = useParams()
  const { designs } = useAdminData()
  const cake = designs.find((c) => c.id === cakeId)

  if (!cake) {
    return (
      <div className="max-w-lg mx-auto px-5 py-20 text-center">
        <h1 className="text-2xl font-semibold mb-2">Diseño no encontrado</h1>
        <p className="text-text-muted mb-6">Este enlace de diseño ya no está disponible.</p>
        <Link to="/">
          <Button variant="secondary" icon={ArrowLeft}>Volver al inicio</Button>
        </Link>
      </div>
    )
  }

  return (
    <div className="max-w-xl mx-auto px-5 py-14">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-text-muted hover:text-primary mb-6">
        <ArrowLeft size={16} /> Volver al inicio
      </Link>

      <h1 className="text-2xl font-semibold mb-1">{cake.name}</h1>
      <p className="text-text-muted mb-6">Diseño seleccionado para este pedido.</p>

      <CakeVisual cake={cake} aspect="aspect-square" big />

      {cake.imageUrl ? (
        <a href={cake.imageUrl} download target="_blank" rel="noreferrer">
          <Button className="mt-6" icon={Download}>Descargar imagen</Button>
        </a>
      ) : (
        <Button className="mt-6" icon={Download} disabled title="Esta categoría aún no tiene fotografía real cargada">
          Descargar imagen
        </Button>
      )}
    </div>
  )
}
