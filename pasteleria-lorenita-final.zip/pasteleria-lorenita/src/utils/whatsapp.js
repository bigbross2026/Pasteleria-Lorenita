// Construye el enlace de WhatsApp para el botón general de contacto
// ("Comunícate con nosotros"). El número real viene de la configuración
// del negocio (business.whatsappNumber, editable en el panel admin).
const DEFAULT_MESSAGE =
  'Hola, Pastelería Lorenita. Me gustaría recibir ayuda para realizar un pedido personalizado.'

export function getContactWhatsAppLink(whatsappNumber, message = DEFAULT_MESSAGE) {
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`
}
