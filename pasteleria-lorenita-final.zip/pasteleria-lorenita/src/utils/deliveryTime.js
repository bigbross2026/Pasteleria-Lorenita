// Reglas de negocio de entrega: el pedido debe hacerse con al menos 24
// horas de anticipación. Estas funciones se usan tanto para deshabilitar
// opciones inválidas en el selector como para validar antes de enviar.

const MIN_HOURS_NOTICE = 24

export function getMinimumDeliveryDate() {
  const min = new Date()
  min.setHours(min.getHours() + MIN_HOURS_NOTICE)
  return min
}

// Un día completo se habilita si existe al menos una hora válida ese día
// (es decir, si el día es posterior al día mínimo, o si es el mismo día
// mínimo pero aún quedan horas del día por delante).
export function isDateDisabled(dateStr) {
  const min = getMinimumDeliveryDate()
  const minDateOnly = toDateOnly(min)
  const candidate = toDateOnly(new Date(`${dateStr}T00:00:00`))
  return candidate < minDateOnly
}

export function isTimeDisabled(dateStr, timeStr) {
  const min = getMinimumDeliveryDate()
  const candidate = new Date(`${dateStr}T${timeStr}:00`)
  return candidate < min
}

function toDateOnly(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate())
}

// Genera las franjas horarias de atención (9:00 a 19:00 cada 30 min) para
// el selector de hora del día elegido.
export function getAvailableTimeSlots() {
  const slots = []
  for (let h = 9; h <= 19; h++) {
    for (const m of [0, 30]) {
      if (h === 19 && m === 30) continue
      const hh = String(h).padStart(2, '0')
      const mm = String(m).padStart(2, '0')
      slots.push(`${hh}:${mm}`)
    }
  }
  return slots
}

export function formatDateHuman(dateStr) {
  if (!dateStr) return ''
  const date = new Date(`${dateStr}T00:00:00`)
  return date.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
}
