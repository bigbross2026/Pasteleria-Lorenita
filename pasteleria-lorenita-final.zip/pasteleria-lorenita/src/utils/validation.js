// Saneamiento defensivo de campos de texto libre (mensajes del pastel,
// testimonios, campos de formularios del admin). React ya escapa el HTML
// al renderizar texto en JSX (no usamos dangerouslySetInnerHTML en ningún
// lugar de la app, así que no hay inyección de HTML/XSS por ese lado),
// pero igual normalizamos la entrada: quitamos etiquetas y recortamos
// espacios/longitud antes de guardarla, como buena práctica adicional y
// para que los datos que eventualmente viajen al backend ya lleguen limpios.
export function sanitizeText(value, maxLength = 500) {
  if (typeof value !== 'string') return ''
  return value
    .replace(/<[^>]*>/g, '') // quita etiquetas HTML
    .trim()
    .slice(0, maxLength)
}

export function isNonEmpty(value) {
  return typeof value === 'string' && value.trim().length > 0
}

export function isPositiveNumber(value) {
  const n = Number(value)
  return !Number.isNaN(n) && n >= 0
}
