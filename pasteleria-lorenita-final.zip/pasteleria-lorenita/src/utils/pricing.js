// Utilidades de cálculo de precio. Reciben directamente el recargo de la
// categoría (en vez de buscarlo internamente) para no depender de ninguna
// fuente de datos concreta: quien llama ya tiene la categoría a mano vía
// useAdminData().getCategoryById(...).
export function calculateCakePrice({ sizePrice, surcharge = 0 }) {
  return round2(sizePrice + surcharge)
}

export function calculateAdditionalProductPrice(tier) {
  return round2(tier.price)
}

export function round2(value) {
  return Math.round(value * 100) / 100
}

export function formatCurrency(value) {
  return `$${round2(value).toFixed(2)}`
}
