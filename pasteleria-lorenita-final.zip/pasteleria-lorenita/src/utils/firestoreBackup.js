import { collection, getDocs, doc, getDoc, setDoc, deleteDoc, writeBatch, query, orderBy } from 'firebase/firestore'
import { db } from '../firebase/config'
import { STORAGE_KEYS } from '../data/seedData'

const BACKUPS_COLLECTION = 'lorenita_backups'
const BUSINESS_DOC = ['settings', 'business']

// Colecciones que forman parte del respaldo (todo el catálogo, pedidos y
// testimonios). El documento de configuración del negocio se respalda
// aparte porque vive como documento único, no como colección.
const DATA_COLLECTIONS = [
  { key: 'categories', name: STORAGE_KEYS.categories },
  { key: 'designs', name: STORAGE_KEYS.designs },
  { key: 'flavors', name: STORAGE_KEYS.flavors },
  { key: 'fillings', name: STORAGE_KEYS.fillings },
  { key: 'sizes', name: STORAGE_KEYS.sizes },
  { key: 'additionalProducts', name: STORAGE_KEYS.additionalProducts },
  { key: 'promotions', name: STORAGE_KEYS.promotions },
  { key: 'testimonials', name: STORAGE_KEYS.testimonials },
  { key: 'orders', name: STORAGE_KEYS.orders }
]

// Lee el estado actual completo de la base de datos (todas las
// colecciones + configuración del negocio) y lo arma en un solo objeto
// serializable, listo para guardar como respaldo o descargar como .json.
export async function exportSnapshot() {
  const collections = {}
  for (const { key, name } of DATA_COLLECTIONS) {
    const snap = await getDocs(collection(db, name))
    collections[key] = snap.docs.map((d) => ({ id: d.id, ...d.data() }))
  }
  const businessSnap = await getDoc(doc(db, ...BUSINESS_DOC))
  return {
    exportedAt: new Date().toISOString(),
    business: businessSnap.exists() ? businessSnap.data() : null,
    collections
  }
}

// Guarda una copia del snapshot como un nuevo documento dentro de
// "lorenita_backups", para mantener varios respaldos disponibles en el
// tiempo (no solo el último). Devuelve el id del respaldo creado.
export async function saveBackupSnapshot(snapshotData, label) {
  const id = `backup-${Date.now()}`
  await setDoc(doc(db, BACKUPS_COLLECTION, id), {
    createdAt: snapshotData.exportedAt,
    label: label || null,
    data: JSON.stringify(snapshotData)
  })
  return id
}

export async function listBackups() {
  const q = query(collection(db, BACKUPS_COLLECTION), orderBy('createdAt', 'desc'))
  const snap = await getDocs(q)
  return snap.docs.map((d) => ({ id: d.id, createdAt: d.data().createdAt, label: d.data().label }))
}

export async function getBackupData(id) {
  const snap = await getDoc(doc(db, BACKUPS_COLLECTION, id))
  if (!snap.exists()) throw new Error('Ese respaldo ya no existe.')
  return JSON.parse(snap.data().data)
}

export async function deleteBackup(id) {
  await deleteDoc(doc(db, BACKUPS_COLLECTION, id))
}

// Reescribe todas las colecciones y la configuración del negocio con los
// datos del respaldo (por id de documento, así se preservan las
// relaciones como categoryId). No borra documentos que existan ahora pero
// no estén en el respaldo — para eso conviene limpiar manualmente antes.
export async function restoreSnapshot(snapshotData) {
  const batch = writeBatch(db)
  for (const { key, name } of DATA_COLLECTIONS) {
    const items = snapshotData.collections?.[key] || []
    items.forEach((item) => {
      const { id, ...rest } = item
      batch.set(doc(db, name, id), rest)
    })
  }
  if (snapshotData.business) {
    batch.set(doc(db, ...BUSINESS_DOC), snapshotData.business)
  }
  await batch.commit()
}

export function downloadSnapshotAsFile(snapshotData) {
  const blob = new Blob([JSON.stringify(snapshotData, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `respaldo-lorenita-${snapshotData.exportedAt.slice(0, 10)}.json`
  a.click()
  URL.revokeObjectURL(url)
}
