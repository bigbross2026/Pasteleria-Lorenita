// Regla de negocio del límite diario:
// - Si el límite está desactivado, no hay restricción.
// - Si está activado con un máximo N, un nuevo PEDIDO solo puede empezar
//   ese día si aún queda al menos 1 espacio (usados < N).
// - Una vez que el pedido ya comenzó ese día (el cliente está agregando
//   más de un pastel), se permite superar el máximo hasta en 2 pasteles
//   adicionales, porque pertenecen al mismo pedido/cliente.
// - Pasado ese margen (N + 2), no se aceptan más pasteles para ese día.

export function getUsedCakeCountForDate(orders, date) {
  return orders
    .filter((o) => o.status !== 'Cancelado')
    .flatMap((o) => o.cakes || [])
    .filter((c) => c.date === date).length
}

export function isDateBlockedForNewOrder(orders, dailyLimit, date) {
  if (!dailyLimit?.enabled) return false
  const used = getUsedCakeCountForDate(orders, date)
  return used >= dailyLimit.max
}

// cartCakesForDate: cuántos pasteles ya tiene el cliente en SU pedido en
// curso (aún no enviado) para esa misma fecha.
export function canAcceptOneMoreCake(orders, dailyLimit, date, cartCakesForDate) {
  if (!dailyLimit?.enabled) return true
  const used = getUsedCakeCountForDate(orders, date)
  const hardCap = dailyLimit.max + 2
  const totalIfAdded = used + cartCakesForDate + 1

  if (totalIfAdded <= dailyLimit.max) return true
  // Excedente permitido solo si el pedido ya tenía al menos un pastel ese
  // día (cartCakesForDate >= 1) y todavía había espacio cuando comenzó.
  if (cartCakesForDate >= 1 && used < dailyLimit.max && totalIfAdded <= hardCap) return true
  return false
}
