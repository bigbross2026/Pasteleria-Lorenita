// Calcula reportes agrupados (nunca cliente por cliente) a partir del
// historial de pedidos. Los pedidos cancelados se excluyen siempre.

export function getRangeForPeriod(period, referenceDate = new Date()) {
  const start = new Date(referenceDate)
  const end = new Date(referenceDate)

  if (period === 'daily') {
    start.setHours(0, 0, 0, 0)
    end.setHours(23, 59, 59, 999)
  } else if (period === 'weekly') {
    const day = start.getDay() // 0 = domingo
    const diffToMonday = day === 0 ? 6 : day - 1
    start.setDate(start.getDate() - diffToMonday)
    start.setHours(0, 0, 0, 0)
    end.setDate(start.getDate() + 6)
    end.setHours(23, 59, 59, 999)
  } else if (period === 'monthly') {
    start.setDate(1)
    start.setHours(0, 0, 0, 0)
    end.setMonth(start.getMonth() + 1, 0)
    end.setHours(23, 59, 59, 999)
  }
  return { start, end }
}

export function computeReport(orders, { start, end }) {
  const filtered = orders.filter((o) => {
    if (o.status === 'Cancelado') return false
    const created = new Date(o.createdAt)
    return created >= start && created <= end
  })

  const byCategory = {}
  const byPromotion = {}
  const byAdditionalProduct = {}
  let totalRevenue = 0

  filtered.forEach((order) => {
    totalRevenue += order.total || 0

    ;(order.cakes || []).forEach((c) => {
      const key = c.category || c.cake?.categoryId || 'sin-categoria'
      if (!byCategory[key]) byCategory[key] = { qty: 0, revenue: 0 }
      byCategory[key].qty += 1
      byCategory[key].revenue += c.price || 0
    })
    ;(order.promotions || []).forEach((p) => {
      const key = p.promotion?.id || 'promocion'
      if (!byPromotion[key]) byPromotion[key] = { qty: 0, revenue: 0, title: p.promotion?.title }
      byPromotion[key].qty += 1
      byPromotion[key].revenue += p.price || 0
    })
    ;(order.additionalProducts || []).forEach((p) => {
      const key = p.product?.id || 'producto'
      if (!byAdditionalProduct[key]) byAdditionalProduct[key] = { qty: 0, revenue: 0, name: p.product?.name }
      byAdditionalProduct[key].qty += p.quantity || 0
      byAdditionalProduct[key].revenue += p.price || 0
    })
  })

  return {
    orderCount: filtered.length,
    totalRevenue,
    byCategory,
    byPromotion,
    byAdditionalProduct
  }
}

// Estadísticas de TODO el historial (no filtradas por período), para el
// panel de estadísticas internas: conteo de pedidos por estado, y lo más
// elegido de cada aspecto del catálogo (pasteles, categorías, sabores,
// rellenos, tamaños, productos adicionales y promociones).
export function computeAllTimeStats(orders) {
  const stats = {
    total: orders.length,
    delivered: 0,
    pending: 0,
    cancelled: 0,
    byCake: {},
    byCategory: {},
    byFlavor: {},
    byFilling: {},
    bySize: {},
    byAdditionalProduct: {},
    byPromotion: {}
  }

  orders.forEach((order) => {
    if (order.status === 'Entregado') stats.delivered += 1
    else if (order.status === 'Cancelado') stats.cancelled += 1
    else stats.pending += 1

    if (order.status === 'Cancelado') return // no cuentan para "más elegidos"

    ;(order.cakes || []).forEach((c) => {
      const cakeName = c.cake?.name || 'Pastel'
      stats.byCake[cakeName] = (stats.byCake[cakeName] || 0) + 1

      const categoryKey = c.category || c.cake?.categoryId || 'Sin categoría'
      stats.byCategory[categoryKey] = (stats.byCategory[categoryKey] || 0) + 1

      if (c.flavor?.name) stats.byFlavor[c.flavor.name] = (stats.byFlavor[c.flavor.name] || 0) + 1
      if (c.filling?.name) stats.byFilling[c.filling.name] = (stats.byFilling[c.filling.name] || 0) + 1
      if (c.size?.label) stats.bySize[c.size.label] = (stats.bySize[c.size.label] || 0) + 1
    })
    ;(order.additionalProducts || []).forEach((p) => {
      const name = p.product?.name || 'Producto'
      stats.byAdditionalProduct[name] = (stats.byAdditionalProduct[name] || 0) + (p.quantity || 1)
    })
    ;(order.promotions || []).forEach((p) => {
      const title = p.promotion?.title || 'Promoción'
      stats.byPromotion[title] = (stats.byPromotion[title] || 0) + 1
    })
  })

  return stats
}

// Convierte un mapa { nombre: cantidad } en un arreglo ordenado de mayor a
// menor, listo para pintar en un gráfico de barras. `limit` recorta al
// top N (por defecto 5).
export function toChartData(map, limit = 5) {
  return Object.entries(map)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, limit)
}

// Ingresos agrupados por día/semana/mes para el gráfico de tendencia.
// `points` controla cuántos períodos hacia atrás se muestran.
export function computeRevenueTrend(orders, period, points = 7) {
  const validOrders = orders.filter((o) => o.status !== 'Cancelado')
  const buckets = []

  for (let i = points - 1; i >= 0; i--) {
    const reference = new Date()
    if (period === 'daily') reference.setDate(reference.getDate() - i)
    if (period === 'weekly') reference.setDate(reference.getDate() - i * 7)
    if (period === 'monthly') reference.setMonth(reference.getMonth() - i)

    const { start, end } = getRangeForPeriod(period, reference)
    const revenue = validOrders
      .filter((o) => {
        const created = new Date(o.createdAt)
        return created >= start && created <= end
      })
      .reduce((sum, o) => sum + (o.total || 0), 0)

    const label =
      period === 'daily'
        ? start.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })
        : period === 'weekly'
        ? `Sem. ${start.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}`
        : start.toLocaleDateString('es-ES', { month: 'short', year: '2-digit' })

    buckets.push({ label, revenue: Math.round(revenue * 100) / 100 })
  }

  return buckets
}
