import { createContext, useContext, useCallback } from 'react'
import { useCollection } from './useCollection'
import { useFirestoreDoc } from './useFirestoreDoc'
import {
  STORAGE_KEYS,
  SEED_CATEGORIES,
  SEED_DESIGNS,
  SEED_FLAVORS,
  SEED_FILLINGS,
  SEED_SIZES,
  SEED_ADDITIONAL_PRODUCTS,
  SEED_PROMOTIONS,
  SEED_TESTIMONIALS,
  SEED_BUSINESS_SETTINGS
} from './seedData'

const AdminDataContext = createContext(null)

export function AdminDataProvider({ children }) {
  const [categories, categoryOps] = useCollection(STORAGE_KEYS.categories, SEED_CATEGORIES)
  const [designs, designOps] = useCollection(STORAGE_KEYS.designs, SEED_DESIGNS)
  const [flavors, flavorOps] = useCollection(STORAGE_KEYS.flavors, SEED_FLAVORS)
  const [fillings, fillingOps] = useCollection(STORAGE_KEYS.fillings, SEED_FILLINGS)
  const [sizes, sizeOps] = useCollection(STORAGE_KEYS.sizes, SEED_SIZES)
  const [additionalProducts, additionalProductOps] = useCollection(STORAGE_KEYS.additionalProducts, SEED_ADDITIONAL_PRODUCTS)
  const [promotions, promotionOps] = useCollection(STORAGE_KEYS.promotions, SEED_PROMOTIONS)
  const [testimonials, testimonialOps] = useCollection(STORAGE_KEYS.testimonials, SEED_TESTIMONIALS)
  const [orders, orderOps] = useCollection(STORAGE_KEYS.orders, [])

  // Documento único "settings/business" en Firestore: nombre, WhatsApp,
  // logotipo, horario, contraseña del admin, módulos activos y límite
  // diario. Se sincroniza en tiempo real entre dispositivos.
  const [business, updateBusiness] = useFirestoreDoc('settings', 'business', SEED_BUSINESS_SETTINGS)

  const toggleModule = useCallback(
    (key) => {
      updateBusiness({ modules: { ...business.modules, [key]: !business.modules[key] } })
    },
    [business.modules, updateBusiness]
  )

  // ---- Selectores usados por el módulo cliente --------------------------
  const getActiveCategories = useCallback(() => categories.filter((c) => c.status === 'active'), [categories])

  const getActiveDesigns = useCallback(() => {
    const activeCategoryIds = new Set(getActiveCategories().map((c) => c.id))
    return designs.filter((d) => d.status === 'active' && activeCategoryIds.has(d.categoryId))
  }, [designs, getActiveCategories])

  const getActiveFlavors = useCallback(() => flavors.filter((f) => f.status === 'active'), [flavors])
  const getActiveFillings = useCallback(() => fillings.filter((f) => f.status === 'active'), [fillings])
  const getActiveSizes = useCallback(() => sizes.filter((s) => s.status === 'active'), [sizes])
  const getActiveAdditionalProducts = useCallback(
    () => additionalProducts.filter((p) => p.status === 'active'),
    [additionalProducts]
  )
  const getActivePromotions = useCallback(() => {
    const today = new Date().toISOString().slice(0, 10)
    return promotions.filter((p) => p.status === 'active' && p.startDate <= today && p.endDate >= today)
  }, [promotions])

  const getApprovedTestimonials = useCallback(
    () => testimonials.filter((t) => t.status === 'approved'),
    [testimonials]
  )
  const getPendingTestimonials = useCallback(
    () => testimonials.filter((t) => t.status === 'pending'),
    [testimonials]
  )

  const getCategoryById = useCallback((id) => categories.find((c) => c.id === id), [categories])

  const value = {
    categories,
    categoryOps,
    designs,
    designOps,
    flavors,
    flavorOps,
    fillings,
    fillingOps,
    sizes,
    sizeOps,
    additionalProducts,
    additionalProductOps,
    promotions,
    promotionOps,
    testimonials,
    testimonialOps,
    orders,
    orderOps,
    business,
    updateBusiness,
    toggleModule,
    getActiveCategories,
    getActiveDesigns,
    getActiveFlavors,
    getActiveFillings,
    getActiveSizes,
    getActiveAdditionalProducts,
    getActivePromotions,
    getApprovedTestimonials,
    getPendingTestimonials,
    getCategoryById
  }

  return <AdminDataContext.Provider value={value}>{children}</AdminDataContext.Provider>
}

export function useAdminData() {
  const ctx = useContext(AdminDataContext)
  if (!ctx) throw new Error('useAdminData debe usarse dentro de <AdminDataProvider>')
  return ctx
}
