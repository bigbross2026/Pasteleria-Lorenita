import { useCallback, useEffect, useRef, useState } from 'react'
import { doc, onSnapshot, setDoc, getDoc } from 'firebase/firestore'
import { db } from '../firebase/config'

// Igual que useCollection, pero para un documento único (por ejemplo la
// configuración general del negocio: nombre, WhatsApp, horario, módulos
// activos, límite diario, contraseña del admin). Se sincroniza en tiempo
// real entre dispositivos.
export function useFirestoreDoc(collectionName, docId, seed = {}) {
  const [data, setData] = useState(seed)
  const seededRef = useRef(false)

  useEffect(() => {
    const ref = doc(db, collectionName, docId)

    if (!seededRef.current) {
      seededRef.current = true
      getDoc(ref)
        .then((snap) => {
          if (!snap.exists()) return setDoc(ref, seed)
        })
        .catch((err) => console.warn(`No se pudo inicializar ${collectionName}/${docId}:`, err.message))
    }

    const unsubscribe = onSnapshot(
      ref,
      (snap) => {
        if (snap.exists()) setData({ ...seed, ...snap.data() })
      },
      (err) => console.warn(`No se pudo escuchar ${collectionName}/${docId}:`, err.message)
    )
    return unsubscribe
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionName, docId])

  const update = useCallback(
    async (patch) => {
      await setDoc(doc(db, collectionName, docId), patch, { merge: true })
    },
    [collectionName, docId]
  )

  return [data, update]
}
