// Datos con los que arranca el negocio la primera vez (equivalentes a los
// del Bloque 2, ahora editables desde el panel administrador). A partir de
// aquí, todo cambio real lo hace el admin y queda en localStorage bajo las
// claves STORAGE_KEYS.

export const STORAGE_KEYS = {
  categories: 'lorenita_categories',
  designs: 'lorenita_cake_designs',
  flavors: 'lorenita_flavors',
  fillings: 'lorenita_fillings',
  sizes: 'lorenita_sizes',
  additionalProducts: 'lorenita_additional_products_v2',
  promotions: 'lorenita_promotions_v2',
  testimonials: 'lorenita_testimonials',
  orders: 'lorenita_orders',
  business: 'lorenita_business_settings'
}

export const SEED_CATEGORIES = [
  { id: 'dorado', name: 'Dorado', emoji: '⭐', frameColor: '212 175 92', surcharge: 8, status: 'active' },
  { id: 'plateado', name: 'Plateado', emoji: '💎', frameColor: '176 184 192', surcharge: 5, status: 'active' },
  { id: 'bronce', name: 'Bronce', emoji: '🥉', frameColor: '176 120 74', surcharge: 6, status: 'active' },
  { id: 'verde', name: 'Verde', emoji: '🌸', frameColor: '90 168 110', surcharge: 4, status: 'active' },
  { id: 'azul', name: 'Azul', emoji: '💠', frameColor: '78 140 214', surcharge: 4, status: 'active' },
  { id: 'morado', name: 'Morado', emoji: '🎉', frameColor: '150 108 200', surcharge: 5, status: 'active' }
]

export const SEED_DESIGNS = [
  { id: 'c1', name: 'Rosas de Ensueño', categoryId: 'dorado', status: 'active' },
  { id: 'c2', name: 'Jardín Primaveral', categoryId: 'verde', status: 'active' },
  { id: 'c3', name: 'Elegancia Real', categoryId: 'morado', status: 'active' },
  { id: 'c4', name: 'Cielo Estrellado', categoryId: 'azul', status: 'active' },
  { id: 'c5', name: 'Toque Bronce', categoryId: 'bronce', status: 'active' },
  { id: 'c6', name: 'Brillo Plateado', categoryId: 'plateado', status: 'active' },
  { id: 'c7', name: 'Fiesta Tropical', categoryId: 'verde', status: 'active' },
  { id: 'c8', name: 'Encanto Dorado', categoryId: 'dorado', status: 'active' },
  { id: 'c9', name: 'Noche Violeta', categoryId: 'morado', status: 'active' },
  { id: 'c10', name: 'Ola Azul', categoryId: 'azul', status: 'active' }
]

export const SEED_FLAVORS = [
  { id: 'f1', name: 'Vainilla', status: 'active' },
  { id: 'f2', name: 'Chocolate', status: 'active' },
  { id: 'f3', name: 'Oreo', status: 'active' },
  { id: 'f4', name: 'Naranja', status: 'active' },
  { id: 'f5', name: 'Zanahoria', status: 'active' },
  { id: 'f6', name: 'Red Velvet', status: 'active' }
]

export const SEED_FILLINGS = [
  { id: 'r1', name: 'Mora', status: 'active' },
  { id: 'r2', name: 'Durazno', status: 'active' },
  { id: 'r3', name: 'Frutilla', status: 'active' }
]

export const SEED_SIZES = [
  { id: 's1', label: '8 porciones', price: 22, status: 'active' },
  { id: 's2', label: '12 porciones', price: 30, status: 'active' },
  { id: 's3', label: '15 porciones', price: 38, status: 'active' },
  { id: 's4', label: '20 porciones', price: 48, status: 'active' },
  { id: 's5', label: '50 porciones', price: 95, status: 'active' }
]

export const SEED_ADDITIONAL_PRODUCTS = [
  { id: 'a1', name: 'Bocaditos dulces', description: '', status: 'active', tiers: [{ qty: 10, price: 5 }, { qty: 20, price: 9 }, { qty: 50, price: 20 }] },
  { id: 'a2', name: 'Bocaditos salados', description: '', status: 'active', tiers: [{ qty: 10, price: 5.5 }, { qty: 20, price: 10 }, { qty: 50, price: 22 }] },
  { id: 'a3', name: 'Gelatinas', description: '', status: 'active', tiers: [{ qty: 10, price: 4 }, { qty: 20, price: 7 }, { qty: 50, price: 16 }] },
  { id: 'a4', name: 'Tequeños', description: '', status: 'active', tiers: [{ qty: 10, price: 6 }, { qty: 20, price: 11 }, { qty: 50, price: 25 }] },
  { id: 'a5', name: 'Pastelitos de carne', description: '', status: 'active', tiers: [{ qty: 10, price: 6.5 }, { qty: 20, price: 12 }, { qty: 50, price: 27 }] }
]

export const SEED_PROMOTIONS = [
  {
    id: 'p1',
    title: '2x1 en Bocaditos',
    description: 'Lleva el doble de bocaditos dulces al pedir cualquier pastel de 20 porciones o más.',
    price: 9,
    startDate: '2026-06-15',
    endDate: '2026-08-31',
    status: 'active'
  },
  {
    id: 'p2',
    title: 'Pastel + Gelatinas',
    description: 'Combo especial: pastel de 15 porciones más 20 gelatinas de regalo.',
    price: 42,
    startDate: '2026-06-01',
    endDate: '2026-08-15',
    status: 'active'
  }
]

export const SEED_TESTIMONIALS = [
  { id: 't1', message: '¡El pastel llegó exactamente como lo pedí! Delicioso y hermoso, superó lo que imaginé.', photos: [{ id: 'ph1' }, { id: 'ph2' }, { id: 'ph3' }], status: 'approved', createdAt: '2026-05-20T10:00:00.000Z' },
  { id: 't2', message: 'Excelente atención y el sabor red velvet quedó perfecto. Repetiré sin duda.', photos: [{ id: 'ph4' }, { id: 'ph5' }], status: 'approved', createdAt: '2026-05-25T10:00:00.000Z' },
  { id: 't3', message: 'Pedido a tiempo, muy bien decorado y todos en la fiesta preguntaron dónde lo compré.', photos: [{ id: 'ph6' }, { id: 'ph7' }, { id: 'ph8' }, { id: 'ph9' }], status: 'approved', createdAt: '2026-06-02T10:00:00.000Z' }
]

export const SEED_BUSINESS_SETTINGS = {
  businessName: 'Pastelería Lorenita',
  whatsappNumber: '0000000000',
  logoLabel: 'Sin logotipo cargado',
  logoUrl: null,
  adminBootstrapped: false, // ⚠️ ver src/firebase/auth.js — la contraseña real vive en Firebase Auth, no aquí
  hours: { open: '09:00', close: '19:00', days: 'Lunes a sábado' },
  dailyLimit: { enabled: false, max: 10 },
  modules: { promotions: true, additionalProducts: true, satisfiedCustomers: true }
}
