import { useCallback, useEffect, useRef, useState } from 'react'
import {
  collection,
  onSnapshot,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  writeBatch
} from 'firebase/firestore'
import { db } from '../firebase/config'

// -----------------------------------------------------------------------
// Hook genérico de colección, ahora respaldado por Firestore en tiempo
// real en vez de localStorage. Mantiene EXACTAMENTE la misma forma de
// retorno que antes — [items, { add, update, remove, removeMany, setAll }]
// — para que ningún componente que ya consumía useCollection() tenga que
// cambiar una sola línea.
//
// Comportamiento:
// - Se suscribe con onSnapshot: cualquier cambio hecho desde OTRO
//   dispositivo/pestaña se refleja aquí automáticamente, en vivo.
// - Si la colección está vacía la primera vez (proyecto recién creado),
//   se siembra automáticamente con `seed` usando los MISMOS ids del seed,
//   así las relaciones entre colecciones (ej. cakeDesign.categoryId)
//   siguen siendo válidas.
// -----------------------------------------------------------------------

let idCounter = 0
export function generateId(prefix = 'id') {
  idCounter += 1
  return `${prefix}-${Date.now()}-${idCounter}`
}

async function seedIfEmpty(collectionName, seed) {
  if (!seed || seed.length === 0) return
  try {
    const snapshot = await getDocs(collection(db, collectionName))
    if (!snapshot.empty) return
    const batch = writeBatch(db)
    seed.forEach((item) => {
      const { id, ...rest } = item
      batch.set(doc(db, collectionName, id || generateId(collectionName)), rest)
    })
    await batch.commit()
  } catch (err) {
    // Si falla la siembra (ej. sin conexión), la app sigue funcionando
    // con los datos que logre recibir por onSnapshot más adelante.
    console.warn(`No se pudo sembrar la colección "${collectionName}":`, err.message)
  }
}

export function useCollection(collectionName, seed = []) {
  // Mientras llega la primera respuesta de Firestore, mostramos el seed
  // como contenido provisional para que la interfaz no aparezca vacía.
  const [items, setItems] = useState(seed)
  const seededRef = useRef(false)

  useEffect(() => {
    if (!seededRef.current) {
      seededRef.current = true
      seedIfEmpty(collectionName, seed)
    }

    const unsubscribe = onSnapshot(
      collection(db, collectionName),
      (snapshot) => {
        setItems(snapshot.docs.map((d) => ({ id: d.id, ...d.data() })))
      },
      (err) => {
        console.warn(`No se pudo escuchar la colección "${collectionName}":`, err.message)
      }
    )
    return unsubscribe
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionName])

  const add = useCallback(
    async (item) => {
      const id = item.id || generateId(collectionName)
      const { id: _drop, ...rest } = item
      await setDoc(doc(db, collectionName, id), rest)
      return { id, ...rest }
    },
    [collectionName]
  )

  const update = useCallback(
    async (id, patch) => {
      await updateDoc(doc(db, collectionName, id), patch)
    },
    [collectionName]
  )

  const remove = useCallback(
    async (id) => {
      await deleteDoc(doc(db, collectionName, id))
    },
    [collectionName]
  )

  const removeMany = useCallback(
    async (ids) => {
      const batch = writeBatch(db)
      ids.forEach((id) => batch.delete(doc(db, collectionName, id)))
      await batch.commit()
    },
    [collectionName]
  )

  // Reemplaza toda la colección (poco usado; se conserva por compatibilidad).
  const setAll = useCallback(
    async (next) => {
      const batch = writeBatch(db)
      next.forEach((item) => {
        const { id, ...rest } = item
        batch.set(doc(db, collectionName, id || generateId(collectionName)), rest)
      })
      await batch.commit()
    },
    [collectionName]
  )

  return [items, { add, update, remove, removeMany, setAll }]
}
