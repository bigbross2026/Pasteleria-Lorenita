import { useEffect, useState } from 'react'
import { doc, runTransaction, setDoc, increment, onSnapshot } from 'firebase/firestore'
import { db } from '../firebase/config'

const COUNTER_REF_PATH = ['counters', 'orders']
const STATS_REF_PATH = ['stats', 'cakeStats']

// Genera el siguiente número de pedido de forma ATÓMICA usando una
// transacción de Firestore. Esto es importante: si dos clientes finalizan
// un pedido al mismo tiempo desde dispositivos distintos, cada uno debe
// recibir un número distinto y consecutivo — algo que un contador en
// localStorage (por navegador) no puede garantizar en producción.
export async function getNextOrderNumber() {
  const ref = doc(db, ...COUNTER_REF_PATH)
  const next = await runTransaction(db, async (transaction) => {
    const snap = await transaction.get(ref)
    const current = snap.exists() ? snap.data().value || 99 : 99
    const value = current + 1
    transaction.set(ref, { value }, { merge: true })
    return value
  })
  return `Pedido-${String(next).padStart(5, '0')}`
}

// Suma 1 a las estadísticas de cada pastel pedido. No se espera a que
// termine (no debe retrasar el envío del pedido por WhatsApp); cualquier
// fallo de red se reintentará solo la próxima vez que el navegador tenga
// conexión, gracias a la persistencia offline de Firestore.
export function bumpCakeStats(cakeIds) {
  if (!cakeIds || cakeIds.length === 0) return
  const ref = doc(db, ...STATS_REF_PATH)
  const patch = {}
  cakeIds.forEach((id) => {
    patch[`counts.${id}`] = increment(1)
  })
  setDoc(ref, patch, { merge: true }).catch((err) => console.warn('No se pudo actualizar estadísticas:', err.message))
}

// Hook en tiempo real con los conteos actuales por pastel: { [cakeId]: n }
export function useCakeStats() {
  const [counts, setCounts] = useState({})

  useEffect(() => {
    const ref = doc(db, ...STATS_REF_PATH)
    const unsubscribe = onSnapshot(
      ref,
      (snap) => setCounts(snap.exists() ? snap.data().counts || {} : {}),
      (err) => console.warn('No se pudo escuchar estadísticas:', err.message)
    )
    return unsubscribe
  }, [])

  return counts
}
