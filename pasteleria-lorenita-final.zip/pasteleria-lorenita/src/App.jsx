import { lazy, Suspense } from 'react'
import { Routes, Route } from 'react-router-dom'
import { Loader2 } from 'lucide-react'
import PublicLayout from './components/layout/PublicLayout'
import AdminLayout from './components/layout/AdminLayout'
import Home from './pages/client/Home'

// Carga diferida (lazy loading): el código de cada página solo se
// descarga cuando el usuario navega a ella. Esto es especialmente
// valioso para el panel administrador (formularios, PDF, gráficos), que
// un cliente normal jamás llega a descargar.
const Pasteles = lazy(() => import('./pages/client/Pasteles'))
const CreaTuPastel = lazy(() => import('./pages/client/CreaTuPastel'))
const DesignViewer = lazy(() => import('./pages/client/DesignViewer'))
const Promociones = lazy(() => import('./pages/client/Promociones'))
const ClientesSatisfechos = lazy(() => import('./pages/client/ClientesSatisfechos'))
const Contacto = lazy(() => import('./pages/client/Contacto'))

const Login = lazy(() => import('./pages/admin/Login'))
const Dashboard = lazy(() => import('./pages/admin/Dashboard'))
const PedidosAdmin = lazy(() => import('./pages/admin/modules/Pedidos'))
const PastelesAdmin = lazy(() => import('./pages/admin/modules/pasteles/Pasteles'))
const PromocionesAdmin = lazy(() => import('./pages/admin/modules/Promociones'))
const ProductosAdicionales = lazy(() => import('./pages/admin/modules/ProductosAdicionales'))
const ClientesSatisfechosAdmin = lazy(() => import('./pages/admin/modules/ClientesSatisfechos'))
const Reportes = lazy(() => import('./pages/admin/modules/Reportes'))
const Configuracion = lazy(() => import('./pages/admin/modules/Configuracion'))

function RouteLoadingFallback() {
  return (
    <div className="flex items-center justify-center py-24" role="status" aria-live="polite">
      <Loader2 size={28} className="animate-spin text-primary" />
      <span className="sr-only">Cargando…</span>
    </div>
  )
}

export default function App() {
  return (
    <Suspense fallback={<RouteLoadingFallback />}>
      <Routes>
        {/* Módulo Cliente */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/pasteles" element={<Pasteles />} />
          <Route path="/crea-tu-pastel" element={<CreaTuPastel />} />
          <Route path="/diseno/:cakeId" element={<DesignViewer />} />
          <Route path="/promociones" element={<Promociones />} />
          <Route path="/clientes-satisfechos" element={<ClientesSatisfechos />} />
          <Route path="/contacto" element={<Contacto />} />
        </Route>

        {/* Acceso administrador (sin layout de admin, es la puerta de entrada) */}
        <Route path="/admin/acceso" element={<Login />} />

        {/* Módulo Administrador (protegido) */}
        <Route element={<AdminLayout />}>
          <Route path="/admin" element={<Dashboard />} />
          <Route path="/admin/pedidos" element={<PedidosAdmin />} />
          <Route path="/admin/pasteles" element={<PastelesAdmin />} />
          <Route path="/admin/promociones" element={<PromocionesAdmin />} />
          <Route path="/admin/productos-adicionales" element={<ProductosAdicionales />} />
          <Route path="/admin/clientes-satisfechos" element={<ClientesSatisfechosAdmin />} />
          <Route path="/admin/reportes" element={<Reportes />} />
          <Route path="/admin/configuracion" element={<Configuracion />} />
        </Route>
      </Routes>
    </Suspense>
  )
}
