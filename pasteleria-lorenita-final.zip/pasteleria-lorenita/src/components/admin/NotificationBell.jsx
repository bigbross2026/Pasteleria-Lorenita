import { useMemo, useState, useRef, useEffect } from 'react'
import { Bell, ClipboardList, Heart, CalendarClock, Gauge } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAdminData } from '../../data/AdminDataContext'
import { getUsedCakeCountForDate } from '../../utils/dailyLimit'

const ICONS = { order: ClipboardList, testimonial: Heart, promo: CalendarClock, limit: Gauge }

export default function NotificationBell() {
  const { orders, testimonials, promotions, business } = useAdminData()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    function onClickOutside(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onClickOutside)
    return () => document.removeEventListener('mousedown', onClickOutside)
  }, [])

  const alerts = useMemo(() => {
    const list = []

    const pendingOrders = orders.filter((o) => o.status === 'Pendiente')
    if (pendingOrders.length > 0) {
      list.push({
        type: 'order',
        text: `${pendingOrders.length} pedido(s) nuevo(s) por revisar`,
        to: '/admin/pedidos'
      })
    }

    const pendingTestimonials = testimonials.filter((t) => t.status === 'pending')
    if (pendingTestimonials.length > 0) {
      list.push({
        type: 'testimonial',
        text: `${pendingTestimonials.length} publicación(es) pendiente(s) de aprobación`,
        to: '/admin/clientes-satisfechos'
      })
    }

    const today = new Date().toISOString().slice(0, 10)
    const soon = new Date()
    soon.setDate(soon.getDate() + 3)
    const soonStr = soon.toISOString().slice(0, 10)
    promotions
      .filter((p) => p.status === 'active' && p.endDate >= today && p.endDate <= soonStr)
      .forEach((p) => {
        list.push({ type: 'promo', text: `La promoción "${p.title}" vence pronto (${p.endDate})`, to: '/admin/promociones' })
      })

    if (business.dailyLimit?.enabled) {
      const usedToday = getUsedCakeCountForDate(orders, today)
      if (usedToday >= business.dailyLimit.max) {
        list.push({ type: 'limit', text: 'Se alcanzó el límite diario de producción de hoy', to: '/admin/pedidos' })
      }
    }

    return list
  }, [orders, testimonials, promotions, business.dailyLimit])

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label={`Notificaciones${alerts.length > 0 ? ` (${alerts.length} nuevas)` : ''}`}
        className="relative p-2 rounded-full hover:bg-surface transition-colors text-text-muted hover:text-primary"
      >
        <Bell size={20} />
        {alerts.length > 0 && (
          <span className="absolute top-0.5 right-0.5 h-4 w-4 rounded-full bg-accent text-[10px] font-bold text-button-text flex items-center justify-center">
            {alerts.length}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-72 bg-card rounded-card shadow-lift p-3 z-50 animate-fade-in-up">
          <p className="text-sm font-semibold mb-2 px-1">Notificaciones</p>
          {alerts.length === 0 ? (
            <p className="text-sm text-text-muted px-1 py-2">No hay nada pendiente por ahora.</p>
          ) : (
            <ul className="space-y-1">
              {alerts.map((a, i) => {
                const Icon = ICONS[a.type]
                return (
                  <li key={i}>
                    <Link
                      to={a.to}
                      onClick={() => setOpen(false)}
                      className="flex items-start gap-2 text-sm px-2 py-2 rounded-xl hover:bg-surface transition-colors"
                    >
                      <Icon size={16} className="text-primary mt-0.5 shrink-0" />
                      <span>{a.text}</span>
                    </Link>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  )
}
