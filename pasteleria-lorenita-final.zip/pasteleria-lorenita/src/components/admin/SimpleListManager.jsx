import { useState } from 'react'
import { Plus, Pencil, Trash2, Check, X, Power } from 'lucide-react'
import Button from '../ui/Button'
import Card from '../ui/Card'
import { sanitizeText, isNonEmpty, isPositiveNumber } from '../../utils/validation'

// Gestor CRUD genérico para colecciones simples: sabores y rellenos usan
// un solo campo de texto ("name"); tamaños agregan un campo de precio.
// `fields` describe qué columnas editar: [{ key, label, type: 'text'|'number' }]
export default function SimpleListManager({ items, ops, fields, emptyState }) {
  const [draft, setDraft] = useState(null) // null = sin formulario abierto
  const [editingId, setEditingId] = useState(null)

  function emptyDraft() {
    const base = {}
    fields.forEach((f) => { base[f.key] = f.type === 'number' ? 0 : '' })
    return base
  }

  function startCreate() {
    setDraft(emptyDraft())
    setEditingId(null)
  }

  function startEdit(item) {
    setEditingId(item.id)
    setDraft(fields.reduce((acc, f) => ({ ...acc, [f.key]: item[f.key] }), {}))
  }

  function cancelEdit() {
    setDraft(null)
    setEditingId(null)
  }

  function validDraft() {
    return fields.every((f) => {
      if (f.type === 'number') return isPositiveNumber(draft[f.key])
      return isNonEmpty(draft[f.key])
    })
  }

  function saveDraft() {
    if (!validDraft()) return
    const clean = {}
    fields.forEach((f) => {
      clean[f.key] = f.type === 'number' ? Number(draft[f.key]) : sanitizeText(draft[f.key], 80)
    })
    if (editingId) {
      ops.update(editingId, clean)
    } else {
      ops.add({ ...clean, status: 'active' })
    }
    cancelEdit()
  }

  function toggleStatus(item) {
    ops.update(item.id, { status: item.status === 'active' ? 'inactive' : 'active' })
  }

  function handleDelete(item) {
    if (window.confirm(`¿Eliminar "${item[fields[0].key]}"? Esta acción no se puede deshacer.`)) {
      ops.remove(item.id)
    }
  }

  return (
    <div>
      {items.length === 0 && !draft && <p className="text-text-muted mb-4">{emptyState || 'Aún no hay elementos.'}</p>}

      <div className="space-y-2 mb-4">
        {items.map((item) => (
          <div key={item.id} className="flex items-center justify-between gap-3 bg-card rounded-card shadow-soft px-4 py-3">
            {editingId === item.id ? (
              <div className="flex flex-1 gap-2 flex-wrap items-center">
                {fields.map((f) => (
                  <input
                    key={f.key}
                    type={f.type === 'number' ? 'number' : 'text'}
                    value={draft[f.key]}
                    onChange={(e) => setDraft((d) => ({ ...d, [f.key]: e.target.value }))}
                    placeholder={f.label}
                    className="rounded-pill border border-secondary px-3 py-1.5 bg-surface outline-none text-sm flex-1 min-w-[100px]"
                  />
                ))}
                <button onClick={saveDraft} className="text-primary hover:opacity-70"><Check size={20} /></button>
                <button onClick={cancelEdit} className="text-text-muted hover:opacity-70"><X size={20} /></button>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3">
                  <span className={`h-2.5 w-2.5 rounded-full ${item.status === 'active' ? 'bg-primary' : 'bg-secondary'}`} />
                  <span className="font-medium">
                    {fields.map((f) => (f.type === 'number' ? `${item[f.key]}${f.suffix || ''}` : item[f.key])).join(' — ')}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <button onClick={() => toggleStatus(item)} className="text-text-muted hover:text-primary" title="Activar/Desactivar">
                    <Power size={18} />
                  </button>
                  <button onClick={() => startEdit(item)} className="text-text-muted hover:text-primary" title="Editar">
                    <Pencil size={18} />
                  </button>
                  <button onClick={() => handleDelete(item)} className="text-text-muted hover:text-primary" title="Eliminar">
                    <Trash2 size={18} />
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {draft && !editingId ? (
        <Card className="flex flex-wrap gap-2 items-center">
          {fields.map((f) => (
            <input
              key={f.key}
              type={f.type === 'number' ? 'number' : 'text'}
              value={draft[f.key]}
              onChange={(e) => setDraft((d) => ({ ...d, [f.key]: e.target.value }))}
              placeholder={f.label}
              className="rounded-pill border border-secondary px-3 py-2 bg-surface outline-none text-sm flex-1 min-w-[120px]"
            />
          ))}
          <Button size="sm" onClick={saveDraft}>Guardar</Button>
          <Button size="sm" variant="secondary" onClick={cancelEdit}>Cancelar</Button>
        </Card>
      ) : (
        <Button size="sm" variant="secondary" icon={Plus} onClick={startCreate}>
          Agregar nuevo
        </Button>
      )}
    </div>
  )
}
