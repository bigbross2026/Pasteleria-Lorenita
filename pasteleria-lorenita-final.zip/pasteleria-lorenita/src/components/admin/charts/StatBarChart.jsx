import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'

const BAR_COLOR = 'rgb(224 55 84)' // coincide con --color-primary por defecto; recharts no lee variables CSS

// Gráfico de barras horizontal para un top N (categorías, sabores,
// rellenos, tamaños, productos adicionales, promociones, pasteles).
// `data` ya viene ordenado y recortado por utils/reports.js#toChartData.
export default function StatBarChart({ data, emptyText = 'Sin datos en este período.' }) {
  if (!data || data.length === 0) {
    return <p className="text-sm text-text-muted">{emptyText}</p>
  }

  return (
    <ResponsiveContainer width="100%" height={Math.max(120, data.length * 40)}>
      <BarChart data={data} layout="vertical" margin={{ left: 8, right: 16, top: 4, bottom: 4 }}>
        <XAxis type="number" hide />
        <YAxis type="category" dataKey="name" width={110} tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
        <Tooltip cursor={{ fill: 'rgba(0,0,0,0.04)' }} />
        <Bar dataKey="value" radius={[0, 8, 8, 0]} barSize={18}>
          {data.map((_, i) => (
            <Cell key={i} fill={BAR_COLOR} fillOpacity={1 - i * 0.12} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}
