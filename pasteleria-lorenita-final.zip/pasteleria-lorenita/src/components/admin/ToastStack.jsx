import { CheckCircle2, AlertTriangle, Info, X } from 'lucide-react'
import { useNotify } from '../../context/NotificationContext'

const ICONS = { success: CheckCircle2, error: AlertTriangle, info: Info }
const COLORS = {
  success: 'bg-primary text-button-text',
  error: 'bg-accent text-button-text',
  info: 'bg-card text-text-main border border-secondary'
}

export default function ToastStack() {
  const { toasts, dismiss } = useNotify()

  if (toasts.length === 0) return null

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 w-[calc(100%-2rem)] max-w-sm" role="status" aria-live="polite">
      {toasts.map((t) => {
        const Icon = ICONS[t.type] || Info
        return (
          <div
            key={t.id}
            className={`flex items-center gap-2 rounded-pill shadow-lift px-4 py-3 text-sm font-medium animate-fade-in-up ${COLORS[t.type] || COLORS.info}`}
          >
            <Icon size={18} className="shrink-0" aria-hidden="true" />
            <span className="flex-1">{t.message}</span>
            <button onClick={() => dismiss(t.id)} aria-label="Cerrar notificación" className="shrink-0 opacity-80 hover:opacity-100">
              <X size={14} />
            </button>
          </div>
        )
      })}
    </div>
  )
}
