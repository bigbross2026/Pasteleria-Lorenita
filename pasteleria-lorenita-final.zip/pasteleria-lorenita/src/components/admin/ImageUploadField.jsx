import { useState } from 'react'
import { ImagePlus, Loader2, AlertTriangle } from 'lucide-react'
import PlaceholderMedia from '../ui/PlaceholderMedia'
import { uploadImage } from '../../firebase/storage'

// Campo reutilizable: botón para elegir una imagen, la sube a Firebase
// Storage (con validación de tipo/tamaño) y devuelve { url, path } por
// `onUploaded`. Se usa en categorías/diseños, productos, promociones,
// logotipo del negocio y testimonios.
export default function ImageUploadField({ folder, currentUrl, label = 'Fotografía', onUploaded, aspect = 'aspect-square' }) {
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState(null)

  async function handleChange(e) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    setUploading(true)
    setError(null)
    try {
      const result = await uploadImage(file, folder)
      onUploaded(result)
    } catch (err) {
      setError(err.message)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div>
      <PlaceholderMedia label={currentUrl ? '' : label} imageUrl={currentUrl} aspect={aspect} className="mb-2" />
      <label className="inline-flex items-center gap-1.5 text-sm font-medium text-primary cursor-pointer">
        {uploading ? <Loader2 size={16} className="animate-spin" /> : <ImagePlus size={16} />}
        {uploading ? 'Subiendo…' : currentUrl ? 'Cambiar imagen' : 'Subir imagen'}
        <input type="file" accept="image/*" className="hidden" onChange={handleChange} disabled={uploading} />
      </label>
      {error && (
        <p className="text-xs text-primary-dark mt-1 flex items-center gap-1">
          <AlertTriangle size={12} /> {error}
        </p>
      )}
    </div>
  )
}
