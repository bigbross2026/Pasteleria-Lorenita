import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'

export default function AdminModuleHeader({ title, description, icon: Icon }) {
  return (
    <div className="mb-6">
      <Link to="/admin" className="inline-flex items-center gap-1 text-sm text-text-muted hover:text-primary mb-4">
        <ArrowLeft size={16} /> Volver al menú
      </Link>
      <h1 className="text-2xl font-semibold mb-1 flex items-center gap-2">
        {Icon && <Icon className="text-primary" size={26} />} {title}
      </h1>
      {description && <p className="text-text-muted">{description}</p>}
    </div>
  )
}
