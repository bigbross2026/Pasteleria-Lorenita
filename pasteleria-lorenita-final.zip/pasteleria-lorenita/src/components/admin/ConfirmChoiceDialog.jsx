import Modal from '../common/Modal'
import Button from '../ui/Button'
import { AlertTriangle } from 'lucide-react'

// A diferencia de window.confirm (solo Sí/No), este diálogo permite más
// de dos opciones — necesario para "eliminar categoría": el admin puede
// eliminar también las fotos asociadas, o conservarlas y moverlas.
export default function ConfirmChoiceDialog({ open, title, description, choices, onClose }) {
  return (
    <Modal open={open} onClose={onClose} size="sm">
      <div className="text-center">
        <AlertTriangle size={36} className="mx-auto mb-3 text-primary" />
        <h3 className="text-lg font-semibold mb-2">{title}</h3>
        {description && <p className="text-text-muted text-sm mb-6">{description}</p>}
        <div className="flex flex-col gap-2">
          {choices.map((choice) => (
            <Button
              key={choice.label}
              variant={choice.variant || 'secondary'}
              onClick={() => {
                choice.onSelect()
                onClose()
              }}
              fullWidth
            >
              {choice.label}
            </Button>
          ))}
        </div>
      </div>
    </Modal>
  )
}
