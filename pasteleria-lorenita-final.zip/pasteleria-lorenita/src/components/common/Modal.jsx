import { useEffect } from 'react'
import { X } from 'lucide-react'

// Modal base usado por el tutorial de bienvenida, la vista ampliada de
// diseños, el formulario "Compartir mi experiencia" y el resumen final.
export default function Modal({ open, onClose, children, size = 'md', showClose = true }) {
  useEffect(() => {
    if (!open) return
    function onKey(e) {
      if (e.key === 'Escape' && onClose) onClose()
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  if (!open) return null

  const widths = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fade-in-up"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className={`relative w-full ${widths[size]} bg-card rounded-card shadow-lift p-6 sm:p-8 max-h-[90vh] overflow-y-auto`}
        onClick={(e) => e.stopPropagation()}
      >
        {showClose && (
          <button
            onClick={onClose}
            aria-label="Cerrar"
            className="absolute top-4 right-4 p-1.5 rounded-full text-text-muted hover:bg-surface hover:text-primary transition-colors"
          >
            <X size={20} />
          </button>
        )}
        {children}
      </div>
    </div>
  )
}
