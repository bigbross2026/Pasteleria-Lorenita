import { useState } from 'react'
import { ShoppingBag, Plus } from 'lucide-react'
import Card from '../ui/Card'
import Button from '../ui/Button'
import PlaceholderMedia from '../ui/PlaceholderMedia'
import { calculateAdditionalProductPrice, formatCurrency } from '../../utils/pricing'
import { useOrder } from '../../context/OrderContext'
import { useAdminData } from '../../data/AdminDataContext'

function AdditionalProductCard({ product }) {
  const { addAdditionalProduct } = useOrder()
  const [selectedTier, setSelectedTier] = useState(null)

  function handleAdd() {
    if (!selectedTier) return
    addAdditionalProduct({
      product,
      tier: selectedTier,
      quantity: selectedTier.qty,
      price: calculateAdditionalProductPrice(selectedTier)
    })
    setSelectedTier(null)
  }

  return (
    <Card hoverable>
      <PlaceholderMedia label={product.name} imageUrl={product.imageUrl} aspect="aspect-[4/3]" className="mb-3" />
      <h4 className="font-semibold mb-2">{product.name}</h4>
      <div className="flex flex-wrap gap-2 mb-3">
        {product.tiers.map((tier) => {
          const isSelected = selectedTier?.qty === tier.qty
          return (
            <button
              key={tier.qty}
              onClick={() => setSelectedTier(tier)}
              className={[
                'text-sm font-medium rounded-pill px-3 py-1.5 border-2 transition-all',
                isSelected
                  ? 'bg-primary text-button-text border-primary'
                  : 'bg-surface text-text-main border-secondary hover:border-primary'
              ].join(' ')}
            >
              {tier.qty}u — {formatCurrency(tier.price)}
            </button>
          )
        })}
      </div>
      <Button size="sm" fullWidth icon={Plus} disabled={!selectedTier} onClick={handleAdd}>
        Agregar al pedido
      </Button>
    </Card>
  )
}

export default function AdditionalProductsSection() {
  const { business, getActiveAdditionalProducts } = useAdminData()
  const products = getActiveAdditionalProducts()
  if (!business.modules.additionalProducts || products.length === 0) return null

  return (
    <section className="max-w-6xl mx-auto px-5 py-10">
      <h2 className="text-2xl font-semibold mb-2 flex items-center gap-2">
        <ShoppingBag className="text-primary" /> Productos adicionales
      </h2>
      <p className="text-text-muted mb-5">Complementa tu pedido con estos deliciosos extras.</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {products.map((p) => (
          <AdditionalProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  )
}
