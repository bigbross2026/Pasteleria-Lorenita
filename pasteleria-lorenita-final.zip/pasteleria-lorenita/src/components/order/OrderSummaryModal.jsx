import { useState } from 'react'
import { MessageCircle, Trash2, PartyPopper } from 'lucide-react'
import Modal from '../common/Modal'
import Button from '../ui/Button'
import { useOrder } from '../../context/OrderContext'
import { formatCurrency } from '../../utils/pricing'
import { formatDateHuman } from '../../utils/deliveryTime'

export default function OrderSummaryModal({ open, onClose }) {
  const { cakes, additionalProducts, promotionsInOrder, total, removeCake, removeAdditionalProduct, removePromotion, submitOrder, itemCount, submitting } = useOrder()
  const [confirmedNumber, setConfirmedNumber] = useState(null)

  async function handleFinish() {
    const orderNumber = await submitOrder()
    if (orderNumber) setConfirmedNumber(orderNumber)
  }

  function handleClose() {
    setConfirmedNumber(null)
    onClose()
  }

  if (confirmedNumber) {
    return (
      <Modal open={open} onClose={handleClose} size="sm">
        <div className="text-center py-4">
          <PartyPopper size={44} className="mx-auto mb-3 text-primary" />
          <h3 className="text-xl font-semibold mb-2">¡Pedido enviado!</h3>
          <p className="text-text-muted mb-1">Tu número de pedido es</p>
          <p className="text-2xl font-display font-bold text-primary mb-5">{confirmedNumber}</p>
          <p className="text-sm text-text-muted mb-5">
            Se abrió WhatsApp con todos los detalles listos para enviar. Si no se abrió automáticamente, revisa que
            tu navegador permita ventanas emergentes.
          </p>
          <Button fullWidth onClick={handleClose}>
            Cerrar
          </Button>
        </div>
      </Modal>
    )
  }

  return (
    <Modal open={open} onClose={onClose} size="lg">
      <h3 className="text-2xl font-semibold mb-1">Resumen de tu pedido</h3>
      <p className="text-text-muted mb-6">Revisa los detalles antes de enviarlo por WhatsApp.</p>

      {itemCount === 0 && <p className="text-text-muted text-center py-8">Aún no has agregado nada a tu pedido.</p>}

      <div className="space-y-4 mb-6">
        {cakes.map((c) => (
          <div key={c.uid} className="flex justify-between items-start gap-3 bg-surface rounded-card p-4">
            <div>
              <p className="font-semibold">{c.cake.name}</p>
              <p className="text-sm text-text-muted">
                {c.flavor.name} · {c.filling.name} · {c.size.label}
              </p>
              <p className="text-xs text-text-muted">
                Entrega: {formatDateHuman(c.date)} a las {c.time}
              </p>
              {c.message && <p className="text-xs text-text-muted italic">"{c.message}"</p>}
            </div>
            <div className="text-right shrink-0">
              <p className="font-display font-semibold text-primary">{formatCurrency(c.price)}</p>
              <button
                onClick={() => removeCake(c.uid)}
                className="text-text-muted hover:text-primary mt-1"
                aria-label="Quitar pastel"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}

        {additionalProducts.map((p) => (
          <div key={p.uid} className="flex justify-between items-center gap-3 bg-surface rounded-card p-4">
            <div>
              <p className="font-semibold">{p.product.name}</p>
              <p className="text-sm text-text-muted">{p.quantity} unidades</p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-display font-semibold text-primary">{formatCurrency(p.price)}</p>
              <button
                onClick={() => removeAdditionalProduct(p.uid)}
                className="text-text-muted hover:text-primary mt-1"
                aria-label="Quitar producto"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}

        {promotionsInOrder.map((p) => (
          <div key={p.uid} className="flex justify-between items-center gap-3 bg-surface rounded-card p-4">
            <div>
              <p className="font-semibold">{p.promotion.title}</p>
              <p className="text-sm text-text-muted">Promoción</p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-display font-semibold text-primary">{formatCurrency(p.price)}</p>
              <button
                onClick={() => removePromotion(p.uid)}
                className="text-text-muted hover:text-primary mt-1"
                aria-label="Quitar promoción"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {itemCount > 0 && (
        <>
          <div className="flex justify-between items-center border-t border-secondary pt-4 mb-6">
            <span className="font-semibold text-lg">Total</span>
            <span className="font-display font-bold text-2xl text-primary">{formatCurrency(total)}</span>
          </div>
          <Button fullWidth size="lg" icon={MessageCircle} onClick={handleFinish} disabled={submitting}>
            {submitting ? 'Generando pedido…' : 'Finalizar pedido por WhatsApp'}
          </Button>
        </>
      )}
    </Modal>
  )
}
