import { useState } from 'react'
import { Heart, Camera } from 'lucide-react'
import Card from '../ui/Card'
import Button from '../ui/Button'
import PlaceholderMedia from '../ui/PlaceholderMedia'
import { useAdminData } from '../../data/AdminDataContext'
import ShareExperienceForm from './ShareExperienceForm'

export default function SatisfiedCustomersSection() {
  const { business, getApprovedTestimonials } = useAdminData()
  const [formOpen, setFormOpen] = useState(false)

  if (!business.modules.satisfiedCustomers) return null
  const testimonials = getApprovedTestimonials()

  return (
    <section className="max-w-6xl mx-auto px-5 py-12">
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <Heart className="text-primary" /> Clientes satisfechos
        </h2>
        <Button size="sm" variant="secondary" icon={Camera} onClick={() => setFormOpen(true)}>
          Compartir mi experiencia
        </Button>
      </div>

      {testimonials.length === 0 ? (
        <p className="text-text-muted">Aún no hay experiencias publicadas. ¡Sé el primero en compartir la tuya!</p>
      ) : (
        <div className="grid sm:grid-cols-3 gap-5">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id}>
              <div className="flex gap-1 mb-3">
                {testimonial.photos.map((photo) => (
                  <PlaceholderMedia key={photo.id} label="" imageUrl={photo.url} aspect="aspect-square" className="flex-1" />
                ))}
              </div>
              <p className="text-sm italic text-text-muted">"{testimonial.message}"</p>
            </Card>
          ))}
        </div>
      )}

      <ShareExperienceForm open={formOpen} onClose={() => setFormOpen(false)} />
    </section>
  )
}
