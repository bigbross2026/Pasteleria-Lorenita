import { useMemo, useState } from 'react'
import { Flame, Maximize2, CakeSlice } from 'lucide-react'
import Card from '../ui/Card'
import Button from '../ui/Button'
import CakeVisual from './CakeVisual'
import CakeLightbox from './CakeLightbox'
import { useAdminData } from '../../data/AdminDataContext'
import { useCakeStats } from '../../data/counters'

// Combina estadísticas reales en vivo (pedidos ya finalizados, vía
// Firestore) con una pequeña "semilla" inicial para que la sección no
// aparezca vacía antes del primer pedido real.
const SEED_STATS = { c1: 14, c8: 11, c3: 9, c6: 7, c2: 5 }

export default function BestSellersSection({ onChoose }) {
  const { getActiveDesigns } = useAdminData()
  const active = getActiveDesigns()
  const liveCounts = useCakeStats()

  const topCakes = useMemo(() => {
    const stats = { ...SEED_STATS, ...liveCounts }
    return [...active].sort((a, b) => (stats[b.id] || 0) - (stats[a.id] || 0)).slice(0, 3)
  }, [active, liveCounts])

  const [expanded, setExpanded] = useState(null)

  if (topCakes.length === 0) return null

  return (
    <section className="max-w-6xl mx-auto px-5 py-10">
      <h2 className="text-2xl font-semibold mb-5 flex items-center gap-2">
        <Flame className="text-primary" /> Los más pedidos
      </h2>
      <div className="grid sm:grid-cols-3 gap-5">
        {topCakes.map((cake) => (
          <Card key={cake.id} hoverable>
            <CakeVisual cake={cake} />
            <div className="flex gap-2 mt-3">
              <Button size="sm" variant="secondary" icon={Maximize2} onClick={() => setExpanded(cake)} className="flex-1">
                Ver
              </Button>
              <Button size="sm" icon={CakeSlice} onClick={() => onChoose(cake)} className="flex-1">
                Elegir
              </Button>
            </div>
          </Card>
        ))}
      </div>

      <CakeLightbox cake={expanded} onClose={() => setExpanded(null)} onChoose={onChoose} />
    </section>
  )
}
