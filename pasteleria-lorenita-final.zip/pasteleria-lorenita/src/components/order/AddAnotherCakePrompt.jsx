import { CakeSlice, ArrowRight } from 'lucide-react'
import Button from '../ui/Button'
import Card from '../ui/Card'

export default function AddAnotherCakePrompt({ onYes, onNo }) {
  return (
    <Card className="max-w-md mx-auto text-center animate-fade-in-up">
      <CakeSlice size={36} className="mx-auto mb-3 text-primary" strokeWidth={1.5} />
      <h3 className="text-xl font-semibold mb-5">¿Deseas agregar otro pastel?</h3>
      <div className="flex gap-3 justify-center">
        <Button variant="secondary" onClick={onNo}>
          No, continuar
        </Button>
        <Button icon={ArrowRight} onClick={onYes}>
          Sí, agregar otro
        </Button>
      </div>
    </Card>
  )
}
