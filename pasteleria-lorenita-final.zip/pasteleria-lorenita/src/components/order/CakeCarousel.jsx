import { useMemo, useRef } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import CakeCard from './CakeCard'

// Baraja el arreglo (Fisher-Yates) una sola vez por montaje, para que las
// tarjetas aparezcan "mezcladas aleatoriamente, sin agrupar por categorías"
// tal como pide el brief.
function shuffle(array) {
  const result = [...array]
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

export default function CakeCarousel({ cakes, onExpand, onChoose }) {
  const shuffled = useMemo(() => shuffle(cakes), [cakes])
  const trackRef = useRef(null)

  function scrollBy(delta) {
    trackRef.current?.scrollBy({ left: delta, behavior: 'smooth' })
  }

  return (
    <div className="relative">
      <button
        onClick={() => scrollBy(-280)}
        className="hidden sm:flex absolute -left-4 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-card shadow-lift items-center justify-center hover:bg-surface transition-colors"
        aria-label="Anterior"
      >
        <ChevronLeft size={20} />
      </button>

      <div
        ref={trackRef}
        className="flex gap-4 overflow-x-auto snap-x snap-mandatory scroll-smooth pb-2 -mx-1 px-1"
        style={{ scrollbarWidth: 'thin' }}
      >
        {shuffled.map((cake) => (
          <CakeCard key={cake.id} cake={cake} onExpand={onExpand} onChoose={onChoose} />
        ))}
      </div>

      <button
        onClick={() => scrollBy(280)}
        className="hidden sm:flex absolute -right-4 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-card shadow-lift items-center justify-center hover:bg-surface transition-colors"
        aria-label="Siguiente"
      >
        <ChevronRight size={20} />
      </button>
    </div>
  )
}
