// Componente genérico para las selecciones de opción única con botones
// grandes y animados: sabor, relleno y tamaño usan exactamente el mismo
// patrón visual, solo cambia la lista de opciones.
export default function OptionGrid({ options, selectedId, onSelect, renderExtra }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
      {options.map((opt) => {
        const isSelected = opt.id === selectedId
        return (
          <button
            key={opt.id}
            type="button"
            onClick={() => onSelect(opt)}
            className={[
              'rounded-card px-4 py-4 text-center font-semibold transition-all duration-200',
              'border-2 active:scale-95',
              isSelected
                ? 'bg-primary text-button-text border-primary shadow-lift scale-[1.03]'
                : 'bg-card text-text-main border-secondary hover:border-primary hover:-translate-y-0.5 shadow-soft'
            ].join(' ')}
          >
            {opt.label || opt.name}
            {renderExtra ? renderExtra(opt, isSelected) : null}
          </button>
        )
      })}
    </div>
  )
}
