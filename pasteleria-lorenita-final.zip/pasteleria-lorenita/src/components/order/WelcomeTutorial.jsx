import { useEffect, useState } from 'react'
import { CakeSlice, Clock, Layers, ShoppingBag, MessageCircle, Palette } from 'lucide-react'
import Modal from '../common/Modal'
import Button from '../ui/Button'

const SESSION_KEY = 'lorenita_tutorial_seen'

const TUTORIAL_POINTS = [
  { icon: Palette, text: 'Elige el diseño de pastel que más te guste del catálogo.' },
  { icon: CakeSlice, text: 'Personaliza sabor, relleno y tamaño a tu gusto.' },
  { icon: Clock, text: 'Los pedidos deben hacerse con 24 horas de anticipación.' },
  { icon: Layers, text: 'Puedes agregar más de un pastel a tu pedido.' },
  { icon: ShoppingBag, text: 'También podrás sumar productos adicionales.' },
  { icon: MessageCircle, text: 'Al finalizar, te llevaremos directo a WhatsApp con todo listo.' }
]

export default function WelcomeTutorial() {
  const [step, setStep] = useState(0) // 0 = cerrado, 1 = bienvenida, 2 = tutorial

  useEffect(() => {
    const seen = sessionStorage.getItem(SESSION_KEY)
    if (!seen) setStep(1)
  }, [])

  function finish() {
    sessionStorage.setItem(SESSION_KEY, 'true')
    setStep(0)
  }

  return (
    <>
      <Modal open={step === 1} onClose={finish} size="sm" showClose={false}>
        <div className="text-center">
          <div className="flex justify-center mb-4 text-primary">
            <CakeSlice size={44} strokeWidth={1.5} />
          </div>
          <h2 className="text-2xl font-semibold mb-3">¡Bienvenido a Pastelería Lorenita!</h2>
          <p className="text-text-muted mb-6">
            Gracias por visitarnos. Aquí podrás crear tu pedido de manera fácil y personalizada.
          </p>
          <Button fullWidth onClick={() => setStep(2)}>
            Siguiente
          </Button>
        </div>
      </Modal>

      <Modal open={step === 2} onClose={finish} size="sm" showClose={false}>
        <div>
          <h2 className="text-xl font-semibold mb-4 text-center">Antes de comenzar</h2>
          <ul className="space-y-3 mb-6">
            {TUTORIAL_POINTS.map(({ icon: Icon, text }, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="mt-0.5 text-primary shrink-0">
                  <Icon size={20} />
                </span>
                <span className="text-sm text-text-main">{text}</span>
              </li>
            ))}
          </ul>
          <Button fullWidth onClick={finish}>
            Entendido
          </Button>
        </div>
      </Modal>
    </>
  )
}
