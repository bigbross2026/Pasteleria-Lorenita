import { useEffect, useState } from 'react'
import { formatCurrency } from '../../utils/pricing'

// Muestra el precio con una pequeña animación de aparición/actualización
// cada vez que cambia el valor (ej. al elegir el tamaño del pastel).
export default function AnimatedPrice({ value, label = 'Total del pastel' }) {
  const [pulse, setPulse] = useState(false)

  useEffect(() => {
    setPulse(true)
    const t = setTimeout(() => setPulse(false), 350)
    return () => clearTimeout(t)
  }, [value])

  return (
    <div className="flex items-baseline gap-2">
      <span className="text-sm text-text-muted">{label}</span>
      <span
        className={`text-3xl font-display font-semibold text-primary transition-transform duration-300 ${
          pulse ? 'scale-110' : 'scale-100'
        }`}
      >
        {formatCurrency(value)}
      </span>
    </div>
  )
}
