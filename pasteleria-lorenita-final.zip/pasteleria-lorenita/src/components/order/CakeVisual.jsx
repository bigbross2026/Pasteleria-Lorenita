import { CakeSlice } from 'lucide-react'
import { useAdminData } from '../../data/AdminDataContext'

// Mientras una categoría/diseño no tenga fotografía real cargada, se
// representa con esta tarjeta visual: el marco usa el color de su
// categoría. En cuanto el admin sube una foto real (Firebase Storage),
// cake.imageUrl queda definido y se muestra la fotografía real aquí
// mismo, sin tocar el resto de la app.
export default function CakeVisual({ cake, aspect = 'aspect-square', big = false }) {
  const { getCategoryById } = useAdminData()
  const category = getCategoryById(cake.categoryId)
  const frameColor = category ? category.frameColor : '200 200 200'

  return (
    <div
      className={`${aspect} w-full rounded-card overflow-hidden relative`}
      style={{ border: `${big ? 6 : 4}px solid rgb(${frameColor})` }}
      role="img"
      aria-label={`Diseño de pastel: ${cake.name}${category ? `, categoría ${category.name}` : ''}`}
    >
      {cake.imageUrl ? (
        <img src={cake.imageUrl} alt={cake.name} className="absolute inset-0 h-full w-full object-cover" loading="lazy" />
      ) : (
        <div className="absolute inset-0 bg-surface flex flex-col items-center justify-center gap-2">
          <CakeSlice size={big ? 72 : 40} strokeWidth={1.25} style={{ color: `rgb(${frameColor})` }} aria-hidden="true" />
          <span className={`font-display font-semibold text-text-main text-center px-3 ${big ? 'text-xl' : 'text-sm'}`}>
            {cake.name}
          </span>
        </div>
      )}
      {category && (
        <span
          className="absolute top-2 left-2 text-[10px] font-bold uppercase tracking-wide px-2 py-1 rounded-pill text-white flex items-center gap-1"
          style={{ backgroundColor: `rgb(${frameColor})` }}
        >
          {category.emoji} {category.name}
        </span>
      )}
    </div>
  )
}
