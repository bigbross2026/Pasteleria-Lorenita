import { useState } from 'react'
import { ImagePlus, Send, CheckCircle2, Loader2, X } from 'lucide-react'
import Modal from '../common/Modal'
import Button from '../ui/Button'
import { useAdminData } from '../../data/AdminDataContext'
import { sanitizeText } from '../../utils/validation'
import { uploadImage, validateImageFile } from '../../firebase/storage'

const MAX_PHOTOS = 4

export default function ShareExperienceForm({ open, onClose }) {
  const { testimonialOps } = useAdminData()
  const [message, setMessage] = useState('')
  const [photos, setPhotos] = useState([]) // { url, path }
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState(null)
  const [submitted, setSubmitted] = useState(false)

  async function handleFiles(e) {
    const files = Array.from(e.target.files || []).slice(0, MAX_PHOTOS - photos.length)
    e.target.value = ''
    setUploading(true)
    setError(null)
    for (const file of files) {
      const validationError = validateImageFile(file)
      if (validationError) {
        setError(validationError)
        continue
      }
      try {
        const { url, path } = await uploadImage(file, 'testimonials')
        setPhotos((prev) => [...prev, { id: `ph-${Date.now()}-${prev.length}`, url, path }].slice(0, MAX_PHOTOS))
      } catch (err) {
        setError(err.message)
      }
    }
    setUploading(false)
  }

  function removePhoto(id) {
    setPhotos((prev) => prev.filter((p) => p.id !== id))
  }

  function handleSubmit() {
    if (!message.trim()) return
    testimonialOps.add({
      message: sanitizeText(message, 300),
      photos,
      status: 'pending',
      createdAt: new Date().toISOString()
    })
    setSubmitted(true)
  }

  function handleClose() {
    setMessage('')
    setPhotos([])
    setSubmitted(false)
    setError(null)
    onClose()
  }

  return (
    <Modal open={open} onClose={handleClose} size="sm">
      {submitted ? (
        <div className="text-center py-4">
          <CheckCircle2 size={44} className="mx-auto mb-3 text-primary" />
          <h3 className="text-xl font-semibold mb-2">¡Gracias por compartir!</h3>
          <p className="text-text-muted mb-5">
            Tu experiencia quedó enviada y será visible en cuanto la administradora la apruebe.
          </p>
          <Button onClick={handleClose} fullWidth>
            Cerrar
          </Button>
        </div>
      ) : (
        <div>
          <h3 className="text-xl font-semibold mb-1">Comparte tu experiencia</h3>
          <p className="text-sm text-text-muted mb-4">Tu mensaje quedará pendiente de aprobación. No se mostrará tu nombre.</p>

          <label className="block mb-4">
            <span className="text-sm font-semibold text-text-main">Tu mensaje</span>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              maxLength={300}
              placeholder="Cuéntanos cómo fue tu experiencia con tu pastel…"
              className="mt-1 w-full rounded-xl border border-secondary px-4 py-3 bg-surface outline-none resize-none"
            />
          </label>

          <label className="block mb-5">
            <span className="text-sm font-semibold text-text-main mb-2 flex items-center gap-2">
              {uploading ? <Loader2 size={16} className="animate-spin" /> : <ImagePlus size={16} />} Fotos (hasta {MAX_PHOTOS})
            </span>
            <input
              type="file"
              accept="image/*"
              multiple
              onChange={handleFiles}
              disabled={photos.length >= MAX_PHOTOS || uploading}
              className="mt-1 w-full text-sm"
            />
            {error && <p className="text-xs text-primary-dark mt-1">{error}</p>}
            {photos.length > 0 && (
              <div className="flex gap-2 mt-2">
                {photos.map((p) => (
                  <div key={p.id} className="relative">
                    <img src={p.url} alt="" className="h-14 w-14 object-cover rounded-xl" />
                    <button
                      onClick={() => removePhoto(p.id)}
                      className="absolute -top-1.5 -right-1.5 bg-card rounded-full p-0.5 shadow-soft"
                      aria-label="Quitar foto"
                    >
                      <X size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </label>

          <Button fullWidth icon={Send} disabled={!message.trim() || uploading} onClick={handleSubmit}>
            Enviar experiencia
          </Button>
        </div>
      )}
    </Modal>
  )
}
