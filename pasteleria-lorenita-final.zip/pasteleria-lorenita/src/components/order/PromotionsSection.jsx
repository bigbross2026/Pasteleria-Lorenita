import { Percent, CalendarRange, Plus } from 'lucide-react'
import Card from '../ui/Card'
import Button from '../ui/Button'
import PlaceholderMedia from '../ui/PlaceholderMedia'
import { formatCurrency } from '../../utils/pricing'
import { useAdminData } from '../../data/AdminDataContext'
import { useOrder } from '../../context/OrderContext'

export default function PromotionsSection() {
  const { business, getActivePromotions } = useAdminData()
  const { addPromotion } = useOrder()
  if (!business.modules.promotions) return null

  const promotions = getActivePromotions()
  if (promotions.length === 0) return null

  return (
    <section className="bg-surface theme-transition py-12">
      <div className="max-w-6xl mx-auto px-5">
        <h2 className="text-2xl font-semibold mb-5 flex items-center gap-2">
          <Percent className="text-primary" /> Promociones
        </h2>
        <div className="grid sm:grid-cols-2 gap-5">
          {promotions.map((promo) => (
            <Card key={promo.id} className="flex gap-4">
              <PlaceholderMedia label={promo.title} imageUrl={promo.imageUrl} aspect="aspect-square" className="w-28 shrink-0" />
              <div className="flex-1">
                <h3 className="font-semibold">{promo.title}</h3>
                <p className="text-sm text-text-muted mt-1 mb-2">{promo.description}</p>
                <p className="flex items-center gap-1 text-xs text-text-muted mb-3">
                  <CalendarRange size={14} />
                  Vigente hasta {new Date(`${promo.endDate}T00:00:00`).toLocaleDateString('es-ES')}
                </p>
                <div className="flex items-center justify-between">
                  <span className="font-display font-semibold text-primary text-lg">
                    {formatCurrency(promo.price)}
                  </span>
                  <Button size="sm" icon={Plus} onClick={() => addPromotion(promo)}>
                    Agregar
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
