import { useMemo } from 'react'
import { CalendarDays, Clock, AlertTriangle } from 'lucide-react'
import { isDateDisabled, isTimeDisabled, getAvailableTimeSlots, getMinimumDeliveryDate } from '../../utils/deliveryTime'
import { isDateBlockedForNewOrder, canAcceptOneMoreCake } from '../../utils/dailyLimit'
import { useAdminData } from '../../data/AdminDataContext'
import { useOrder } from '../../context/OrderContext'

function getNext14Days() {
  const days = []
  const today = new Date()
  for (let i = 0; i < 14; i++) {
    const d = new Date(today)
    d.setDate(today.getDate() + i)
    days.push(d)
  }
  return days
}

export default function DeliveryDateTimePicker({ date, time, onChangeDate, onChangeTime }) {
  const days = useMemo(getNext14Days, [])
  const timeSlots = useMemo(getAvailableTimeSlots, [])
  const minInfo = useMemo(getMinimumDeliveryDate, [])
  const { orders, business } = useAdminData()
  const { cakes } = useOrder()

  const dailyLimit = business.dailyLimit

  function dateStatus(dateStr) {
    if (isDateDisabled(dateStr)) return 'too-soon'
    const cartCakesForDate = cakes.filter((c) => c.date === dateStr).length
    if (cartCakesForDate === 0 && isDateBlockedForNewOrder(orders, dailyLimit, dateStr)) return 'full'
    if (!canAcceptOneMoreCake(orders, dailyLimit, dateStr, cartCakesForDate)) return 'full'
    return 'ok'
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="flex items-center gap-2 font-semibold mb-2 text-text-main">
          <CalendarDays size={18} className="text-primary" /> Fecha de entrega
        </p>
        <p className="text-xs text-text-muted mb-3">
          Los pedidos requieren mínimo 24 horas de anticipación (disponible desde el{' '}
          {minInfo.toLocaleDateString('es-ES', { day: 'numeric', month: 'long' })}).
          {dailyLimit?.enabled && ' Algunas fechas pueden no tener cupo disponible.'}
        </p>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {days.map((d) => {
            const dateStr = d.toISOString().slice(0, 10)
            const status = dateStatus(dateStr)
            const disabled = status !== 'ok'
            const isSelected = dateStr === date
            return (
              <button
                key={dateStr}
                disabled={disabled}
                onClick={() => onChangeDate(dateStr)}
                title={status === 'full' ? 'Sin cupo disponible este día' : undefined}
                className={[
                  'shrink-0 w-16 rounded-card py-2 text-center border-2 transition-all relative',
                  disabled
                    ? 'opacity-35 cursor-not-allowed border-secondary bg-surface'
                    : isSelected
                    ? 'bg-primary text-button-text border-primary shadow-soft'
                    : 'bg-card border-secondary hover:border-primary'
                ].join(' ')}
              >
                <div className="text-[10px] uppercase font-semibold">
                  {d.toLocaleDateString('es-ES', { weekday: 'short' })}
                </div>
                <div className="text-lg font-bold leading-none mt-1">{d.getDate()}</div>
                {status === 'full' && (
                  <AlertTriangle size={10} className="absolute top-1 right-1 text-primary-dark" />
                )}
              </button>
            )
          })}
        </div>
      </div>

      {date && (
        <div>
          <p className="flex items-center gap-2 font-semibold mb-2 text-text-main">
            <Clock size={18} className="text-primary" /> Hora de entrega
          </p>
          <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
            {timeSlots.map((t) => {
              const disabled = isTimeDisabled(date, t)
              const isSelected = t === time
              return (
                <button
                  key={t}
                  disabled={disabled}
                  onClick={() => onChangeTime(t)}
                  className={[
                    'rounded-pill py-2 text-sm font-medium border-2 transition-all',
                    disabled
                      ? 'opacity-35 cursor-not-allowed border-secondary bg-surface'
                      : isSelected
                      ? 'bg-primary text-button-text border-primary'
                      : 'bg-card border-secondary hover:border-primary'
                  ].join(' ')}
                >
                  {t}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
