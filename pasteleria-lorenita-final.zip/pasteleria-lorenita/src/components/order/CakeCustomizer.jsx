import { useState } from 'react'
import { RefreshCw, MessageSquareText, Check } from 'lucide-react'
import CakeVisual from './CakeVisual'
import OptionGrid from './OptionGrid'
import AnimatedPrice from './AnimatedPrice'
import DeliveryDateTimePicker from './DeliveryDateTimePicker'
import Button from '../ui/Button'
import { useAdminData } from '../../data/AdminDataContext'
import { calculateCakePrice } from '../../utils/pricing'
import { sanitizeText } from '../../utils/validation'

export default function CakeCustomizer({ cake, onChangeDesign, onConfirm }) {
  const { getActiveFlavors, getActiveFillings, getActiveSizes, getCategoryById } = useAdminData()
  const flavors = getActiveFlavors()
  const fillings = getActiveFillings()
  const sizes = getActiveSizes()
  const category = getCategoryById(cake.categoryId)

  const [flavor, setFlavor] = useState(null)
  const [filling, setFilling] = useState(null)
  const [size, setSize] = useState(null)
  const [date, setDate] = useState('')
  const [time, setTime] = useState('')
  const [message, setMessage] = useState('')

  const price = size ? calculateCakePrice({ sizePrice: size.price, surcharge: category?.surcharge || 0 }) : 0

  const canConfirm = flavor && filling && size && date && time

  function handleConfirm() {
    if (!canConfirm) return
    onConfirm({
      cake,
      category: cake.categoryId,
      flavor,
      filling,
      size,
      date,
      time,
      message: sanitizeText(message, 80),
      price
    })
  }

  return (
    <div className="grid md:grid-cols-2 gap-8">
      {/* Imagen: ocupa la mitad de la pantalla en escritorio */}
      <div>
        <CakeVisual cake={cake} aspect="aspect-square" big />
        <Button variant="secondary" size="sm" icon={RefreshCw} onClick={onChangeDesign} className="mt-4 w-full">
          Cambiar diseño
        </Button>
      </div>

      {/* Personalización */}
      <div className="space-y-7">
        <section>
          <h3 className="font-semibold mb-3">Elige el sabor</h3>
          <OptionGrid options={flavors} selectedId={flavor?.id} onSelect={setFlavor} />
        </section>

        <section>
          <h3 className="font-semibold mb-3">Elige el relleno</h3>
          <OptionGrid options={fillings} selectedId={filling?.id} onSelect={setFilling} />
        </section>

        <section>
          <h3 className="font-semibold mb-3">Elige el tamaño</h3>
          <OptionGrid options={sizes} selectedId={size?.id} onSelect={setSize} />
        </section>

        {size && (
          <section className="animate-fade-in-up">
            <AnimatedPrice value={price} />
          </section>
        )}

        {size && (
          <section className="animate-fade-in-up">
            <DeliveryDateTimePicker date={date} time={time} onChangeDate={setDate} onChangeTime={setTime} />
          </section>
        )}

        {size && (
          <section className="animate-fade-in-up">
            <label className="block">
              <span className="flex items-center gap-2 font-semibold mb-2 text-text-main">
                <MessageSquareText size={18} className="text-primary" /> Mensaje para el pastel (opcional)
              </span>
              <input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder='Ej. "¡Feliz cumpleaños, Ana!"'
                maxLength={80}
                className="w-full rounded-pill border border-secondary px-4 py-2 bg-surface outline-none"
              />
            </label>
          </section>
        )}

        <Button fullWidth size="lg" icon={Check} disabled={!canConfirm} onClick={handleConfirm}>
          Agregar este pastel al pedido
        </Button>
      </div>
    </div>
  )
}
