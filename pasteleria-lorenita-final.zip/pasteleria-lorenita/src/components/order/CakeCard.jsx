import { Maximize2, CakeSlice } from 'lucide-react'
import CakeVisual from './CakeVisual'
import Button from '../ui/Button'

export default function CakeCard({ cake, onExpand, onChoose }) {
  return (
    <div className="shrink-0 w-64 snap-center">
      <div className="bg-card rounded-card shadow-soft p-3 hover:shadow-lift transition-shadow duration-300">
        <button onClick={() => onExpand(cake)} className="block w-full">
          <CakeVisual cake={cake} />
        </button>
        <div className="flex gap-2 mt-3">
          <Button size="sm" variant="secondary" icon={Maximize2} onClick={() => onExpand(cake)} className="flex-1">
            Ampliar
          </Button>
          <Button size="sm" icon={CakeSlice} onClick={() => onChoose(cake)} className="flex-1">
            Elegir
          </Button>
        </div>
      </div>
    </div>
  )
}
