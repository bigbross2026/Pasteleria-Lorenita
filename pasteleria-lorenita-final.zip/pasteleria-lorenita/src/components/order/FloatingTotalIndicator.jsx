import { useEffect, useState } from 'react'
import { ShoppingBasket } from 'lucide-react'
import { useOrder } from '../../context/OrderContext'
import { formatCurrency } from '../../utils/pricing'

// Indicador pequeño y elegante que se actualiza solo cuando cambia el
// total. Se mantiene fijo en la parte inferior para no interrumpir la
// experiencia del cliente mientras arma su pedido.
export default function FloatingTotalIndicator({ onClick }) {
  const { total, itemCount } = useOrder()
  const [pulse, setPulse] = useState(false)

  useEffect(() => {
    setPulse(true)
    const t = setTimeout(() => setPulse(false), 400)
    return () => clearTimeout(t)
  }, [total])

  if (itemCount === 0) return null

  return (
    <button
      onClick={onClick}
      className={`fixed bottom-5 right-5 z-30 flex items-center gap-3 bg-primary text-button-text rounded-pill
        shadow-lift px-5 py-3 transition-transform duration-300 hover:-translate-y-1 active:scale-95 ${
          pulse ? 'scale-105' : 'scale-100'
        }`}
    >
      <ShoppingBasket size={20} />
      <span className="font-semibold text-sm">{itemCount} artículo{itemCount !== 1 ? 's' : ''}</span>
      <span className="font-display font-bold">{formatCurrency(total)}</span>
    </button>
  )
}
