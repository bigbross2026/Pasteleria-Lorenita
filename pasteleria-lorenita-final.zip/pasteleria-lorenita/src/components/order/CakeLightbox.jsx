import Modal from '../common/Modal'
import Button from '../ui/Button'
import CakeVisual from './CakeVisual'
import { CakeSlice } from 'lucide-react'

export default function CakeLightbox({ cake, onClose, onChoose }) {
  return (
    <Modal open={!!cake} onClose={onClose} size="lg">
      {cake && (
        <div>
          <CakeVisual cake={cake} aspect="aspect-[4/3]" big />
          <div className="mt-5 flex justify-center">
            <Button icon={CakeSlice} onClick={() => onChoose(cake)}>
              Elegir este pastel
            </Button>
          </div>
        </div>
      )}
    </Modal>
  )
}
