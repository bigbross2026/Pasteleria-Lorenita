import { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Menu, X, CakeSlice } from 'lucide-react'
import { useAdminData } from '../../data/AdminDataContext'

const LINKS = [
  { to: '/', label: 'Inicio' },
  { to: '/pasteles', label: 'Pasteles' },
  { to: '/promociones', label: 'Promociones' },
  { to: '/clientes-satisfechos', label: 'Clientes Satisfechos' },
  { to: '/contacto', label: 'Contacto' }
]

export default function PublicNavbar() {
  const [open, setOpen] = useState(false)
  const { business } = useAdminData()

  return (
    <header className="sticky top-0 z-40 bg-header/90 backdrop-blur shadow-soft theme-transition">
      <nav className="max-w-6xl mx-auto flex items-center justify-between px-5 py-4">
        <Link to="/" className="flex items-center gap-2 font-display text-xl font-semibold text-primary">
          {business.logoUrl ? (
            <img src={business.logoUrl} alt={`Logotipo de ${business.businessName}`} className="h-8 w-8 object-contain rounded-full" />
          ) : (
            <CakeSlice size={26} strokeWidth={2} aria-hidden="true" />
          )}
          {business.businessName}
        </Link>

        <ul className="hidden md:flex items-center gap-7">
          {LINKS.map((link) => (
            <li key={link.to}>
              <NavLink
                to={link.to}
                className={({ isActive }) =>
                  [
                    'font-medium transition-colors',
                    isActive ? 'text-primary' : 'text-text-main hover:text-primary'
                  ].join(' ')
                }
              >
                {link.label}
              </NavLink>
            </li>
          ))}
        </ul>

        <button
          className="md:hidden p-2 rounded-full hover:bg-surface transition-colors"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
        >
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </nav>

      {open && (
        <ul className="md:hidden flex flex-col gap-1 px-5 pb-4 animate-fade-in-up">
          {LINKS.map((link) => (
            <li key={link.to}>
              <NavLink
                to={link.to}
                onClick={() => setOpen(false)}
                className="block py-2 font-medium text-text-main hover:text-primary"
              >
                {link.label}
              </NavLink>
            </li>
          ))}
        </ul>
      )}
    </header>
  )
}
