import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import PublicNavbar from './PublicNavbar'
import Footer from './Footer'
import FloatingTotalIndicator from '../order/FloatingTotalIndicator'
import OrderSummaryModal from '../order/OrderSummaryModal'

export default function PublicLayout() {
  const [summaryOpen, setSummaryOpen] = useState(false)

  return (
    <div className="min-h-screen flex flex-col theme-transition">
      <PublicNavbar />
      <main id="main-content" className="flex-1">
        <Outlet />
      </main>
      <Footer />

      <FloatingTotalIndicator onClick={() => setSummaryOpen(true)} />
      <OrderSummaryModal open={summaryOpen} onClose={() => setSummaryOpen(false)} />
    </div>
  )
}
