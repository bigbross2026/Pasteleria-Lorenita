import { Navigate, Outlet, useNavigate } from 'react-router-dom'
import { LogOut, CakeSlice, Loader2 } from 'lucide-react'
import { useAdminAuth } from '../../auth/AdminAuthContext'
import NotificationBell from '../admin/NotificationBell'
import ToastStack from '../admin/ToastStack'

// Envuelve todas las páginas /admin/* (excepto la de acceso). Si el admin
// no ha iniciado sesión, lo redirige a la pantalla de contraseña. Espera
// a que Firebase Auth confirme el estado de la sesión (authReady) antes
// de decidir, para no expulsar por error a un admin que sí tiene sesión
// válida justo al recargar la página.
export default function AdminLayout() {
  const { isAuthenticated, authReady, logout } = useAdminAuth()
  const navigate = useNavigate()

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 size={28} className="animate-spin text-primary" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/admin/acceso" replace />
  }

  return (
    <div className="min-h-screen bg-background theme-transition">
      <header className="bg-header shadow-soft">
        <div className="max-w-5xl mx-auto flex items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2 font-display text-lg font-semibold text-primary">
            <CakeSlice size={24} />
            Panel Administrador
          </div>
          <div className="flex items-center gap-3">
            <NotificationBell />
            <button
              onClick={async () => {
                await logout()
                navigate('/admin/acceso')
              }}
              className="flex items-center gap-2 text-sm font-medium text-text-muted hover:text-primary transition-colors"
            >
              <LogOut size={18} /> Salir
            </button>
          </div>
        </div>
      </header>

      <main id="main-content" className="max-w-5xl mx-auto px-5 py-8">
        <Outlet />
      </main>

      <ToastStack />
    </div>
  )
}
