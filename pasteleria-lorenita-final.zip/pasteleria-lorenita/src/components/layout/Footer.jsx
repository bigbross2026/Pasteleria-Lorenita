import { Link } from 'react-router-dom'
import { MessageCircle, Lock } from 'lucide-react'
import { useAdminData } from '../../data/AdminDataContext'
import { getContactWhatsAppLink } from '../../utils/whatsapp'

export default function Footer() {
  const { business } = useAdminData()

  return (
    <footer className="mt-16 bg-header theme-transition">
      <div className="max-w-6xl mx-auto px-5 py-10 grid gap-8 sm:grid-cols-3">
        <div>
          <h3 className="font-display text-lg font-semibold text-primary mb-2">{business.businessName}</h3>
          <p className="text-sm text-text-muted">
            Pasteles personalizados hechos con dulzura, para cada celebración.
          </p>
          {business.hours && (
            <p className="text-xs text-text-muted mt-2">
              {business.hours.days} · {business.hours.open} a {business.hours.close}
            </p>
          )}
        </div>

        <div>
          <h4 className="font-semibold mb-2 text-text-main">Contacto</h4>
          <a
            href={getContactWhatsAppLink(business.whatsappNumber)}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-sm text-text-muted hover:text-primary transition-colors"
          >
            <MessageCircle size={18} aria-hidden="true" /> Escríbenos por WhatsApp
          </a>
        </div>

        <div className="sm:text-right">
          <Link
            to="/admin/acceso"
            className="inline-flex items-center gap-2 text-xs text-text-muted hover:text-primary transition-colors"
          >
            <Lock size={14} aria-hidden="true" /> Acceso administrador
          </Link>
        </div>
      </div>

      <div className="text-center text-xs text-text-muted py-4 border-t border-secondary/40">
        © {new Date().getFullYear()} {business.businessName}. Todos los derechos reservados.
      </div>
    </footer>
  )
}
