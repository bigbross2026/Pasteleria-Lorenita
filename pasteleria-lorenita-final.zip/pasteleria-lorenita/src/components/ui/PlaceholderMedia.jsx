import { ImageIcon } from 'lucide-react'

// Reserva visual para logo, banner, carruseles y fotos mientras no exista
// una imagen real. En cuanto `imageUrl` está definido (foto subida a
// Firebase Storage desde el panel admin), se muestra la imagen real aquí
// mismo, sin que el resto de la app tenga que cambiar.
export default function PlaceholderMedia({ label = 'Imagen', aspect = 'aspect-[16/9]', className = '', imageUrl = null }) {
  if (imageUrl) {
    return (
      <div className={`${aspect} w-full rounded-card overflow-hidden ${className}`}>
        <img src={imageUrl} alt={label || 'Fotografía'} className="h-full w-full object-cover" loading="lazy" />
      </div>
    )
  }

  return (
    <div
      role="img"
      aria-label={label ? `Imagen pendiente: ${label}` : 'Imagen pendiente de cargar'}
      className={[
        aspect,
        'w-full rounded-card bg-surface border-2 border-dashed border-secondary',
        'flex flex-col items-center justify-center gap-2 text-text-muted',
        className
      ].join(' ')}
    >
      <ImageIcon size={28} strokeWidth={1.5} aria-hidden="true" />
      {label && <span className="text-sm font-medium">{label}</span>}
    </div>
  )
}
