// Botón base de toda la aplicación. Centralizar aquí el estilo garantiza que
// TODOS los botones respondan igual a los cambios de tema y mantengan las
// mismas microanimaciones (hover, presión) pedidas en el diseño.

const VARIANTS = {
  primary: 'bg-primary text-button-text hover:bg-primary-dark shadow-soft hover:shadow-lift',
  secondary: 'bg-surface text-text-main border border-secondary hover:bg-secondary',
  ghost: 'bg-transparent text-primary hover:bg-surface',
  accent: 'bg-accent text-button-text hover:brightness-95 shadow-soft'
}

const SIZES = {
  sm: 'text-sm px-4 py-2',
  md: 'text-base px-6 py-3',
  lg: 'text-lg px-8 py-4'
}

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon: Icon,
  fullWidth = false,
  className = '',
  ...props
}) {
  return (
    <button
      className={[
        'inline-flex items-center justify-center gap-2 rounded-pill font-body font-semibold',
        'transition-all duration-200 ease-out active:scale-95',
        VARIANTS[variant],
        SIZES[size],
        fullWidth ? 'w-full' : '',
        className
      ].join(' ')}
      {...props}
    >
      {Icon && <Icon size={size === 'lg' ? 22 : 18} strokeWidth={2.25} />}
      {children}
    </button>
  )
}
