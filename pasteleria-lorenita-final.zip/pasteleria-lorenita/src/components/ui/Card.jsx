export default function Card({ children, className = '', hoverable = false, ...props }) {
  return (
    <div
      className={[
        'bg-card rounded-card shadow-soft p-6',
        hoverable ? 'transition-transform duration-300 hover:-translate-y-1 hover:shadow-lift' : '',
        className
      ].join(' ')}
      {...props}
    >
      {children}
    </div>
  )
}
