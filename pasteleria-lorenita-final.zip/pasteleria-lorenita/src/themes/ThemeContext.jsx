import { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react'
import { BUILT_IN_THEMES, THEME_ROLES, DEFAULT_THEME_ID } from './themes'

const STORAGE_KEY_ACTIVE = 'lorenita_active_theme'
const STORAGE_KEY_CUSTOM = 'lorenita_custom_themes'

const ThemeContext = createContext(null)

// Aplica un objeto de colores { primary: "r g b", ... } como variables CSS
// en :root, con el prefijo --color-<rol-en-kebab-case>.
function applyColorsToRoot(colors) {
  const root = document.documentElement
  THEME_ROLES.forEach((role) => {
    const cssVarName = `--color-${role.replace(/([A-Z])/g, '-$1').toLowerCase()}`
    if (colors[role]) {
      root.style.setProperty(cssVarName, colors[role])
    }
  })
}

function loadCustomThemes() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CUSTOM)
    return raw ? JSON.parse(raw) : []
  } catch {
    return []
  }
}

export function ThemeProvider({ children }) {
  const [customThemes, setCustomThemes] = useState(loadCustomThemes)
  const allThemes = useMemo(() => [...BUILT_IN_THEMES, ...customThemes], [customThemes])

  const [activeThemeId, setActiveThemeId] = useState(
    () => localStorage.getItem(STORAGE_KEY_ACTIVE) || DEFAULT_THEME_ID
  )
  const [previewThemeId, setPreviewThemeId] = useState(null)

  // El tema que se está mostrando ahora mismo: el de vista previa si existe,
  // si no el activo guardado.
  const displayedThemeId = previewThemeId || activeThemeId
  const displayedTheme = useMemo(
    () => allThemes.find((t) => t.id === displayedThemeId) || allThemes[0],
    [allThemes, displayedThemeId]
  )

  useEffect(() => {
    if (displayedTheme) applyColorsToRoot(displayedTheme.colors)
  }, [displayedTheme])

  const applyTheme = useCallback((themeId) => {
    setPreviewThemeId(null)
    setActiveThemeId(themeId)
    localStorage.setItem(STORAGE_KEY_ACTIVE, themeId)
  }, [])

  // Muestra el tema temporalmente. Si se pasa una duración, vuelve solo al
  // tema activo al terminar (usado por el botón "Vista previa").
  const previewTheme = useCallback((themeId, durationMs = 4000) => {
    setPreviewThemeId(themeId)
    if (durationMs) {
      window.setTimeout(() => {
        setPreviewThemeId((current) => (current === themeId ? null : current))
      }, durationMs)
    }
  }, [])

  const cancelPreview = useCallback(() => setPreviewThemeId(null), [])

  const saveCustomTheme = useCallback((theme) => {
    setCustomThemes((prev) => {
      const exists = prev.some((t) => t.id === theme.id)
      const next = exists
        ? prev.map((t) => (t.id === theme.id ? theme : t))
        : [...prev, theme]
      localStorage.setItem(STORAGE_KEY_CUSTOM, JSON.stringify(next))
      return next
    })
  }, [])

  const deleteCustomTheme = useCallback((themeId) => {
    setCustomThemes((prev) => {
      const next = prev.filter((t) => t.id !== themeId)
      localStorage.setItem(STORAGE_KEY_CUSTOM, JSON.stringify(next))
      return next
    })
    setActiveThemeId((current) => (current === themeId ? DEFAULT_THEME_ID : current))
  }, [])

  const value = {
    themes: allThemes,
    activeThemeId,
    previewThemeId,
    displayedTheme,
    applyTheme,
    previewTheme,
    cancelPreview,
    saveCustomTheme,
    deleteCustomTheme
  }

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const ctx = useContext(ThemeContext)
  if (!ctx) throw new Error('useTheme debe usarse dentro de <ThemeProvider>')
  return ctx
}
