// Cada tema define TODOS los colores usados por la app. Los valores están
// en formato "R G B" (sin comas) porque Tailwind los consume así para
// poder aplicar opacidad con la sintaxis rgb(var(--x) / <alpha-value>).
//
// Para agregar un tema nuevo: copiar un objeto, cambiar id/name/colors.
// El resto de la aplicación no necesita saber cuántos temas existen.

export const THEME_ROLES = [
  'primary',
  'primaryDark',
  'secondary',
  'accent',
  'background',
  'surface',
  'card',
  'header',
  'text',
  'textMuted',
  'buttonText'
]

export const BUILT_IN_THEMES = [
  {
    id: 'dulce-suspiro',
    name: 'Dulce Suspiro',
    description: 'Rosa pastel suave, delicado y romántico.',
    colors: {
      primary: '236 100 149',
      primaryDark: '214 74 118',
      secondary: '255 214 224',
      accent: '255 176 201',
      background: '255 247 249',
      surface: '255 240 244',
      card: '255 255 255',
      header: '255 235 240',
      text: '74 44 55',
      textMuted: '150 110 122',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'chocolate-premium',
    name: 'Chocolate Premium',
    description: 'Tonos cacao y crema, elegante y cálido.',
    colors: {
      primary: '109 66 42',
      primaryDark: '77 45 27',
      secondary: '224 194 158',
      accent: '196 138 74',
      background: '250 244 235',
      surface: '240 227 210',
      card: '255 255 255',
      header: '61 38 25',
      text: '54 36 24',
      textMuted: '132 106 88',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'lavanda',
    name: 'Lavanda',
    description: 'Violeta suave y sereno, moderno y sofisticado.',
    colors: {
      primary: '146 111 199',
      primaryDark: '111 79 158',
      secondary: '224 210 245',
      accent: '190 156 235',
      background: '250 248 255',
      surface: '240 233 252',
      card: '255 255 255',
      header: '235 226 250',
      text: '58 46 82',
      textMuted: '132 116 158',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'fresa',
    name: 'Fresa',
    description: 'Rojo fresa vibrante, dulce y juvenil.',
    colors: {
      primary: '224 55 84',
      primaryDark: '182 36 62',
      secondary: '255 205 210',
      accent: '255 132 149',
      background: '255 248 248',
      surface: '255 233 235',
      card: '255 255 255',
      header: '255 225 228',
      text: '77 28 34',
      textMuted: '158 90 98',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'durazno',
    name: 'Durazno',
    description: 'Naranja melocotón cálido y acogedor.',
    colors: {
      primary: '237 133 76',
      primaryDark: '206 103 48',
      secondary: '255 214 176',
      accent: '255 170 110',
      background: '255 250 244',
      surface: '255 236 217',
      card: '255 255 255',
      header: '255 228 202',
      text: '82 51 27',
      textMuted: '163 120 88',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'menta',
    name: 'Menta',
    description: 'Verde menta fresco, limpio y moderno.',
    colors: {
      primary: '46 168 143',
      primaryDark: '31 136 114',
      secondary: '196 240 226',
      accent: '111 214 187',
      background: '246 253 250',
      surface: '224 247 238',
      card: '255 255 255',
      header: '212 244 232',
      text: '24 68 58',
      textMuted: '90 140 126',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'arandano',
    name: 'Arándano',
    description: 'Azul índigo profundo, elegante y nocturno.',
    colors: {
      primary: '72 78 163',
      primaryDark: '52 57 128',
      secondary: '203 207 240',
      accent: '110 116 214',
      background: '247 247 253',
      surface: '228 229 248',
      card: '255 255 255',
      header: '39 42 92',
      text: '32 34 68',
      textMuted: '104 108 150',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'fiesta',
    name: 'Fiesta',
    description: 'Combinación vibrante magenta y amarillo, alegre.',
    colors: {
      primary: '224 52 145',
      primaryDark: '184 35 116',
      secondary: '255 224 102',
      accent: '255 176 59',
      background: '255 251 240',
      surface: '255 238 205',
      card: '255 255 255',
      header: '255 214 232',
      text: '77 27 55',
      textMuted: '163 90 128',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'dorado-elegante',
    name: 'Dorado Elegante',
    description: 'Negro y dorado, lujo y sofisticación.',
    colors: {
      primary: '182 142 58',
      primaryDark: '138 106 40',
      secondary: '232 216 176',
      accent: '212 175 92',
      background: '250 248 244',
      surface: '32 30 28',
      card: '255 255 255',
      header: '20 19 18',
      text: '32 28 22',
      textMuted: '120 108 88',
      buttonText: '255 255 255'
    }
  },
  {
    id: 'cielo',
    name: 'Cielo',
    description: 'Azul cielo claro, ligero y optimista.',
    colors: {
      primary: '58 150 224',
      primaryDark: '38 120 190',
      secondary: '196 228 255',
      accent: '110 190 245',
      background: '246 251 255',
      surface: '221 241 255',
      card: '255 255 255',
      header: '211 236 255',
      text: '22 55 82',
      textMuted: '90 130 158',
      buttonText: '255 255 255'
    }
  }
]

export const DEFAULT_THEME_ID = 'dulce-suspiro'
