import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { ThemeProvider } from './themes/ThemeContext'
import { AdminAuthProvider } from './auth/AdminAuthContext'
import { OrderProvider } from './context/OrderContext'
import { AdminDataProvider } from './data/AdminDataContext'
import { NotificationProvider } from './context/NotificationContext'
import { initAnalyticsIfSupported } from './firebase/config'
import './index.css'

initAnalyticsIfSupported()

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.warn('No se pudo registrar el Service Worker:', err))
  })
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider>
      <AdminDataProvider>
        <OrderProvider>
          <AdminAuthProvider>
            <NotificationProvider>
              <BrowserRouter>
                <App />
              </BrowserRouter>
            </NotificationProvider>
          </AdminAuthProvider>
        </OrderProvider>
      </AdminDataProvider>
    </ThemeProvider>
  </React.StrictMode>
)
