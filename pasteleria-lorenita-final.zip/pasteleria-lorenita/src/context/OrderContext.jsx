import { createContext, useContext, useState, useCallback, useMemo } from 'react'
import { round2, formatCurrency } from '../utils/pricing'
import { formatDateHuman } from '../utils/deliveryTime'
import { useAdminData } from '../data/AdminDataContext'
import { getNextOrderNumber, bumpCakeStats } from '../data/counters'

const OrderContext = createContext(null)

export function OrderProvider({ children }) {
  const { orderOps, business } = useAdminData()

  // Cada pastel en el pedido: { uid, cake, category, flavor, filling, size,
  //   date, time, price, message }
  const [cakes, setCakes] = useState([])
  // Cada producto adicional: { uid, product, tier, quantity, price }
  const [additionalProducts, setAdditionalProducts] = useState([])
  // Promociones agregadas directamente desde la sección de Promociones.
  const [promotionsInOrder, setPromotionsInOrder] = useState([])
  const [submitting, setSubmitting] = useState(false)

  const addCake = useCallback((cakeOrderItem) => {
    setCakes((prev) => [...prev, { ...cakeOrderItem, uid: `cake-${Date.now()}-${prev.length}` }])
  }, [])

  const removeCake = useCallback((uid) => {
    setCakes((prev) => prev.filter((c) => c.uid !== uid))
  }, [])

  const addAdditionalProduct = useCallback((item) => {
    setAdditionalProducts((prev) => [...prev, { ...item, uid: `addon-${Date.now()}-${prev.length}` }])
  }, [])

  const removeAdditionalProduct = useCallback((uid) => {
    setAdditionalProducts((prev) => prev.filter((p) => p.uid !== uid))
  }, [])

  const addPromotion = useCallback((promo) => {
    setPromotionsInOrder((prev) => [...prev, { uid: `promo-${Date.now()}-${prev.length}`, promotion: promo, price: promo.price }])
  }, [])

  const removePromotion = useCallback((uid) => {
    setPromotionsInOrder((prev) => prev.filter((p) => p.uid !== uid))
  }, [])

  const total = useMemo(() => {
    const cakesTotal = cakes.reduce((sum, c) => sum + c.price, 0)
    const addonsTotal = additionalProducts.reduce((sum, p) => sum + p.price, 0)
    const promosTotal = promotionsInOrder.reduce((sum, p) => sum + p.price, 0)
    return round2(cakesTotal + addonsTotal + promosTotal)
  }, [cakes, additionalProducts, promotionsInOrder])

  const itemCount = cakes.length + additionalProducts.length + promotionsInOrder.length

  const clearOrder = useCallback(() => {
    setCakes([])
    setAdditionalProducts([])
    setPromotionsInOrder([])
  }, [])

  // Construye el mensaje completo de WhatsApp y el enlace de diseño de
  // cada pastel (apunta a /diseno/:cakeId, donde la administradora puede
  // ver la imagen en alta calidad y descargarla).
  const buildWhatsAppMessage = useCallback(
    (orderNumber) => {
      const lines = []
      lines.push(`*${orderNumber}* — ${business.businessName}`)
      lines.push(`Fecha del pedido: ${new Date().toLocaleDateString('es-ES')}`)
      lines.push('')
      cakes.forEach((c, i) => {
        const designUrl = `${window.location.origin}/diseno/${c.cake.id}`
        lines.push(`🍰 Pastel ${i + 1}: ${c.cake.name}`)
        lines.push(`   Sabor: ${c.flavor.name} | Relleno: ${c.filling.name} | Tamaño: ${c.size.label}`)
        lines.push(`   Entrega: ${formatDateHuman(c.date)} a las ${c.time}`)
        lines.push(`   Precio: ${formatCurrency(c.price)}`)
        lines.push(`   Diseño: ${designUrl}`)
        lines.push('')
      })
      if (additionalProducts.length > 0) {
        lines.push('🛍️ Productos adicionales:')
        additionalProducts.forEach((p) => {
          lines.push(`   ${p.product.name} — ${p.tier.qty} unidades — ${formatCurrency(p.price)}`)
        })
        lines.push('')
      }
      if (promotionsInOrder.length > 0) {
        lines.push('🎉 Promociones:')
        promotionsInOrder.forEach((p) => {
          lines.push(`   ${p.promotion.title} — ${formatCurrency(p.price)}`)
        })
        lines.push('')
      }
      lines.push(`*Total: ${formatCurrency(total)}*`)
      return lines.join('\n')
    },
    [cakes, additionalProducts, promotionsInOrder, total, business.businessName]
  )

  // Finaliza el pedido: obtiene un número atómico desde Firestore, guarda
  // el pedido en la colección central (visible de inmediato en el panel
  // administrador), actualiza estadísticas de más vendidos, y abre
  // WhatsApp con el mensaje listo. `submitting` evita doble envío si el
  // cliente presiona el botón varias veces mientras se genera el número.
  const submitOrder = useCallback(async () => {
    if (submitting) return null
    setSubmitting(true)
    try {
      const orderNumber = await getNextOrderNumber()
      const message = buildWhatsAppMessage(orderNumber)

      // No se espera (await) el guardado en Firestore antes de abrir
      // WhatsApp: la prioridad es que el cliente complete el envío del
      // pedido sin demoras. Si falla, queda registrado en consola y el
      // mensaje de WhatsApp ya enviado conserva toda la información.
      orderOps
        .add({
          orderNumber,
          createdAt: new Date().toISOString(),
          status: 'Pendiente',
          cakes,
          additionalProducts,
          promotions: promotionsInOrder,
          total
        })
        .catch((err) => console.error('No se pudo guardar el pedido en la base de datos:', err))

      bumpCakeStats(cakes.map((c) => c.cake.id))

      const url = `https://wa.me/${business.whatsappNumber}?text=${encodeURIComponent(message)}`
      window.open(url, '_blank', 'noopener,noreferrer')

      clearOrder()
      return orderNumber
    } finally {
      setSubmitting(false)
    }
  }, [submitting, cakes, additionalProducts, promotionsInOrder, total, buildWhatsAppMessage, clearOrder, orderOps, business.whatsappNumber])

  const value = {
    cakes,
    additionalProducts,
    promotionsInOrder,
    total,
    itemCount,
    submitting,
    addCake,
    removeCake,
    addAdditionalProduct,
    removeAdditionalProduct,
    addPromotion,
    removePromotion,
    clearOrder,
    submitOrder,
    buildWhatsAppMessage
  }

  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>
}

export function useOrder() {
  const ctx = useContext(OrderContext)
  if (!ctx) throw new Error('useOrder debe usarse dentro de <OrderProvider>')
  return ctx
}
