import { createContext, useCallback, useContext, useState } from 'react'

const NotificationContext = createContext(null)

let toastId = 0

export function NotificationProvider({ children }) {
  const [toasts, setToasts] = useState([])

  const notify = useCallback((type, message, durationMs = 4000) => {
    const id = ++toastId
    setToasts((prev) => [...prev, { id, type, message }])
    if (durationMs) {
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id))
      }, durationMs)
    }
    return id
  }, [])

  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  return (
    <NotificationContext.Provider value={{ toasts, notify, dismiss }}>{children}</NotificationContext.Provider>
  )
}

export function useNotify() {
  const ctx = useContext(NotificationContext)
  if (!ctx) throw new Error('useNotify debe usarse dentro de <NotificationProvider>')
  return ctx
}
