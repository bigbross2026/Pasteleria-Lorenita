import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Configuración base de Vite. Preparada para agregar alias de rutas
// y variables de entorno a medida que el proyecto crezca.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    open: true
  },
  resolve: {
    alias: {
      '@': '/src'
    }
  }
})
