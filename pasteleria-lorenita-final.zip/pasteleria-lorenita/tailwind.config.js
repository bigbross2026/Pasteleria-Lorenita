/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      // Los colores apuntan a variables CSS definidas por el tema activo
      // (ver src/themes/themes.js). Así, cambiar de tema no requiere
      // recompilar Tailwind: solo se actualizan las variables en :root.
      colors: {
        primary: {
          DEFAULT: 'rgb(var(--color-primary) / <alpha-value>)',
          dark: 'rgb(var(--color-primary-dark) / <alpha-value>)'
        },
        secondary: 'rgb(var(--color-secondary) / <alpha-value>)',
        accent: 'rgb(var(--color-accent) / <alpha-value>)',
        background: 'rgb(var(--color-background) / <alpha-value>)',
        surface: 'rgb(var(--color-surface) / <alpha-value>)',
        card: 'rgb(var(--color-card) / <alpha-value>)',
        header: 'rgb(var(--color-header) / <alpha-value>)',
        'text-main': 'rgb(var(--color-text) / <alpha-value>)',
        'text-muted': 'rgb(var(--color-text-muted) / <alpha-value>)',
        'button-text': 'rgb(var(--color-button-text) / <alpha-value>)'
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        body: ['"Plus Jakarta Sans"', 'sans-serif']
      },
      borderRadius: {
        card: '1.25rem',
        pill: '999px'
      },
      boxShadow: {
        soft: '0 8px 24px -6px rgb(0 0 0 / 0.12)',
        lift: '0 16px 32px -8px rgb(0 0 0 / 0.18)'
      },
      keyframes: {
        pulseAttention: {
          '0%, 100%': { transform: 'scale(1)', opacity: '1' },
          '50%': { transform: 'scale(1.15)', opacity: '0.7' }
        },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' }
        }
      },
      animation: {
        'pulse-attention': 'pulseAttention 1.4s ease-in-out infinite',
        'fade-in-up': 'fadeInUp 0.5s ease-out'
      }
    }
  },
  plugins: []
}
