// Service Worker simple para Pastelería Lorenita.
// Estrategia:
// - Navegación (HTML): network-first, con fallback a caché si no hay
//   conexión, para que la app instalada abra aunque el usuario esté sin
//   internet momentáneamente.
// - Archivos estáticos propios (JS/CSS/íconos/manifest): cache-first,
//   ya que Vite los versiona con hash en el nombre y son seguros de
//   cachear agresivamente.
// - Todo lo demás (Firestore, Storage, APIs externas) NUNCA se
//   intercepta: los datos del negocio siempre deben ser los más
//   recientes, nunca servidos desde caché.

const CACHE_NAME = 'lorenita-cache-v1'
const APP_SHELL = ['/', '/manifest.json', '/icons/icon-192.png', '/icons/icon-512.png']

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  )
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  )
  self.clients.claim()
})

function isOwnStaticAsset(url) {
  return url.origin === self.location.origin && /\.(js|css|png|jpg|jpeg|webp|svg|woff2?)$/.test(url.pathname)
}

self.addEventListener('fetch', (event) => {
  const { request } = event
  if (request.method !== 'GET') return

  const url = new URL(request.url)

  // Nunca cachear peticiones a Firebase (Firestore/Storage/Auth) ni a
  // dominios externos: los datos del negocio deben ser siempre en vivo.
  if (url.origin !== self.location.origin) return

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          caches.open(CACHE_NAME).then((cache) => cache.put('/', response.clone()))
          return response
        })
        .catch(() => caches.match('/'))
    )
    return
  }

  if (isOwnStaticAsset(url)) {
    event.respondWith(
      caches.match(request).then(
        (cached) =>
          cached ||
          fetch(request).then((response) => {
            caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()))
            return response
          })
      )
    )
  }
})
