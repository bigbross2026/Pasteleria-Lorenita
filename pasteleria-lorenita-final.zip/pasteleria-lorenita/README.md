# Pastelería Lorenita — Bloque 1 + 2 + 3 + 4 (proyecto completo)

**Bloque 1** entregó la base profesional: arquitectura, sistema de diseño,
sistema de temas y base de datos normalizada.

**Bloque 2** entregó el módulo completo del cliente: tutorial de
bienvenida, catálogo de diseños, personalización paso a paso, productos
adicionales, promociones, clientes satisfechos y el cierre del pedido por
WhatsApp.

**Bloque 3** entregó el **panel de administración completo y funcional**:
todo lo que el cliente ve en el catálogo ahora es editable en tiempo real
por la administradora, con pedidos, reportes y configuración operando
sobre los mismos datos.

**Bloque 4** (este) conecta todo a una **base de datos real en Firebase**,
y deja el proyecto optimizado, seguro y listo para producción: PWA
instalable, SEO completo, accesibilidad, estadísticas con gráficos,
notificaciones, respaldos múltiples en la nube y carga diferida.

## 🔥 Novedades del Bloque 4: Firebase como backend real

- **Firestore reemplaza `localStorage`** como fuente de verdad. El cambio
  se hizo dentro de `src/data/useCollection.js` y `useFirestoreDoc.js`
  manteniendo exactamente la misma API que ya usaba todo el resto de la
  app (`useAdminData()`), así que **ningún componente tuvo que cambiar su
  lógica** — solo se reemplazó el motor de guardado.
- **Tiempo real de verdad**: gracias a `onSnapshot`, si la administradora
  edita el catálogo desde su celular, el sitio público de un cliente que
  ya tiene la página abierta en otra pantalla se actualiza solo, sin
  recargar.
- **Firebase Storage** para fotografías reales: categorías/diseños (subida
  masiva), logotipo, productos adicionales, promociones y fotos de
  testimonios. Con validación de tipo y tamaño (`src/firebase/storage.js`,
  máximo 5 MB, solo imágenes).
- **Número de pedido atómico**: se corrigió un problema real que tenía la
  versión anterior (contador en `localStorage`, que solo era correcto
  dentro de un mismo navegador). Ahora usa una **transacción de
  Firestore** (`src/data/counters.js`), así que dos clientes comprando al
  mismo tiempo desde dispositivos distintos siempre reciben números de
  pedido distintos y consecutivos.
- **Autenticación real del administrador** (`src/firebase/auth.js`): la
  contraseña **ya no se guarda en la base de datos**. Por dentro se usa
  Firebase Authentication con una cuenta técnica fija e invisible para la
  persona (que solo ve el campo de contraseña, tal como pide el brief).
  Esto da protección real contra fuerza bruta: Firebase bloquea
  automáticamente los intentos repetidos fallidos.
- **Reglas de seguridad reales** en `firestore.rules` y `storage.rules`:
  lectura pública del catálogo (necesaria para que el sitio funcione),
  escritura solo para el admin autenticado, y los pedidos de un cliente no
  pueden ser leídos por otros clientes.
- **Respaldos múltiples en la nube** (`src/utils/firestoreBackup.js`):
  crear, listar, descargar, restaurar y eliminar respaldos — ya no depende
  de un solo archivo `.json` local.

## Otras novedades de calidad y producción del Bloque 4

- **PWA instalable**: `manifest.json`, íconos propios, Service Worker
  (`public/sw.js`) con estrategia de caché segura (nunca cachea datos de
  Firebase, solo archivos estáticos propios).
- **SEO**: meta etiquetas completas, Open Graph, Twitter Cards, datos
  estructurados (`schema.org/Bakery`), `robots.txt` y `sitemap.xml`.
- **Rendimiento**: todas las rutas usan `React.lazy` + `Suspense` — el
  panel administrador (formularios, gráficos, generación de PDF) no se
  descarga hasta que alguien realmente entra a `/admin`.
- **Accesibilidad**: enlace "saltar al contenido", `aria-label` en
  imágenes/íconos decorativos, roles ARIA en diálogos, foco visible y
  navegación por teclado en modales.
- **Estadísticas internas con gráficos** (`recharts`): pedidos por estado,
  pasteles/categorías/sabores/rellenos/tamaños/productos/promociones más
  vendidos, y tendencia de ingresos — todo en `Reportes → Estadísticas
  generales`.
- **Notificaciones**: campana con alertas en vivo (pedidos nuevos,
  publicaciones pendientes, promociones por vencer, límite diario
  alcanzado) y notificaciones tipo "toast" al guardar, eliminar o
  restaurar información.

## ⚠️ Antes de usar en producción — pasos pendientes en Firebase Console

El código ya está listo, pero **hay que publicar las reglas de seguridad**
para que la protección sea real (mientras no se publiquen, Firestore
usará su configuración por defecto del proyecto):

1. Firebase Console → **Firestore Database → Reglas** → pega el contenido
   de `firestore.rules` → Publicar.
2. Firebase Console → **Storage → Reglas** → pega el contenido de
   `storage.rules` → Publicar.
3. Firebase Console → **Authentication → Sign-in method** → habilita el
   proveedor **Correo/contraseña** (Email/Password) — sin esto, el login
   del admin no podrá crear ni validar la cuenta técnica interna.
4. La primera vez que alguien entre a `/admin/acceso` y escriba `LOREILI`,
   la app crea automáticamente la cuenta interna del administrador en
   Firebase Authentication. Desde ese momento, `LOREILI` deja de servir y
   solo funciona la contraseña que se haya configurado.
5. (Opcional, recomendado) Instalar Firebase CLI y ejecutar
   `firebase deploy --only firestore:rules,storage` desde la raíz del
   proyecto en lugar de copiar/pegar manualmente.

## Novedades del Bloque 3

- **`src/data/AdminDataContext.jsx`** — fuente única de verdad para
  categorías, diseños/fotos, sabores, rellenos, tamaños, productos
  adicionales, promociones, testimonios, pedidos y configuración del
  negocio. Todo el módulo cliente (Bloque 2) ahora LEE de aquí en vez de
  datos fijos; todo el panel admin ESCRIBE aquí. `src/data/useCollection.js`
  es el hook CRUD genérico detrás de cada colección.
- **Acceso administrador**: contraseña inicial `LOREILI`. Desde el Bloque 4
  esto ya no se guarda ni se compara en la base de datos — ver la sección
  de Firebase Authentication más arriba. Cambiable desde
  `Configuración → General`. Mensaje amigable si la contraseña no es válida.
- **Módulo Pedidos**: búsqueda por código (`Pedido-00100`), ficha completa
  del pedido (fechas, diseño, sabor, relleno, tamaño, productos, total,
  enlace de diseño), cambio de estado (Pendiente / Entregado / Cancelado —
  sin "en preparación", como se pidió), y el **límite diario de
  producción** con la regla de excedente de hasta 2 pasteles del mismo
  pedido (`src/utils/dailyLimit.js`), reflejado en el selector de fecha
  que ve el cliente.
- **Módulo Pasteles**: categorías 100% personalizables (nombre, emoji,
  color de marco, recargo, activa/silenciada) con subida masiva de fotos,
  y por foto: ver, eliminar, silenciar, mover de categoría. Eliminar una
  categoría con fotos pregunta qué hacer con ellas
  (`ConfirmChoiceDialog`). Sabores, rellenos y tamaños con CRUD completo
  vía `SimpleListManager` (componente reutilizable).
- **Módulo Promociones**: CRUD completo (foto, nombre, descripción, precio,
  vigencia, estado) + interruptor de módulo. Las promociones ahora se
  pueden agregar directamente al pedido del cliente (antes solo se
  mostraban).
- **Módulo Productos Adicionales**: totalmente dinámico — cualquier
  producto con cualquier cantidad de "niveles" (unidades → precio),
  silenciar individualmente, editar, eliminar.
- **Módulo Clientes Satisfechos**: aprobar / rechazar / eliminar
  publicaciones, editar el mensaje, eliminar fotos una por una o todas a
  la vez.
- **Módulo Reportes**: diario, semanal y mensual — pedidos, ventas por
  categoría, por promoción, por producto adicional, e ingresos totales
  (pedidos cancelados excluidos), con **exportar a PDF** con logotipo,
  fecha y resumen (`jspdf`, ver `src/utils/reports.js`).
- **Módulo Configuración**: contraseña, WhatsApp, logotipo, nombre del
  negocio, horario de atención, activar/desactivar cada módulo, límite
  diario, temas (todo lo del Bloque 1 se conserva), y **respaldo /
  restauración** de todos los datos como archivo `.json` descargable.
- Indicadores de "pendiente" (punto animado) en el menú del admin ahora
  son reales: pedidos sin revisar y publicaciones por aprobar.

## Estado real de seguridad (honesto, sin exagerar)

- **Ya es real**: contraseña del admin gestionada por Firebase
  Authentication (nunca en texto plano en la base de datos), bloqueo
  automático de fuerza bruta, reglas de Firestore/Storage que separan
  lectura pública de escritura solo-admin, validación de tipo/tamaño en
  cada imagen subida, y saneamiento de campos de texto libre
  (`src/utils/validation.js`).
- **Limitación conocida**: los conteos internos (`counters/orders`,
  `stats/cakeStats`) y la creación de pedidos/testimonios permiten
  escritura pública porque son parte del flujo normal de un cliente sin
  sesión (finalizar compra, compartir experiencia). Las reglas en
  `firestore.rules` limitan qué campos y formas son válidas en esas
  escrituras, pero un uso extremadamente malicioso y dirigido (por
  ejemplo, un script que cree miles de pedidos falsos) requeriría además
  reglas de límite de tasa (App Check / reCAPTCHA), que no están incluidas
  en este bloque y son un buen siguiente paso si el negocio crece.
- **Protección contra SQL Injection**: no aplica de la forma tradicional
  porque Firestore no usa SQL ni consultas de texto interpoladas; el SDK
  parametriza todo por diseño.
- Las carpetas `database/schema.sql` del Bloque 1 se conservan como
  referencia de diseño relacional, pero la base de datos que realmente
  usa la app en producción es Firestore (no relacional), documentada en
  `src/data/seedData.js`.

## Stack elegido

- **React 18 + Vite** — arranque rápido, HMR instantáneo, build optimizado.
- **React Router 6** — enrutamiento de los módulos Cliente y Administrador,
  con carga diferida (`React.lazy`) por ruta.
- **Tailwind CSS** — utilidades + variables CSS para que los temas cambien
  toda la app sin recompilar.
- **lucide-react** — iconos grandes, claros y consistentes (clave para un
  admin sin conocimientos técnicos).
- **Firebase** — Firestore (base de datos en tiempo real), Storage
  (fotografías) y Authentication (acceso del admin).
- **recharts** — gráficos del panel de estadísticas.
- **jspdf** — exportación de reportes en PDF.

## Cómo correr el proyecto localmente

```bash
npm install
npm run dev
```

Abre `http://localhost:5173`. La ruta pública es `/`, y el panel administrador
está en `/admin/acceso` (contraseña temporal de desarrollo: `lorenita2026`,
ver nota de seguridad abajo).

## Estructura de carpetas

```
src/
  auth/              AdminAuthContext — puerta de acceso (Firebase Auth por dentro)
  firebase/          config.js, auth.js, storage.js — toda la integración con Firebase
  themes/            10 temas + ThemeContext (motor de temas, del Bloque 1)
  context/           OrderContext (carrito), NotificationContext (toasts)
  data/              AdminDataContext (fuente única de datos), useCollection,
                     useFirestoreDoc, counters.js, seedData.js
  utils/             pricing, deliveryTime, dailyLimit, validation, whatsapp,
                     reports, firestoreBackup
  components/
    ui/              Button, Card, PlaceholderMedia — piezas reutilizables
    layout/          Navbar, Footer, PublicLayout, AdminLayout
    order/           Todo el flujo de compra del cliente (Bloque 2)
    admin/           Piezas del panel: AdminModuleHeader, SimpleListManager,
                     ImageUploadField, NotificationBell, ToastStack, charts/
    common/          Modal genérico
  pages/
    client/          Páginas públicas (Inicio, Crea tu pastel, Promociones…)
    admin/           Login, Dashboard, y cada módulo (Pedidos, Pasteles,
                     Promociones, Productos Adicionales, Clientes
                     Satisfechos, Reportes, Configuración)
  App.jsx            Rutas, con carga diferida (React.lazy) por página
  main.jsx           Punto de entrada: monta providers y el Service Worker
public/
  manifest.json, sw.js, icons/, robots.txt, sitemap.xml
firestore.rules       Reglas de seguridad de la base de datos
storage.rules         Reglas de seguridad de los archivos subidos
firebase.json         Configuración de despliegue (hosting + reglas)
database/
  schema.sql         Diseño relacional de referencia del Bloque 1 (no usado en runtime)
```

## Sistema de temas

Cada tema es un objeto con 11 roles de color (`primary`, `secondary`,
`accent`, `background`, `surface`, `card`, `header`, `text`, `textMuted`,
`buttonText`, `primaryDark`). `ThemeProvider` aplica esos colores como
variables CSS en `:root`, y Tailwind las consume vía
`rgb(var(--color-x) / <alpha-value>)`. Esto significa que **ningún
componente necesita saber qué tema está activo**: solo usa clases como
`bg-primary` o `text-text-muted` y el color correcto aparece solo.

Incluye:

- 10 temas predisñados (`src/themes/themes.js`).
- Vista previa temporal (`previewTheme`) que no se guarda.
- Aplicar tema con transición suave (`theme-transition` en CSS).
- Editor de tema personalizado (guardar / aplicar / eliminar), disponible en
  `Configuración → Tema personalizado` dentro del admin.

## Panel administrador

Menú principal con **únicamente** 7 botones grandes (Pedidos, Pasteles,
Promociones, Productos Adicionales, Clientes Satisfechos, Reportes,
Configuración), tal como se especificó. Los módulos con pendientes muestran
un punto animado de atención (ver `Dashboard.jsx`).

## ⚠️ Nota de seguridad importante

El login del admin en este bloque es una **simulación de frontend** para
poder navegar el panel mientras se diseña. Cuando se construya el backend
(siguiente bloque), se debe reemplazar `AdminAuthContext.jsx` para que:

1. La contraseña se valide en el servidor contra un hash (bcrypt/argon2)
   guardado en `admin_settings.password_hash`.
2. Nunca se compare ni se guarde en texto plano, ni en el cliente ni en la
   base de datos.
3. La sesión se maneje con un token (JWT o cookie httpOnly), no con
   `sessionStorage` como aquí.

## Base de datos

`database/schema.sql` normaliza el negocio en tablas independientes:
configuración, temas, clientes, catálogo de pasteles (con tamaños, sabores
y rellenos como relaciones N:M), productos adicionales, promociones,
pedidos (con historial de estados) y clientes satisfechos. Está diseñada
para que el siguiente bloque (proceso de compra) se conecte directamente
sin tener que rediseñar tablas existentes.

## Siguiente bloque

Con esta base lista, el siguiente paso es construir:

- El flujo completo de personalización y compra del cliente.
- La lógica funcional de cada módulo del admin (por ahora son placeholders).
- La conexión real a base de datos y autenticación segura del backend.
